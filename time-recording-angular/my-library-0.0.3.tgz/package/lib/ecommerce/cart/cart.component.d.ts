import { EC_Functions } from '../EC_Functions';
import { PackagesInterface } from '../EC_Packages';
import { ServicesInterface } from '../EC_Services';
import * as i0 from "@angular/core";
export declare class CartComponent {
    private EC_Func;
    constructor(EC_Func: EC_Functions);
    Total: number;
    Cart: any[];
    ngOnInit(): void;
    Remove(item: (PackagesInterface | ServicesInterface)): void;
    trackByFn(index: number, item: any): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartComponent, "app-cart", never, {}, {}, never, never, false, never>;
}
