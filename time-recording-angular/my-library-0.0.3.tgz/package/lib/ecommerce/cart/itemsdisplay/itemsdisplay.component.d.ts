import { Router } from '@angular/router';
import { EC_Functions } from '../../EC_Functions';
import { PackagesInterface } from '../../EC_Packages';
import { ServicesInterface } from '../../EC_Services';
import * as i0 from "@angular/core";
export declare class ItemsdisplayComponent {
    EC_Func: EC_Functions;
    router: Router;
    constructor(EC_Func: EC_Functions, router: Router);
    Total: number;
    Cart: any[];
    ngOnInit(): void;
    trackByFn(index: number, item: any): number;
    Price_OutputFilter(Input: any): string;
    Remove(item: (PackagesInterface | ServicesInterface)): void;
    Clear(): void;
    CheckoutOrView(): void;
    Checkout: () => Promise<void>;
    showCheckout: () => Promise<void>;
    isCartEmpty: () => boolean;
    ClearCart: () => void;
    getCartt: (update?: boolean) => ([] | PackagesInterface | ServicesInterface)[];
    getcartTotal: (cart: any[], convert?: string | null) => number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemsdisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ItemsdisplayComponent, "ec-itemsdisplay", never, {}, {}, never, never, false, never>;
}
