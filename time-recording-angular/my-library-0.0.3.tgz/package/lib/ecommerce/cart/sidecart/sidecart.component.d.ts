import { OnInit } from '@angular/core';
import { EC_Functions } from '../../EC_Functions';
import * as i0 from "@angular/core";
export declare class SidecartComponent implements OnInit {
    private EC_Func;
    constructor(EC_Func: EC_Functions);
    ShowCart: boolean;
    Cart_Display(): void;
    Total: number;
    Cart: any[];
    ngOnInit(): void;
    trackByFn(index: number, item: any): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidecartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidecartComponent, "ec-sidecart", never, {}, {}, never, never, false, never>;
}
