export declare var NavList: string[];
export interface PackagesInterface {
    ID: number;
    Title: string;
    Description: string;
    Tiers: {
        Title: string;
        Price: number;
        Length: string;
        Extra: string;
    }[] | any;
    Type: string;
    Inclusions: string[];
    Policies: string;
    Keywords: string[];
    Quantity?: number;
}
export declare var Packages: PackagesInterface[];
