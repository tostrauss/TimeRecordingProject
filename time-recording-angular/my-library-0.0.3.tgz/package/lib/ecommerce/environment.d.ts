export declare const environment: {
    production: boolean;
    stripePublishableKey: string;
};
