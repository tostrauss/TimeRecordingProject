export interface ServicesInterface {
    ID: number;
    Title: string;
    Description: string;
    Inclusions: string[];
    Policies: string;
    Tiers: {
        Price: number;
        Length: string;
        Extra: string | string[];
    }[] | any;
    AssociatedServices: number[];
    Type: string;
    Keywords: string[];
    onSuccess?: any;
    Quantity?: number;
}
export declare var Services: ServicesInterface[];
export declare var WebsiteAdvancedServices: string[];
