import { OnInit } from '@angular/core';
import { EC_Functions } from '../EC_Functions';
import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
export declare class ProductViewComponent implements OnInit {
    private userService;
    private EC_Func;
    product: any;
    IsTiered: boolean;
    CustomPackages: any;
    ShowCategories: boolean;
    constructor(userService: IndexedDBService, EC_Func: EC_Functions);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductViewComponent, "ec-product-view", never, { "CustomPackages": { "alias": "CustomPackages"; "required": false; }; "ShowCategories": { "alias": "ShowCategories"; "required": false; }; }, {}, never, never, false, never>;
}
