export declare var eRouteKey: {
    ecommerce: {
        path: string;
        canActivate: boolean;
    };
    cart: {
        path: string;
        canActivate: boolean;
    };
    productView: {
        path: string;
        canActivate: boolean;
    };
    productTier: {
        path: string;
        canActivate: boolean;
    };
    checkout: {
        path: string;
        canActivate: boolean;
    };
};
