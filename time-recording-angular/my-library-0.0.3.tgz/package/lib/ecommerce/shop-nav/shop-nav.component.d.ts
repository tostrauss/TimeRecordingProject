import * as i0 from "@angular/core";
export declare class ShopNavComponent {
    NavItems: string[];
    scrollToSection(sectionId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShopNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShopNavComponent, "ec-shop-nav", never, {}, {}, never, never, false, never>;
}
