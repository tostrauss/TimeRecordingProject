import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PackagesInterface } from './EC_Packages';
import { ServicesInterface } from './EC_Services';
import { IndexedDBService } from '../Functions_USession';
import { HttpClient } from '@angular/common/http';
import * as i0 from "@angular/core";
export declare class EC_Functions {
    private router;
    private userService;
    private http;
    private cartItems;
    Cart: Observable<([] | PackagesInterface | ServicesInterface)[]>;
    private cartTotal;
    CartTotal: Observable<number>;
    AllAvailable: PackagesInterface[];
    view: {
        ecommerce: {
            path: string;
            canActivate: boolean;
        };
        cart: {
            path: string;
            canActivate: boolean;
        };
        productView: {
            path: string;
            canActivate: boolean;
        };
        productTier: {
            path: string;
            canActivate: boolean;
        };
        checkout: {
            path: string;
            canActivate: boolean;
        };
    };
    lView: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    constructor(router: Router, userService: IndexedDBService, http: HttpClient);
    ChangePackages(input: PackagesInterface[]): void;
    getCartt(update?: boolean): (PackagesInterface | ServicesInterface | [])[];
    UpdateCart(item: (PackagesInterface | ServicesInterface), Type?: "set" | "add" | "sub" | "clear", num?: number | null): void;
    ClearCart(): void;
    ConstructStoreItems(): (PackagesInterface | ServicesInterface)[];
    ViewProductInfo(ID: number, Refresh?: boolean): void;
    getPrice(item: any): number;
    getcartTotal(cart: any[], convert?: string | null): number;
    ConvertCurrency(amount: number, roundTo?: "decimal" | null): number;
    Checkout(): Promise<void>;
    ViewCart(): Promise<void>;
    isCartEmpty(): boolean;
    removeUndefinedProperties(obj: any): any;
    private apiUrl;
    getUsdToEurRate(): Observable<number>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EC_Functions, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EC_Functions>;
}
