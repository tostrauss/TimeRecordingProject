import { EC_Functions } from '../EC_Functions';
import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
export declare class TickMarkerComponent {
    private EC_Func;
    private userService;
    id: any;
    hide: boolean;
    CustomPackages: any;
    constructor(EC_Func: EC_Functions, userService: IndexedDBService);
    Cart: any[];
    ngOnInit(): void;
    updateQuantity(id: any, delta: (number | string)): void;
    getQuantity(id: any): number;
    updateC(id: any, event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TickMarkerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TickMarkerComponent, "app-tick-marker", never, { "id": { "alias": "id"; "required": false; }; }, {}, never, never, false, never>;
}
