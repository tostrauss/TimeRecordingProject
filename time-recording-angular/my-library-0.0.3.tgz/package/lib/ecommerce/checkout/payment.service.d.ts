import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../Functions_API';
import { EC_Functions } from '../EC_Functions';
import { PaymentMethod, StripeCardElement } from '@stripe/stripe-js';
import { Observable } from 'rxjs';
import { StripeService } from './stripe.service';
import * as i0 from "@angular/core";
export interface PaymentIntentResponse {
    clientSecret: string;
}
export declare class PaymentService {
    private http;
    private API;
    private ECF;
    private stripeService;
    private stripe;
    constructor(http: HttpClient, API: ApiService, ECF: EC_Functions, stripeService: StripeService);
    private getStripe;
    createPaymentIntent(paymentMethod: PaymentMethod, customer: any): Observable<any>;
    createPaymentMethod(card: StripeCardElement, customerID: string, billingDetails: {
        address: {
            city: string;
            line1: string;
            postal_code: string;
            state: string;
        };
        email: string;
        name: string;
    }): Promise<PaymentMethod | undefined>;
    confirmPayment(clientSecret: string, paymentMethod: PaymentMethod): Promise<void>;
    cleanup(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaymentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PaymentService>;
}
