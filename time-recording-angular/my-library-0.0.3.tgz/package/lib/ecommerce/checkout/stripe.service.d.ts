import { NgZone } from '@angular/core';
import { Stripe, StripeElements } from '@stripe/stripe-js';
import * as i0 from "@angular/core";
export declare class StripeService {
    private ngZone;
    private stripeInstance;
    private cleanupInterval;
    private readonly stripePublicKey;
    constructor(ngZone: NgZone);
    initStripe(publishableKey: string): Promise<any>;
    getStripe(): Promise<Stripe | null>;
    getStripeElements(): Promise<StripeElements | null>;
    cleanup(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StripeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StripeService>;
}
