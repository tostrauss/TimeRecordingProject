import { OnInit, ElementRef } from '@angular/core';
import { PaymentService } from './payment.service';
import { Router } from '@angular/router';
import { ApiService } from '../../Functions_API';
import { EC_Functions } from '../EC_Functions';
import { IndexedDBService } from '../../Functions_USession';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormService } from '../../Functions_Forms';
import { Stripe } from '@stripe/stripe-js';
import { StripeService } from './stripe.service';
import * as i0 from "@angular/core";
export declare class CheckoutComponent implements OnInit {
    private router;
    private ECF;
    private userService;
    private formBuilder;
    formFunctions: FormService;
    private paymentService;
    private API;
    private stripeService;
    data: any;
    IsUserLoggedIn: boolean;
    stripe: Stripe | null;
    private readonly stripePublicKey;
    loading: boolean;
    cardComplete: boolean;
    cardError: string | null;
    showInvoice: boolean;
    view: {
        ecommerce: {
            path: string;
            canActivate: boolean;
        };
        cart: {
            path: string;
            canActivate: boolean;
        };
        productView: {
            path: string;
            canActivate: boolean;
        };
        productTier: {
            path: string;
            canActivate: boolean;
        };
        checkout: {
            path: string;
            canActivate: boolean;
        };
    };
    lockClosed: string;
    applicableCountries: string[];
    GERMANStates: string[];
    USStates: string[];
    stateSelectors: string[];
    constructor(router: Router, ECF: EC_Functions, userService: IndexedDBService, formBuilder: FormBuilder, formFunctions: FormService, paymentService: PaymentService, API: ApiService, stripeService: StripeService);
    cardNumber: string;
    cardExp: string;
    cardCvv: string;
    errorMessage: string;
    cardElement: ElementRef;
    private card;
    User: any;
    form: FormGroup;
    ngOnInit(): Promise<void>;
    private initializeForm;
    showOtherStateInput: boolean;
    onStateChange(event: Event): void;
    updateStateSelectors(country: string): void;
    private updateCardElementOptions;
    updateZipValidators(country: string): void;
    UpdateButtonColor(): void;
    ngOnDestroy(): void;
    handlePayment(event: Event): Promise<void>;
    CheckCart(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutComponent, "app-checkout", never, {}, {}, never, never, false, never>;
}
