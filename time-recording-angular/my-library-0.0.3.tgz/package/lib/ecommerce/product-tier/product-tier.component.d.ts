import { OnInit } from '@angular/core';
import { EC_Functions } from '../EC_Functions';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
export declare class ProductTierComponent implements OnInit {
    private EC_Func;
    private router;
    view: {
        ecommerce: {
            path: string;
            canActivate: boolean;
        };
        cart: {
            path: string;
            canActivate: boolean;
        };
        productView: {
            path: string;
            canActivate: boolean;
        };
        productTier: {
            path: string;
            canActivate: boolean;
        };
        checkout: {
            path: string;
            canActivate: boolean;
        };
    };
    Product: any;
    CustomPackages: any;
    checkmark: string;
    constructor(EC_Func: EC_Functions, router: Router);
    ProductTiers: any;
    ProductInclusions: string[];
    ngOnInit(): void;
    onClick(index: number): void;
    Convert: (amount: number, roundTo?: "decimal" | null) => number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductTierComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductTierComponent, "ec-product-tier", never, { "Product": { "alias": "Product"; "required": false; }; "CustomPackages": { "alias": "CustomPackages"; "required": false; }; }, {}, never, never, false, never>;
}
