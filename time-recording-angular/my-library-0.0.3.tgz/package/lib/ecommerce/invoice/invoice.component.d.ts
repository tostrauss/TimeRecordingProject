import { OnInit } from '@angular/core';
import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
interface InvoiceInfo {
    name: string;
    address: {
        city: string;
        line1: string;
        country: string;
        line2: string;
        postal_code: string;
        state: string;
    };
    email: string;
    payment_method: string;
    last4: string;
    cardBrand: string;
}
export declare class InvoiceComponent implements OnInit {
    private indexdb;
    data: InvoiceInfo;
    billingAddress: {
        key: string;
        value: string;
    }[];
    constructor(indexdb: IndexedDBService);
    ngOnInit(): void;
    home(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoiceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvoiceComponent, "lib-invoice", never, { "data": { "alias": "data"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
