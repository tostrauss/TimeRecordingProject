import { ActivatedRoute } from '@angular/router';
import { EC_Functions } from './EC_Functions';
import * as i0 from "@angular/core";
export declare class EcommerceComponent {
    private route;
    private EC_Func;
    routeView: string;
    routeURL: {
        ecommerce: {
            path: string;
            canActivate: boolean;
        };
        cart: {
            path: string;
            canActivate: boolean;
        };
        productView: {
            path: string;
            canActivate: boolean;
        };
        productTier: {
            path: string;
            canActivate: boolean;
        };
        checkout: {
            path: string;
            canActivate: boolean;
        };
    };
    constructor(route: ActivatedRoute, EC_Func: EC_Functions);
    static ɵfac: i0.ɵɵFactoryDeclaration<EcommerceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EcommerceComponent, "ec-ecommerce", never, {}, {}, never, never, false, never>;
}
