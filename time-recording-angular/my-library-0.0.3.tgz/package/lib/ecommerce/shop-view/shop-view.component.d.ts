import { EC_Functions } from '../EC_Functions';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
export declare class ShopViewComponent {
    private EC_Func;
    private router;
    view: {
        ecommerce: {
            path: string;
            canActivate: boolean;
        };
        cart: {
            path: string;
            canActivate: boolean;
        };
        productView: {
            path: string;
            canActivate: boolean;
        };
        productTier: {
            path: string;
            canActivate: boolean;
        };
        checkout: {
            path: string;
            canActivate: boolean;
        };
    };
    constructor(EC_Func: EC_Functions, router: Router);
    NavItems: string[];
    AllAvailable: (import("../EC_Packages").PackagesInterface | import("../EC_Services").ServicesInterface)[];
    CustomServices: string[];
    addToCart(item: any): void;
    ViewProductInfo: (ID: number, Refresh?: boolean) => void;
    filterServices(Category: string): (import("../EC_Packages").PackagesInterface | import("../EC_Services").ServicesInterface)[];
    projectRequest(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShopViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShopViewComponent, "ec-shop-view", never, {}, {}, never, never, false, never>;
}
