import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../Functions_API';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class LegalComponent {
    private router;
    private HTTPCall;
    private sanitizer;
    HTML_Output: any;
    sanitizedHtml: SafeHtml;
    Content: 'policies' | 'terms' | 'datarequest' | 'storepolicies';
    constructor(router: ActivatedRoute, HTTPCall: ApiService, sanitizer: DomSanitizer);
    ngOnInit(): void;
    fetchContent(url: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LegalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LegalComponent, "legal-Paperwork", never, {}, {}, never, never, false, never>;
}
