import { IndexedDBService } from '../Functions_USession';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
export declare class SettingsComponent {
    private USessionData;
    private route;
    private router;
    routeKey: {
        settings: {
            path: string;
            canActivate: boolean;
        };
        account: {
            path: string;
            canActivate: boolean;
        };
        profile: {
            path: string;
            canActivate: boolean;
        };
        help: {
            path: string;
            canActivate: boolean;
        };
    };
    routeKeyLogin: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    routeView: string;
    additionalSettings: any;
    User: Promise<any>;
    constructor(USessionData: IndexedDBService, route: ActivatedRoute, router: Router);
    ngOnInit(): void;
    arrowleft: string;
    arrowright: string;
    star: string;
    setViewState(view: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SettingsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SettingsComponent, "app-settings", never, {}, {}, never, never, false, never>;
}
