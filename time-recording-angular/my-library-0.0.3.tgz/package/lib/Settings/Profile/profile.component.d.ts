import * as i0 from "@angular/core";
export declare class ProfileComponent {
    User: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProfileComponent, "settings-profile", never, { "User": { "alias": "User"; "required": false; }; }, {}, never, never, false, never>;
}
