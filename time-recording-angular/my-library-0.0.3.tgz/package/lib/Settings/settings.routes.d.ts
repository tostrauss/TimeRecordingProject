export declare var sRouteKey: {
    settings: {
        path: string;
        canActivate: boolean;
    };
    account: {
        path: string;
        canActivate: boolean;
    };
    profile: {
        path: string;
        canActivate: boolean;
    };
    help: {
        path: string;
        canActivate: boolean;
    };
};
