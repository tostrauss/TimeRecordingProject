import { OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { KeysComponent } from '../../../KEYS';
import { FormService } from '../../../Functions_Forms';
import { IndexedDBService } from '../../../Functions_USession';
import { ApiService } from '../../../Functions_API';
import * as i0 from "@angular/core";
export declare class UserFormComponent implements OnInit {
    private formBuilder;
    private Keys;
    private HTTPCall;
    FormService: FormService;
    userService: IndexedDBService;
    private router;
    private alertController;
    log_in_outline: string;
    key_outline: string;
    closeCircle: string;
    User: any;
    Account_Edit_Form: FormGroup;
    routeKey: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    constructor(formBuilder: FormBuilder, Keys: KeysComponent, HTTPCall: ApiService, FormService: FormService, userService: IndexedDBService, router: Router, alertController: AlertController);
    ngOnInit(): void;
    CheckExi(ControlName: string, Type: string): Promise<void>;
    onSubmit(): Promise<void>;
    resetPass(): void;
    DeletionPolicy: string;
    requestDelete(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserFormComponent, "settings-account-form", never, { "User": { "alias": "User"; "required": false; }; }, {}, never, never, false, never>;
}
