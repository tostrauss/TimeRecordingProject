import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
export declare class AccountComponent {
    private USessionData;
    User: any;
    constructor(USessionData: IndexedDBService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountComponent, "settings-account", never, { "User": { "alias": "User"; "required": false; }; }, {}, never, never, false, never>;
}
