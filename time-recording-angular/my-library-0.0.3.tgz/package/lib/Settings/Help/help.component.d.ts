import * as i0 from "@angular/core";
export declare class HelpComponent {
    constructor();
    User: any;
    Mail: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<HelpComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HelpComponent, "settings-help", never, { "User": { "alias": "User"; "required": false; }; }, {}, never, never, false, never>;
}
