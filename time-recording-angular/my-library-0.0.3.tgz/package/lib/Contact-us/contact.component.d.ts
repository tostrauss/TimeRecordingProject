import * as i0 from "@angular/core";
export declare class ContactComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ContactComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContactComponent, "app-contact", never, {}, {}, never, never, false, never>;
}
