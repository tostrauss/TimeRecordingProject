export declare var cRouteKey: {
    contact: {
        path: string;
        canActivate: boolean;
    };
};
