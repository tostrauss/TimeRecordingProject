import { OnInit } from '@angular/core';
import { KeysComponent } from '../KEYS';
import { FormGroup, FormBuilder } from '@angular/forms';
import { FormService } from '../Functions_Forms';
import { IndexedDBService } from '../Functions_USession';
import * as i0 from "@angular/core";
export declare class ContactUsComponent implements OnInit {
    private formBuilder;
    private Keys;
    FormService: FormService;
    private userService;
    User: any;
    contactForm: FormGroup;
    constructor(formBuilder: FormBuilder, Keys: KeysComponent, FormService: FormService, userService: IndexedDBService);
    ngOnInit(): void;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContactUsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContactUsComponent, "app-contactus", never, {}, {}, never, never, false, never>;
}
