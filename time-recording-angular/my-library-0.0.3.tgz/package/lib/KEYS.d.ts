import * as i0 from "@angular/core";
export declare class KeysComponent {
    readonly UEditKey: string;
    readonly ProPhoto: string;
    readonly UExtra_EditKey: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<KeysComponent, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KeysComponent>;
}
