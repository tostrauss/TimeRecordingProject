import { ErrorHandlingService } from '../../Components/Error/ErrorHandling_Service';
import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
export declare class ShareprofileService {
    private ErrorHelper;
    private USessionData;
    User: any;
    Url: string;
    constructor(ErrorHelper: ErrorHandlingService, USessionData: IndexedDBService);
    share_(dis_name?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShareprofileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShareprofileService>;
}
