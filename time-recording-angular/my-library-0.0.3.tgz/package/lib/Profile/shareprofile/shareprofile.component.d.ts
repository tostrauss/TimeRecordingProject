import { ShareprofileService } from './shareprofile.service';
import * as i0 from "@angular/core";
export declare class ShareprofileComponent {
    private ShareProfile;
    dis_name: string | null;
    constructor(ShareProfile: ShareprofileService);
    Share: string;
    share_(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShareprofileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShareprofileComponent, "profile-shareprofile", never, { "dis_name": { "alias": "dis_name"; "required": false; }; }, {}, never, never, false, never>;
}
