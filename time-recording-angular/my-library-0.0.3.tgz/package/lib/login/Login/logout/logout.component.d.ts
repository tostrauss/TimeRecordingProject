import { Router } from '@angular/router';
import { IndexedDBService } from '../../../Functions_USession';
import * as i0 from "@angular/core";
export declare class LogoutComponent {
    private router;
    private User;
    view: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    constructor(router: Router, User: IndexedDBService);
    logout(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoutComponent, "login-logout", never, {}, {}, never, never, false, never>;
}
