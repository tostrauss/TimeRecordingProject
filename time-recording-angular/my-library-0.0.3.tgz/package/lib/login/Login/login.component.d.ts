import { OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as i0 from "@angular/core";
export declare class LoginComponent implements OnInit {
    private route;
    fullKit: boolean;
    logoBox: boolean;
    error: boolean;
    background: boolean;
    footer: boolean;
    routeKey: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    routeView: string;
    constructor(route: ActivatedRoute);
    selectedTab: string;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginComponent, "user-login", never, { "fullKit": { "alias": "fullKit"; "required": false; }; "logoBox": { "alias": "logoBox"; "required": false; }; "error": { "alias": "error"; "required": false; }; "background": { "alias": "background"; "required": false; }; "footer": { "alias": "footer"; "required": false; }; }, {}, never, never, false, never>;
}
