import { KeysComponent } from '../../../KEYS';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormService } from '../../../Functions_Forms';
import { IndexedDBService } from '../../../Functions_USession';
import * as i0 from "@angular/core";
export declare class PassresetComponent {
    private formBuilder;
    private Keys;
    FormService: FormService;
    userService: IndexedDBService;
    email_outline: string;
    Email: string;
    PassResetForm: FormGroup;
    constructor(formBuilder: FormBuilder, Keys: KeysComponent, FormService: FormService, userService: IndexedDBService);
    User: any;
    ngOnInit(): void;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PassresetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PassresetComponent, "login-passreset", never, { "Email": { "alias": "Email"; "required": false; }; }, {}, never, never, false, never>;
}
