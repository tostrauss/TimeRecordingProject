export interface LoginTokenInterface {
    STATUS: string;
    Email: string;
    sub: number;
    time: number;
    rem: number;
    dis_name: string;
    reg_date: string;
    kys: string;
}
