export declare var lRouteKey: {
    login: {
        path: string;
        canActivate: boolean;
    };
    logout: {
        path: string;
        canActivate: boolean;
    };
    createAccount: {
        path: string;
        canActivate: boolean;
    };
    forgotPassword: {
        path: string;
        canActivate: boolean;
    };
    passwordReset: {
        path: string;
        canActivate: boolean;
    };
};
