import { IndexedDBService } from '../../../Functions_USession';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
export declare class LoginButtonComponent {
    private router;
    private indexedDBService;
    isLoggedIn: boolean;
    view: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    constructor(router: Router, indexedDBService: IndexedDBService);
    logIn(): void;
    settings(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginButtonComponent, "login-button", never, {}, {}, never, never, false, never>;
}
