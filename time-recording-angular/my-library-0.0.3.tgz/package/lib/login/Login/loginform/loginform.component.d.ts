import { OnInit, OnDestroy } from '@angular/core';
import { KeysComponent } from '../../../KEYS';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormService } from '../../../Functions_Forms';
import { Router } from '@angular/router';
import { IndexedDBService } from '../../../Functions_USession';
import * as i0 from "@angular/core";
export declare class LoginformComponent implements OnInit, OnDestroy {
    private formBuilder;
    private Keys;
    FormService: FormService;
    router: Router;
    private userService;
    ShowPassword: boolean;
    togglePasswordVisibility(): void;
    eye_outline: string;
    eye_off_outline: string;
    log_in_outline: string;
    LoginForm: FormGroup;
    Remember: any;
    defaultEmail: string;
    User: any;
    view: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    constructor(formBuilder: FormBuilder, Keys: KeysComponent, FormService: FormService, router: Router, userService: IndexedDBService);
    private userSubscription;
    ngOnInit(): void;
    HideLogin: boolean;
    onSubmit(): Promise<void>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginformComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginformComponent, "login-form", never, { "defaultEmail": { "alias": "defaultEmail"; "required": false; }; }, {}, never, never, false, never>;
}
