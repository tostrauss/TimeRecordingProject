import { Router } from '@angular/router';
import { KeysComponent } from '../../../KEYS';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormService } from '../../../Functions_Forms';
import * as i0 from "@angular/core";
export declare class LoginPopUpComponent {
    private formBuilder;
    private Keys;
    private router;
    FormService: FormService;
    log_in_outline: string;
    ErrorTrack: {} | null;
    RegForm: FormGroup;
    loginTrue: boolean | null;
    view: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    constructor(formBuilder: FormBuilder, Keys: KeysComponent, router: Router, FormService: FormService);
    CheckExi(ControlName: string, Type: string): Promise<void>;
    openPrivacy(): void;
    get defaultEmail(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginPopUpComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginPopUpComponent, "login-pop-up", never, {}, {}, never, never, false, never>;
}
