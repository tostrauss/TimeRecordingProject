import { OnInit } from '@angular/core';
import { KeysComponent } from '../../../KEYS';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormService } from '../../../Functions_Forms';
import { Router } from '@angular/router';
import { IndexedDBService } from '../../../Functions_USession';
import * as i0 from "@angular/core";
export declare class UserRegComponent implements OnInit {
    private formBuilder;
    private Keys;
    private router;
    FormService: FormService;
    private userService;
    eye_outline: string;
    eye_off_outline: string;
    log_in_outline: string;
    view: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    RegForm: FormGroup;
    defaultEmail: string;
    constructor(formBuilder: FormBuilder, Keys: KeysComponent, router: Router, FormService: FormService, userService: IndexedDBService);
    User: any;
    ngOnInit(): void;
    openPrivacy(): void;
    openTerms(): void;
    CheckExi(ControlName: string, Type: string): Promise<void>;
    ShowPassword: boolean;
    togglePasswordVisibility(): void;
    ShowPassword2: boolean;
    togglePasswordVisibility2(): void;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserRegComponent, "login-signupform", never, { "defaultEmail": { "alias": "defaultEmail"; "required": false; }; }, {}, never, never, false, never>;
}
