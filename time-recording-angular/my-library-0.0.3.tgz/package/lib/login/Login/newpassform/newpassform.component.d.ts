import { KeysComponent } from '../../../KEYS';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormService } from '../../../Functions_Forms';
import { Router } from '@angular/router';
import { IndexedDBService } from '../../../Functions_USession';
import * as i0 from "@angular/core";
export declare class NewPassFormComponent {
    private formBuilder;
    private Keys;
    FormService: FormService;
    private router;
    userService: IndexedDBService;
    Pass: string;
    eye_off_outline: string;
    eye_outline: string;
    key_outline: string;
    view: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    NewPassform: FormGroup;
    constructor(formBuilder: FormBuilder, Keys: KeysComponent, FormService: FormService, router: Router, userService: IndexedDBService);
    User: any;
    ngOnInit(): void;
    onSubmit(): void;
    requestPassLink(): void;
    ShowPassword: boolean;
    togglePasswordVisibility(): void;
    ShowPassword2: boolean;
    togglePasswordVisibility2(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NewPassFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NewPassFormComponent, "login-newpassform", never, { "Pass": { "alias": "Pass"; "required": false; }; }, {}, never, never, false, never>;
}
