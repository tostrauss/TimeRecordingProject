import * as i0 from "@angular/core";
export declare class FourZeroFourComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FourZeroFourComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FourZeroFourComponent, "app-404", never, {}, {}, never, never, false, never>;
}
