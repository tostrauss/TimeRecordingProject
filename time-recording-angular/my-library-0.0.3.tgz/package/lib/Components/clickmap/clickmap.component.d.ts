import * as i0 from "@angular/core";
export declare class ClickmapComponent {
    constructor();
    ItemMap: any | {
        Title: string;
        Complete: boolean;
    }[];
    ActiveItem: number;
    CheckmarkOutline: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClickmapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClickmapComponent, "app-clickmap", never, { "ItemMap": { "alias": "ItemMap"; "required": false; }; "ActiveItem": { "alias": "ActiveItem"; "required": false; }; }, {}, never, never, false, never>;
}
