import * as i0 from "@angular/core";
export declare class ScrollTopComponent {
    isAtTop: boolean;
    arrowDown: string;
    arrowUp: string;
    styleAdjust: string;
    onWindowScroll(): void;
    scrollToTopOrBottom(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollTopComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollTopComponent, "app-scroll-top", never, { "styleAdjust": { "alias": "styleAdjust"; "required": false; }; }, {}, never, never, false, never>;
}
