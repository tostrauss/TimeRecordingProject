import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class SplashHandlingService {
    private _splash$;
    splash$: Observable<boolean>;
    setSplash(): void;
    unsetSplashPage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SplashHandlingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SplashHandlingService>;
}
