import { SplashHandlingService } from './SplashService';
import * as i0 from "@angular/core";
export declare class SplashComponent {
    splashService: SplashHandlingService;
    Image: string | null;
    ImageStylingString: string;
    constructor(splashService: SplashHandlingService);
    static ɵfac: i0.ɵɵFactoryDeclaration<SplashComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SplashComponent, "splash-page", never, { "Image": { "alias": "Image"; "required": false; }; }, {}, never, never, false, never>;
}
