import { OnInit, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ClockComponent implements OnInit, OnDestroy {
    clock: Date;
    duration?: number;
    clockContainerStyle: any;
    timerStyle: any;
    timeUnitStyle: any;
    valueStyle: any;
    labelStyle: any;
    useLongLabels: boolean;
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    timer: any;
    ngOnInit(): void;
    ngOnDestroy(): void;
    startTimer(): void;
    clearTimer(): void;
    getDayLabel(): string;
    getHourLabel(): string;
    getMinuteLabel(): string;
    getSecondLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClockComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClockComponent, "app-clock", never, { "clock": { "alias": "clock"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "clockContainerStyle": { "alias": "clockContainerStyle"; "required": false; }; "timerStyle": { "alias": "timerStyle"; "required": false; }; "timeUnitStyle": { "alias": "timeUnitStyle"; "required": false; }; "valueStyle": { "alias": "valueStyle"; "required": false; }; "labelStyle": { "alias": "labelStyle"; "required": false; }; "useLongLabels": { "alias": "useLongLabels"; "required": false; }; }, {}, never, never, false, never>;
}
