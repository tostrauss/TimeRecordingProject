import { OnInit } from '@angular/core';
import { ErrorHandlingService } from './ErrorHandling_Service';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
interface ErrorData {
    Success: boolean;
    Message: string;
    Token?: any;
}
export declare class ErrorComponent implements OnInit {
    private errorService;
    private router;
    ErrorData: ErrorData | null;
    showError: boolean;
    animationState: string;
    constructor(errorService: ErrorHandlingService, router: Router);
    ngOnInit(): void;
    calculateTimeoutDuration(message: string): number;
    closeError(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorComponent, "error", never, { "ErrorData": { "alias": "ErrorData"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
