import { Observable } from 'rxjs';
import { DataInterface } from '../../Functions_API';
import * as i0 from "@angular/core";
export declare class ErrorHandlingService {
    private _error$;
    error$: Observable<DataInterface | null>;
    setError(ErrorData: DataInterface): DataInterface;
    clearError(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorHandlingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorHandlingService>;
}
