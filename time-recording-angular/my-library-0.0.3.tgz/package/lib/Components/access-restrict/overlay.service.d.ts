import * as i0 from "@angular/core";
export interface Controller {
    Title: string;
    Message: string;
    ButtonTitle: string;
    ButtonAction: string;
}
export declare class AccessRestrictOverlayService {
    private isVisibleSubject;
    isVisible$: import("rxjs").Observable<boolean>;
    private ControllerSubject;
    Controller$: import("rxjs").Observable<Controller>;
    updateController(controller: Controller): void;
    showOverlay(): void;
    hideOverlay(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccessRestrictOverlayService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccessRestrictOverlayService>;
}
