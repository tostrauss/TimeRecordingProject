import { AccessRestrictOverlayService, Controller } from './overlay.service';
import * as i0 from "@angular/core";
export declare class AccessRestrictComponent {
    private overlayService;
    constructor(overlayService: AccessRestrictOverlayService);
    isVisible: import("rxjs").Observable<boolean>;
    Controller: import("rxjs").Observable<Controller>;
    title: string;
    message: string;
    buttonTitle: string;
    buttonAction: string;
    ngOnInit(): void;
    Close(): void;
    GoToURL(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccessRestrictComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccessRestrictComponent, "access-restrict", never, {}, {}, never, never, false, never>;
}
