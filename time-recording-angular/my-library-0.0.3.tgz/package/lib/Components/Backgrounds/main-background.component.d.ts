import { OnDestroy, OnInit } from '@angular/core';
import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
export declare class BackgroundComponent implements OnInit, OnDestroy {
    private userService;
    BackgroundImage: string;
    PhotoOnly: boolean;
    userSubscription: any;
    constructor(userService: IndexedDBService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BackgroundComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BackgroundComponent, "background", never, { "BackgroundImage": { "alias": "BackgroundImage"; "required": false; }; }, {}, never, never, false, never>;
}
