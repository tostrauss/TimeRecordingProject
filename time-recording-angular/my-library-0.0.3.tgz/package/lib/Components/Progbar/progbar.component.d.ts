import * as i0 from "@angular/core";
export declare class ProgbarComponent {
    total: number;
    current: number;
    get percentage(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgbarComponent, "app-progress-bar", never, { "total": { "alias": "total"; "required": false; }; "current": { "alias": "current"; "required": false; }; }, {}, never, never, false, never>;
}
