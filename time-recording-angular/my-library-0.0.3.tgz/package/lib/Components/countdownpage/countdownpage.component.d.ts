import * as i0 from "@angular/core";
export declare class CountdownpageComponent {
    targetDate: Date;
    Title: string;
    Description: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CountdownpageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CountdownpageComponent, "app-countdownpage", never, { "targetDate": { "alias": "targetDate"; "required": false; }; "Title": { "alias": "Title"; "required": false; }; "Description": { "alias": "Description"; "required": false; }; }, {}, never, never, false, never>;
}
