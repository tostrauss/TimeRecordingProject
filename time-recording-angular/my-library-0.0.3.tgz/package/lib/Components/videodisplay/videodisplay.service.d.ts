import * as i0 from "@angular/core";
export declare class VideodisplayService {
    constructor();
    changeUserVideo(videoUrl: string, attempt?: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VideodisplayService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VideodisplayService>;
}
