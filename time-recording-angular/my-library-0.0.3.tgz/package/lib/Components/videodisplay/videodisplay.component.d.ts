import { OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { FormService } from '../../Functions_Forms';
import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
export declare class VideodisplayComponent implements OnInit, OnChanges {
    private sanitizer;
    private formService;
    private userService;
    videoLink: string;
    autoplay: boolean;
    VideoSrc: 'External' | 'Internal';
    Domain: string;
    safeVideoLink: SafeResourceUrl;
    constructor(sanitizer: DomSanitizer, formService: FormService, userService: IndexedDBService);
    VideoIcon: string;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    filterVideoLink(url: string): SafeResourceUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<VideodisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VideodisplayComponent, "app-videodisplay", never, { "videoLink": { "alias": "videoLink"; "required": false; }; "autoplay": { "alias": "autoplay"; "required": false; }; }, {}, never, never, false, never>;
}
