import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class LoadingSpinnerService {
    private _spinner$;
    spinner$: Observable<boolean>;
    setSpinner(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingSpinnerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoadingSpinnerService>;
}
