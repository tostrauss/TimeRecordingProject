import { OnInit } from '@angular/core';
import { LoadingSpinnerService } from './LoadingSpinner';
import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
export declare class LoadingSpinnerComponent implements OnInit {
    private LoadingSpinner;
    private userService;
    isLoading: boolean;
    constructor(LoadingSpinner: LoadingSpinnerService, userService: IndexedDBService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingSpinnerComponent, "app-loadingspinner", never, { "isLoading": { "alias": "isLoading"; "required": false; }; }, {}, never, never, false, never>;
}
