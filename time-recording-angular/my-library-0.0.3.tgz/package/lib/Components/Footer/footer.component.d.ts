import { OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IndexedDBService } from '../../Functions_USession';
import { Subscription } from 'rxjs';
import * as i0 from "@angular/core";
export declare class FooterComponent implements OnInit, OnDestroy {
    View: Router;
    private router;
    private userService;
    isLoggedIn: boolean;
    Show: boolean;
    home: string;
    meet: string;
    guide: string;
    settings: string;
    chat: string;
    buttons: Array<{
        icon: string;
        label: string;
        route: string;
        active: boolean;
    }>;
    userSubscription: Subscription;
    routerSubscription: Subscription;
    constructor(View: Router, router: Router, userService: IndexedDBService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    route(destination: string): void;
    private updateActiveButton;
    trackByFunction(index: number, button: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FooterComponent, "hub-footer", never, { "Show": { "alias": "Show"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; }, {}, never, never, false, never>;
}
