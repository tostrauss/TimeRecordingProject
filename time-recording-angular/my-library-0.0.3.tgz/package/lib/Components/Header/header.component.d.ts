import { OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { IndexedDBService } from '../../Functions_USession';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
interface DropdownOption {
    Icon: string;
    Title: string;
    func: () => void;
}
export declare class HeaderComponent implements OnInit, OnDestroy {
    private router;
    private userService;
    private renderer;
    constructor(router: Router, userService: IndexedDBService, renderer: Renderer2);
    User: any;
    isLoggedIn: boolean;
    private userSubscription;
    logo: string;
    title: string;
    private ignoreClickOutside;
    Show: boolean;
    UserName: string | null;
    appsOutline: string;
    login: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    setting: {
        settings: {
            path: string;
            canActivate: boolean;
        };
        account: {
            path: string;
            canActivate: boolean;
        };
        profile: {
            path: string;
            canActivate: boolean;
        };
        help: {
            path: string;
            canActivate: boolean;
        };
    };
    SettingDropdownOptions: any;
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleDropdown(): void;
    handleClickOutside(event: Event): void;
    generateNavigationArray(items: string[]): DropdownOption[];
    home(): void;
    Login_(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderComponent, "hub-header", never, { "Show": { "alias": "Show"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
