import { OnInit, OnChanges, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormService } from '../../../Functions_Forms';
import * as i0 from "@angular/core";
export interface InputConstructor {
    Title: string;
    Name: string;
    Type: string;
    Vars: any;
    Style: string;
    Category: string;
    Placeholder?: string;
    Span?: string;
}
export declare class FormCreatorComponent implements OnInit, OnChanges {
    private cdr;
    private formService;
    InputItem: InputConstructor;
    formGroup: FormGroup;
    labelStyle: string;
    videoLink: string;
    showVideo: boolean;
    constructor(cdr: ChangeDetectorRef, formService: FormService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateVideoLink(url: string): void;
    onInputChange(event: Event): void;
    isInvalid(entry: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormCreatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormCreatorComponent, "form-creator", never, { "InputItem": { "alias": "InputItem"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "labelStyle": { "alias": "labelStyle"; "required": false; }; }, {}, never, never, false, never>;
}
