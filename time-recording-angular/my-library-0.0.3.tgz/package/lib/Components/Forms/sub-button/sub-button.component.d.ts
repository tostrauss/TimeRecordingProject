import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FormSubButtonComponent {
    ButtonTitle: string;
    buttonClicked: EventEmitter<void>;
    onButtonClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormSubButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormSubButtonComponent, "formSubButton", never, { "ButtonTitle": { "alias": "ButtonTitle"; "required": false; }; }, { "buttonClicked": "buttonClicked"; }, never, never, false, never>;
}
