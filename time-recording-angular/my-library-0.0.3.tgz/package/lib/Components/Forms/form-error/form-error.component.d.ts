import { AbstractControl, FormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class FormErrorComponent {
    control?: AbstractControl | null;
    private errorMessages;
    getErrors(control?: AbstractControl<any, any> | null | undefined): string[];
    getErrorMessage(error: string): string;
    displayErrorMessage(errorKey: string, errorParams: any): string;
    getAllErrorMessages(form: FormGroup): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormErrorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormErrorComponent, "formErrorMessage", never, { "control": { "alias": "control"; "required": false; }; }, {}, never, never, false, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormErrorComponent>;
}
