import { Router } from '@angular/router';
import { IndexedDBService } from '../../Functions_USession';
import * as i0 from "@angular/core";
export declare class LogoBoxComponent {
    private userService;
    private View;
    styling?: string;
    Boxstyling?: string;
    AltText: string;
    Logo: string;
    TagOn: boolean;
    Tag: string;
    userSubscription: any;
    constructor(userService: IndexedDBService, View: Router);
    ngOnInit(): void;
    ngOnDestroy(): void;
    changeView(view: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoBoxComponent, "logo-box", never, { "styling": { "alias": "styling"; "required": false; }; "Boxstyling": { "alias": "Boxstyling"; "required": false; }; "AltText": { "alias": "AltText"; "required": false; }; "Logo": { "alias": "Logo"; "required": false; }; "TagOn": { "alias": "TagOn"; "required": false; }; }, {}, never, never, false, never>;
}
