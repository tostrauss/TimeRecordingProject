import { Type } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './Functions_API';
import { IndexedDBService } from './Functions_USession';
import { SplashHandlingService } from './Components/SplashPage/SplashService';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import * as i0 from "@angular/core";
export declare var ROUTE_CONFIG: RouteInfo[];
interface GlobalConfig {
    G_BusName: string;
}
export interface RouteInfo {
    path: string;
    component: any;
    children?: any;
    canActivate?: any[];
    RestrictAcess?: boolean;
}
export declare class GlobalInitializer {
    private HTTPCall;
    private Splash;
    private userService;
    private router;
    constructor(HTTPCall: ApiService, Splash: SplashHandlingService, userService: IndexedDBService, router: Router);
    private Trig;
    private _Globals$;
    GLOBALS$: Observable<any>;
    private Debug;
    private userSubscription;
    initGlobals(GLOBALS_App: any, Routes: any, Key: any): Observable<GlobalConfig>;
    initializeRoutes(): void;
    addRoute(path: string | {
        [key: string]: {
            path: string;
            canActivate: boolean;
        };
    }, component: Type<any>, authGuard?: any, children?: any): void;
    getRoutes(): RouteInfo[];
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GlobalInitializer>;
}
export declare class AuthGuard implements CanActivate {
    private userService;
    private View;
    private route;
    constructor(userService: IndexedDBService, View: Router, route: ActivatedRoute);
    key: {
        login: {
            path: string;
            canActivate: boolean;
        };
        logout: {
            path: string;
            canActivate: boolean;
        };
        createAccount: {
            path: string;
            canActivate: boolean;
        };
        forgotPassword: {
            path: string;
            canActivate: boolean;
        };
        passwordReset: {
            path: string;
            canActivate: boolean;
        };
    };
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthGuard>;
}
export {};
