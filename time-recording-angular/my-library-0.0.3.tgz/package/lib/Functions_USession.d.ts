import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { LoginTokenInterface } from './login/Login/LoginTokenInterface';
import * as i0 from "@angular/core";
export declare class IndexedDBService {
    private router;
    private dbName;
    private dbVersion;
    private db;
    private userData;
    USERDATA$: Observable<any>;
    constructor(router: Router);
    private initializeDB;
    private storeData;
    getData(id?: number): Promise<any>;
    updateSession(token: any, id?: number): Promise<{
        Success: boolean;
    }>;
    clearData(): Promise<void>;
    createSession(token: any, id?: number): Promise<void>;
    loginSession(token: LoginTokenInterface): Promise<void>;
    logoutSession(): Promise<void>;
    isLoggedIn(RestrictData?: {
        Title: string;
        Message: string;
        ButtonTitle: string;
        ButtonAction: string;
    } | null): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IndexedDBService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IndexedDBService>;
}
