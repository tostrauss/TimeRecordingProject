import { OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { ErrorHandlingService } from './Components/Error/ErrorHandling_Service';
import { LoadingSpinnerService } from './Components/LoadingSpinner/LoadingSpinner';
import { SplashHandlingService } from './Components/SplashPage/SplashService';
import { IndexedDBService } from './Functions_USession';
import * as i0 from "@angular/core";
export interface DataInterface {
    Message: string;
    Success: boolean;
    Token?: any;
    Action?: string;
    Url?: string;
    Timer?: number;
}
export declare class ApiService implements OnDestroy {
    private http;
    private ErrorHandling;
    private Spinner;
    private router;
    private Splash;
    private userService;
    constructor(http: HttpClient, ErrorHandling: ErrorHandlingService, Spinner: LoadingSpinnerService, router: Router, Splash: SplashHandlingService, userService: IndexedDBService);
    private Debug;
    private userSubscription;
    private ApiErrorMessage;
    private ApiLink;
    ngOnDestroy(): void;
    TakeAction(data: any, Restrict?: boolean | {
        Title: string;
        Message: string;
        ButtonTitle: string;
        ButtonAction: string;
    }, Headers?: {}, url?: string): Observable<DataInterface>;
    private ResponseAction;
    post(data: any, Call: string, Extra?: {}, url?: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApiService>;
}
