import { OnDestroy } from '@angular/core';
import { AbstractControl, FormGroup, FormControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { ErrorHandlingService } from './Components/Error/ErrorHandling_Service';
import { ApiService } from './Functions_API';
import { Observable } from 'rxjs';
import { IndexedDBService } from './Functions_USession';
import { FormErrorComponent } from './Components/Forms/form-error/form-error.component';
import { KeysComponent } from './KEYS';
import * as i0 from "@angular/core";
export declare class FormService implements OnDestroy {
    private ErrorHandling;
    private HTTPCall;
    private userService;
    private FormError;
    private Keys;
    http: any;
    constructor(ErrorHandling: ErrorHandlingService, HTTPCall: ApiService, userService: IndexedDBService, FormError: FormErrorComponent, Keys: KeysComponent);
    private Debug;
    private userSubscription;
    ngOnDestroy(): void;
    private HoneyPot;
    isInvalid(control: AbstractControl | null): boolean;
    ValidatePassword(control: FormControl): {
        [key: string]: boolean;
    } | null;
    ValidateName: ValidatorFn;
    CheckPassword(control: FormGroup): {
        [key: string]: boolean;
    } | null;
    CheckEmail(Form: FormGroup, ControlName: string): Observable<{
        emExError: true;
    } | null>;
    CheckExpirationDate(): ValidatorFn;
    CheckDisname(Form: FormGroup, ControlName: string): Observable<{
        disNameError: true;
    } | null>;
    FormValid(FormData: FormGroup): boolean;
    ValidateYoutubeLink(control: FormControl): {
        [key: string]: boolean;
    } | null;
    getYouTubeEmbedUrl_Library(videoUrl: string): string;
    ValidateLink(control: AbstractControl): ValidationErrors | null;
    submitForm(Form: FormGroup, Caller: string, Restrict?: boolean): Promise<any>;
    updateInfo(ProfileForm: FormGroup): Promise<any>;
    onSubmit(Form: FormGroup, Caller: string): Promise<boolean>;
    getTouchedAndDirtyValues(form: FormGroup): any;
    US_States: string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<FormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormService>;
}
export declare var US_States: string[];
