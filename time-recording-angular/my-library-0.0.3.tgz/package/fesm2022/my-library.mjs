import * as i0 from '@angular/core';
import { Injectable, Component, Input, ViewChild, HostListener, EventEmitter, Output, NgModule } from '@angular/core';
import { BehaviorSubject, of, map as map$1, firstValueFrom, take as take$1, catchError as catchError$1, finalize, Observable } from 'rxjs';
import * as i1 from '@angular/router';
import { NavigationEnd } from '@angular/router';
import * as i3 from '@angular/common';
import { NgOptimizedImage } from '@angular/common';
import * as i1$2 from '@angular/forms';
import { Validators, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i4 from '@ionic/angular';
import { IonicModule } from '@ionic/angular';
import { eyeOffOutline, eyeOutline, keyOutline, logInOutline, mailOutline, checkmark, cameraReverseOutline, videocamOff, lockClosed, closeCircle, arrowForwardOutline, arrowBackOutline, star, checkmarkOutline, home, peopleOutline, informationCircleOutline, settingsOutline, chatbubblesOutline, appsOutline, arrowDown, arrowUp, shareSocialOutline } from 'ionicons/icons';
import { take, catchError, map, switchMap, filter } from 'rxjs/operators';
import * as i1$1 from '@angular/common/http';
import { HttpHeaders, HttpClientModule } from '@angular/common/http';
import * as i1$3 from '@angular/platform-browser';
import { BrowserModule } from '@angular/platform-browser';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

var lRouteKey = {
    login: { path: 'login', canActivate: false },
    logout: { path: 'logout', canActivate: true },
    createAccount: { path: 'create-account', canActivate: true },
    forgotPassword: { path: 'forgot-password', canActivate: true },
    passwordReset: { path: 'password-reset', canActivate: true }
};

class IndexedDBService {
    constructor(router) {
        this.router = router;
        this.dbName = 'myDatabase';
        this.dbVersion = 1;
        this.db = null;
        this.userData = new BehaviorSubject(null);
        this.USERDATA$ = this.userData.asObservable();
        this.getData(); // add update of user info // calls to populate user data on component constructor 
    }
    async initializeDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);
            request.onupgradeneeded = (event) => {
                this.db = event.target.result;
                this.db.createObjectStore('myObjectStore', { keyPath: 'id' });
                resolve();
            };
            request.onsuccess = (event) => {
                this.db = event.target.result;
                resolve();
            };
            request.onerror = (event) => reject(event);
        });
    }
    async storeData(data) {
        await this.initializeDB();
        if (this.db) {
            const transaction = this.db.transaction(['myObjectStore'], 'readwrite');
            const store = transaction.objectStore('myObjectStore');
            await store.put(data);
            this.userData.next(data.value);
        }
    }
    async getData(id = this.dbVersion) {
        await this.initializeDB();
        if (this.db) {
            const transaction = this.db.transaction(['myObjectStore'], 'readonly');
            const store = transaction.objectStore('myObjectStore');
            const request = store.get(id);
            return new Promise((resolve, reject) => {
                request.onsuccess = () => {
                    if (request.result) {
                        resolve(request.result.value);
                        this.userData.next(request.result.value); // added to synchroinize user data to one variable 8/13/24
                    }
                    else {
                        resolve(null); // Resolve with null if no data is found
                    }
                };
                request.onerror = () => reject(request.error);
            });
        }
        return null;
    }
    async updateSession(token, id = this.dbVersion) {
        const data = await this.getData(id);
        if (data) {
            const updatedData = { ...data, ...token };
            await this.storeData({ id, value: updatedData });
            this.userData.next(updatedData);
            return { Success: true };
        }
        return { Success: false };
    }
    async clearData() {
        await this.initializeDB();
        if (this.db) {
            const transaction = this.db.transaction(['myObjectStore'], 'readwrite');
            const store = transaction.objectStore('myObjectStore');
            await store.clear();
            this.userData.next(null);
        }
    }
    // SPECIFICALLY FOR USE IN INITIALIZER OF GLOBALS AND APP SETTINGS
    async createSession(token, id = this.dbVersion) {
        const data = await this.getData(id);
        if (data) {
            await this.updateSession(token);
        }
        else {
            await this.storeData({ id: id, value: token });
        }
    }
    async loginSession(token) {
        const sessionID = this.dbVersion;
        const data = await this.getData(sessionID);
        if (data) {
            await this.updateSession(token);
            //this.userData.next(token);
        }
        else {
            await this.storeData({ id: sessionID, value: token });
            //this.userData.next(token);
        }
    }
    async logoutSession() {
        // get data and update status to offline
        const data = await this.getData();
        const remember = data.rememberme ?? false;
        if (remember) {
            // if user wants to remember session, then just update status to offline and leave data for offline browsing 
            // NEED TO COMPLETE FRONTEND LOGIC FOR WHEN USER TRIES TO LOGIN AND IS OFFLINE BUT HAS SESSION SAVED
            await this.updateSession({ STATUS: 'Offline' });
        }
        else {
            // if user does not want to remember session, then clear all data
            const CONFIG = data.CONFIG;
            const Call = data.CALL;
            await this.clearData();
            await this.createSession({ CONFIG: CONFIG, CALL: Call }); // reapply necessary data for smooth UI flow
        }
    }
    // public async isLoggedIn(): Promise<boolean> {
    //   const data = await this.getData();
    //   return data ? data.STATUS !== 'Offline' : false;
    // }
    async isLoggedIn(RestrictData = null) {
        const data = await this.getData();
        let LoggedIn = data ? data.STATUS === 'Online' : false;
        if (RestrictData && !LoggedIn) {
            // this.overlayService.updateController(RestrictData);
            // this.overlayService.showOverlay();
        }
        return LoggedIn;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IndexedDBService, deps: [{ token: i1.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IndexedDBService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IndexedDBService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i1.Router }]; } });

class BackgroundComponent {
    constructor(userService) {
        this.userService = userService;
        this.PhotoOnly = true;
    }
    ngOnInit() {
        if (!this.BackgroundImage) {
            this.userSubscription = this.userService.USERDATA$.subscribe((userData) => {
                let SettingCheck = userData ? userData.CONFIG : null;
                if (SettingCheck) {
                    this.BackgroundImage = userData.CONFIG.BackgroundImage;
                }
            });
        }
    }
    ngOnDestroy() {
        // Unsubscribe to prevent memory leaks
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: BackgroundComponent, deps: [{ token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: BackgroundComponent, selector: "background", inputs: { BackgroundImage: "BackgroundImage" }, ngImport: i0, template: "<div *ngIf=\"!PhotoOnly\" class=\"Holder Top Fade_IN Grow_Height Grow_Width\">\n    <div class=\"Holder Main\" style=\"background-image: url('{{BackgroundImage}}');\">\n    </div>\n    <div class=\"ClipPath Holder InnerL\">\n\n    </div>\n    <div class=\"ClipPath Holder InnerL InnerLCoupled\">\n\n    </div>\n\n    <div class=\"ClipPath Holder InnerBack blink\">\n\n    </div>\n\n    <div class=\"ClipPath Holder InnerR\">\n\n    </div>\n\n</div>\n\n<div style=\"background: black;\">\n    <div *ngIf=\"PhotoOnly\" class=\"Holder  Fade_IN Grow_Height Grow_Width\">\n        <div class=\"Holder Main\" style=\"background-image: url('{{BackgroundImage}}');\">\n        </div>\n    </div>\n</div>", styles: [".Holder{display:flex;flex-direction:column;height:100vh;width:100vw;overflow:hidden;z-index:-4;background-position:center;background-size:cover;position:fixed;top:0}.ClipPath{clip-path:polygon(0% 0%,9.2% 19%,20.8% 34.1%,54.8% 44.1%,73% 67.6%,100.2% 63.1%,100.2% 100%,0% 100%)}.Top{opacity:1;transform:rotate(45deg) scale(1.5)}.Main{transform:rotate(360deg);opacity:.2}.InnerL{background:#ffffffc9;z-index:-1}.InnerLCoupled{z-index:-2;background-color:#e1f24c4f;margin-right:5px;margin-top:-5px}.InnerR{background:#fff;z-index:-3;transform:rotate(360deg) scaleY(-1)}.InnerBack{background:linear-gradient(to right,var(--Color),var(--Color2))}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: BackgroundComponent, decorators: [{
            type: Component,
            args: [{ selector: 'background', template: "<div *ngIf=\"!PhotoOnly\" class=\"Holder Top Fade_IN Grow_Height Grow_Width\">\n    <div class=\"Holder Main\" style=\"background-image: url('{{BackgroundImage}}');\">\n    </div>\n    <div class=\"ClipPath Holder InnerL\">\n\n    </div>\n    <div class=\"ClipPath Holder InnerL InnerLCoupled\">\n\n    </div>\n\n    <div class=\"ClipPath Holder InnerBack blink\">\n\n    </div>\n\n    <div class=\"ClipPath Holder InnerR\">\n\n    </div>\n\n</div>\n\n<div style=\"background: black;\">\n    <div *ngIf=\"PhotoOnly\" class=\"Holder  Fade_IN Grow_Height Grow_Width\">\n        <div class=\"Holder Main\" style=\"background-image: url('{{BackgroundImage}}');\">\n        </div>\n    </div>\n</div>", styles: [".Holder{display:flex;flex-direction:column;height:100vh;width:100vw;overflow:hidden;z-index:-4;background-position:center;background-size:cover;position:fixed;top:0}.ClipPath{clip-path:polygon(0% 0%,9.2% 19%,20.8% 34.1%,54.8% 44.1%,73% 67.6%,100.2% 63.1%,100.2% 100%,0% 100%)}.Top{opacity:1;transform:rotate(45deg) scale(1.5)}.Main{transform:rotate(360deg);opacity:.2}.InnerL{background:#ffffffc9;z-index:-1}.InnerLCoupled{z-index:-2;background-color:#e1f24c4f;margin-right:5px;margin-top:-5px}.InnerR{background:#fff;z-index:-3;transform:rotate(360deg) scaleY(-1)}.InnerBack{background:linear-gradient(to right,var(--Color),var(--Color2))}\n"] }]
        }], ctorParameters: function () { return [{ type: IndexedDBService }]; }, propDecorators: { BackgroundImage: [{
                type: Input
            }] } });

class LogoBoxComponent {
    constructor(userService, View) {
        this.userService = userService;
        this.View = View;
        this.TagOn = false;
    }
    ngOnInit() {
        this.userSubscription = this.userService.USERDATA$.subscribe((userData) => {
            let SettingCheck = userData ? userData.CONFIG : null;
            if (SettingCheck) {
                this.Logo = this.Logo ?? userData.CONFIG.LOGO;
                this.AltText = this.AltText ?? userData.CONFIG.BUSName + ' Logo - ' + userData.CONFIG.BUSTag;
                this.Tag = userData.CONFIG.BUSTag;
            }
        });
    }
    ngOnDestroy() {
        // Unsubscribe to prevent memory leaks
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
    }
    changeView(view) {
        this.View.navigate(['/' + view]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LogoBoxComponent, deps: [{ token: IndexedDBService }, { token: i1.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LogoBoxComponent, selector: "logo-box", inputs: { styling: "styling", Boxstyling: "Boxstyling", AltText: "AltText", Logo: "Logo", TagOn: "TagOn" }, ngImport: i0, template: "<div (click)=\"changeView('')\" [style]=\"Boxstyling\" class=\"LogoBox\">\n    <img [style]=\"styling\" [src]=\"Logo\" [alt]=\"AltText\">\n    <span *ngIf=\"TagOn\">{{Tag}}</span>\n</div>", styles: [".LogoBox{text-align:center;margin:auto;cursor:pointer}.LogoBox img{width:120px}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LogoBoxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'logo-box', template: "<div (click)=\"changeView('')\" [style]=\"Boxstyling\" class=\"LogoBox\">\n    <img [style]=\"styling\" [src]=\"Logo\" [alt]=\"AltText\">\n    <span *ngIf=\"TagOn\">{{Tag}}</span>\n</div>", styles: [".LogoBox{text-align:center;margin:auto;cursor:pointer}.LogoBox img{width:120px}\n"] }]
        }], ctorParameters: function () { return [{ type: IndexedDBService }, { type: i1.Router }]; }, propDecorators: { styling: [{
                type: Input
            }], Boxstyling: [{
                type: Input
            }], AltText: [{
                type: Input
            }], Logo: [{
                type: Input
            }], TagOn: [{
                type: Input
            }] } });

class KeysComponent {
    constructor() {
        this.UEditKey = 'uEd1t';
        this.ProPhoto = 'Phot0_up';
        this.UExtra_EditKey = 'U3dit3tra';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: KeysComponent, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: KeysComponent, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: KeysComponent, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class ErrorHandlingService {
    constructor() {
        this._error$ = new BehaviorSubject(null);
        this.error$ = this._error$.asObservable();
    }
    setError(ErrorData) {
        if (ErrorData.Message !== null) {
            this._error$.next(ErrorData);
        }
        return ErrorData;
    }
    clearError() {
        this._error$.next(null);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ErrorHandlingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ErrorHandlingService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ErrorHandlingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class LoadingSpinnerService {
    constructor() {
        this._spinner$ = new BehaviorSubject(false);
        this.spinner$ = this._spinner$.asObservable();
    }
    setSpinner(value) {
        this._spinner$.next(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingSpinnerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingSpinnerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingSpinnerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class SplashHandlingService {
    constructor() {
        this._splash$ = new BehaviorSubject(false);
        this.splash$ = this._splash$.asObservable();
    }
    setSplash() {
        this._splash$.next(true);
    }
    unsetSplashPage() {
        this._splash$.next(false); // delay is set on individual pathway API Fumnc
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SplashHandlingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SplashHandlingService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SplashHandlingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

/*
  API Service Helper Functions
  Gateway to API Calls
  Updated: 4/7/24
  ________________________________

*/
// export interface TakeActionParams {
//     data: any;
//     Restrict?: boolean | { Title: string; Message: string; ButtonTitle: string; ButtonAction: string };
//     Headers?: any;
//     url?: string;
// }
class ApiService {
    constructor(http, ErrorHandling, Spinner, router, Splash, userService) {
        this.http = http;
        this.ErrorHandling = ErrorHandling;
        this.Spinner = Spinner;
        this.router = router;
        this.Splash = Splash;
        this.userService = userService;
        this.ApiErrorMessage = "Unable to process request. Please try again later.";
        this.userSubscription = this.userService.USERDATA$.subscribe((userData) => {
            //this.User = userData;
            let SettingCheck = userData ? userData.CONFIG : null;
            if (SettingCheck) {
                this.Debug = userData.CONFIG.DEBUG;
                this.ApiLink = userData.CONFIG.URL + userData.CONFIG.API;
            }
        });
    }
    ngOnDestroy() {
        // Unsubscribe to prevent memory leaks
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
    }
    // New POST Function replacement - phasing in as of 8/19/24
    TakeAction(data, Restrict = false, Headers = {}, url = this.ApiLink) {
        // DISPLAY ACTIONS - setup ////////////////////////////////////////////////
        this.Spinner.setSpinner(true); // spinner always runs to show loading
        // REQUIRED VARS //////////////////////////////////////////
        // API Caller //
        if (!(data.CALL)) {
            this.Spinner.setSpinner(false);
            return of(this.ErrorHandling.setError({ Success: false, Message: "Error Purple Band: Server Caller Unauthorized. " }));
        }
        // ACCESS RESTRICTION
        if (Restrict) {
            // USE DEFAULT ASSIGNMENT IF TRUE
            if (Restrict == true) {
                Restrict = { Title: 'Access Restricted', Message: 'Error Yellow Band: Not Logged In', ButtonTitle: 'Login', ButtonAction: 'login' }; // run default
            }
            // UNTESTED RESTRICTION
            let LoggedIn = this.userService.isLoggedIn(Restrict);
            if (!LoggedIn) {
                this.Spinner.setSpinner(false);
                return of(this.ErrorHandling.setError({ Success: false, Message: "Error Green Band: Restricted feature. " }));
                ;
            }
            // User Vars // Get USER - NEW INITIATIVE 8/13
            let User;
            this.userService.USERDATA$.pipe(take(1)).subscribe((UserData) => {
                User = UserData;
                data.Sub = UserData.Ky ?? null;
                // had it send Email mandatory but now removing 
                // if(!(data.Email)) {
                //     data.Email = UserData.Email;
                // }
            });
            // Catch Error
            if (!(data.Sub)) {
                this.Spinner.setSpinner(false);
                return of(this.ErrorHandling.setError({ Success: false, Message: "Error Orange Band:" + this.ApiErrorMessage }));
            }
        }
        // DEBUG //////////////////////////////////////////
        if (this.Debug === true) {
            console.log("Data Sent: ", data);
        }
        // Check Offline or not - not yet implemented 
        // Return Observable
        // let API_Response: {Message: string, Success: boolean, Token: any};
        return this.http.post(url, data, (Headers ?? new HttpHeaders().set('Content-Type', 'application/json'))).pipe(catchError((error) => {
            // DEBUG /////////////////////////////////////////////////
            if (this.Debug === true) {
                console.log("Data Returned ERROR: ", [{ Data: data }, { Error: error.error }]);
            }
            // DISPLAY ACTIONS - resolve ////////////////////////////////////////////////
            this.Spinner.setSpinner(false);
            // ERROR HANDLING /////////////////////////////////////////////////
            let errorMessage = "Malformed request. Internet Error (potentially offline). ";
            if (error.status === 500) {
                errorMessage = "Server Error 500: Internal Request Error. ";
            }
            let errorOutput = { Success: false, Message: errorMessage + this.ApiErrorMessage };
            this.ErrorHandling.setError(errorOutput);
            // // Log specific network errors
            // was attemtping to have this specifically state if it was a network error related to not connected to the internet and if so to return an action that triggers a message to the user of false or something like that
            // if (error.error instanceof ErrorEvent) {
            //     console.error('Client-side error:', error.error.message);
            //   } else {
            //     console.error('Server-side error:', error.message);
            //   }
            return of(errorOutput); // error.error not used needed but when removed casues error 
        }), map((response) => {
            // DEBUG /////////////////////////////////////////////////
            if (this.Debug === true) {
                console.log("Data Returned:", response);
            }
            // DISPLAY ACTIONS - resolve ////////////////////////////////////////////////
            this.Spinner.setSpinner(false);
            // Display User Notice ////////////////////////////////////////////////////
            this.ErrorHandling.setError(response);
            // DATA PARSE - Filter For Actions
            if (typeof (response) == 'string') {
                let _output = response;
                try {
                    response = JSON.parse(_output);
                }
                catch (error) {
                    return { Success: false, Message: "FE 500 Error" };
                }
            }
            // RETURN ACTIONS
            this.ResponseAction(response); // considering revamping this as well 
            return response;
        }));
    }
    // HANDLE ACTION RESPONSE FROM SERVER 
    // Eventually will change to allow offline access
    ResponseAction(response) {
        // Allows Server to send frontend actions to client
        if (response.Action) {
            // Actions
            setTimeout(async () => {
                switch (response.Action?.toUpperCase()) {
                    case "LOGOUT":
                        /*
                            In use for Session Key fail authentication - log user in again with new key (update data with new key)
                            Eventually handle new login on backend token to frontend
                        */
                        await this.userService.logoutSession();
                        location.reload(); // refresh the window - AUTH GUARD handles redirect
                        break;
                    // NOT YET MERGED TO NEW API CALL (BELOW)
                    case "LOGIN":
                        //this.Splash.setSplash();
                        //setTimeout(() => { this.Splash.unsetSplashPage(); }, 4000); // extend duration for full effect
                        await this.userService.loginSession(response.Token); // set user session
                        this.router.navigate(['/']);
                        break;
                    case "sec_reg":
                        // possibly no longer in use **
                        this.router.navigate(['/' + response.Url]);
                        break;
                    case "Redirect":
                        // backend can control redirect status 
                        this.router.navigate(['/' + response.Url]);
                        break;
                    default:
                        this.router.navigate(['/' + response.Url]);
                        break;
                }
            }, (response.Timer ?? 0)); // o second
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////
    // OLD VERSION POST - PHASING OUT AS OF 8/19/24
    post(data, Call, Extra = {}, url = this.ApiLink) {
        // Set Display Actions
        this.Spinner.setSpinner(true); // spinner always runs to show loading
        // Setup Required Vars 
        data.CALL = Call ?? null;
        if (!(data.CALL)) {
            this.ErrorHandling.setError({ Success: false, Message: "The server was not able to process the request" });
            return of(false);
        }
        // DEBUG
        if (this.Debug === true) {
            console.log("Data In: ", data);
        }
        // Check Offline or not
        return this.http.post(url, data, (Extra ?? new HttpHeaders().set('Content-Type', 'application/json'))).pipe(catchError((error) => {
            // DEBUG
            if (this.Debug === true) {
                console.log("Data Out: ", data);
            }
            // Resolve Display Actions
            this.Spinner.setSpinner(false);
            // ERROR HANDLING
            this.ErrorHandling.setError({ Success: false, Message: this.ApiErrorMessage });
            return error.error; // error.error not used needed but when removed casues error 
        }), map((response) => {
            // DEBUG
            if (this.Debug === true) {
                console.log("Data Out: ", response);
            }
            // LOADER - For user viewing loader
            this.Spinner.setSpinner(false);
            // DATA PARSE - Filter For Actions
            if (typeof (response) == 'string') {
                let _output = response;
                try {
                    response = JSON.parse(_output);
                    // RETURN ACTIONS
                    this.ResponseAction(response);
                    return response;
                }
                catch (error) {
                    return { Success: false, Message: "FE 500 Error" };
                }
            }
            // RETURN ACTIONS
            this.ResponseAction(response);
            return response;
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiService, deps: [{ token: i1$1.HttpClient }, { token: ErrorHandlingService }, { token: LoadingSpinnerService }, { token: i1.Router }, { token: SplashHandlingService }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ApiService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i1$1.HttpClient }, { type: ErrorHandlingService }, { type: LoadingSpinnerService }, { type: i1.Router }, { type: SplashHandlingService }, { type: IndexedDBService }]; } });

class FormErrorComponent {
    constructor() {
        this.errorMessages = {
            // Add index signature
            required: 'This field is required. ',
            minlength: (params) => `Minimum length is ${params.requiredLength}. `,
            maxlength: (params) => `Maximum length is ${params.requiredLength}. `,
            email: 'Invalid email format. ',
            emailExists: 'Email invalid or already in use. Choose another.',
            invalidPassword: 'Password must be minimum 8 characters, maximum 50 characters, and must contain at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character ($@$!%*?&). NO PERIODS ALLOWED',
            invalidPasswordMatch: 'Passwords do not match.',
            disNameError: 'Display name unavailable. Choose another. ',
            emExError: 'Email invalid or already in use. Choose another. ',
            invalidName: 'Invalid name - cannot contain blank spaces or symbols. ',
            invalidLink: 'Invalid URL. ',
        };
    }
    getErrors(control = this.control) {
        return Object.keys(control?.errors || {});
    }
    getErrorMessage(error) {
        const errorParams = this.control?.errors?.[error]; // Handle null possibility
        const errorMessage = this.errorMessages[error];
        return typeof errorMessage === 'function'
            ? errorMessage(errorParams)
            : errorMessage;
    }
    displayErrorMessage(errorKey, errorParams) {
        const errorMessage = this.errorMessages[errorKey];
        return typeof errorMessage === 'function'
            ? errorMessage(errorParams)
            : errorMessage;
    }
    getAllErrorMessages(form) {
        let errorMessages = [];
        Object.keys(form.controls).forEach(key => {
            const control = form.get(key);
            if (control && control.errors) {
                Object.keys(control.errors).forEach(errorKey => {
                    const errorParams = control.errors ? control.errors[errorKey] : null;
                    const translatedError = this.displayErrorMessage(errorKey, errorParams);
                    errorMessages.push(translatedError);
                });
            }
        });
        return errorMessages.join('\n');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormErrorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FormErrorComponent, selector: "formErrorMessage", inputs: { control: "control" }, ngImport: i0, template: "<div *ngIf=\"control?.invalid && (control?.dirty || control?.touched)\">\n    <span *ngFor=\"let error of getErrors()\" style=\"color: red\">{{ getErrorMessage(error) }}</span>\n  </div>\n", styles: [""], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormErrorComponent, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormErrorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'formErrorMessage', template: "<div *ngIf=\"control?.invalid && (control?.dirty || control?.touched)\">\n    <span *ngFor=\"let error of getErrors()\" style=\"color: red\">{{ getErrorMessage(error) }}</span>\n  </div>\n" }]
        }, {
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], propDecorators: { control: [{
                type: Input
            }] } });

/*
    FORM FUNCTIONS
    V1.0 - created 3/24/24
    This File will house all form related functions that will be used with form HTML and TS files.
*/
class FormService {
    constructor(ErrorHandling, HTTPCall, userService, FormError, Keys) {
        this.ErrorHandling = ErrorHandling;
        this.HTTPCall = HTTPCall;
        this.userService = userService;
        this.FormError = FormError;
        this.Keys = Keys;
        this.ValidateName = (control) => {
            const nameRegex = /^[a-zA-Z\s]+$/;
            if (!control.value || nameRegex.test(control.value)) {
                return null;
            }
            else {
                return { invalidName: true };
            }
        };
        // FORM VARS ///////////////////////////////////////////
        this.US_States = [
            'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia',
            'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland',
            'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey',
            'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina',
            'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
        ];
        this.http = HTTPCall;
        this.userSubscription = this.userService.USERDATA$.subscribe((userData) => {
            //this.User = userData;
            let SettingCheck = userData ? userData.CONFIG : null;
            if (SettingCheck) {
                this.Debug = userData.CONFIG.DEBUG;
            }
        });
    }
    ngOnDestroy() {
        // Unsubscribe to prevent memory leaks
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
    }
    // Honeypot - Prevents spam
    HoneyPot(HoneypotValue) {
        if (HoneypotValue) {
            this.ErrorHandling.setError({ Success: false, Message: "Under maintenance. Please try again later." });
            return false; // failed honeypot
        }
        else {
            return true;
        }
    }
    // VALIDATIONS ///////////////////////////////////////////
    // For NG STYLE - turn form field red if invalid
    isInvalid(control) {
        return (control?.errors && control?.touched && control?.invalid) ?? false;
    }
    // Password Validation
    ValidatePassword(control) {
        const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&-])[A-Za-z\d$@$!%*?&-]{8,50}$/;
        if (!regex.test(control.value)) {
            return { invalidPassword: true };
        }
        return null;
    }
    // Password Match Validation
    CheckPassword(control) {
        let InputCheck = control?.get('passre');
        let InputCheck2 = control?.get('passre2');
        if (InputCheck?.value === InputCheck2?.value) {
            return null;
        }
        else {
            return { invalidPasswordMatch: true };
        }
    }
    // Email Availablility Validation
    CheckEmail(Form, ControlName) {
        let eventValue = Form ? Form.get(ControlName)?.value : null;
        if (eventValue) {
            return this.http.post({ checkd: eventValue }, '3mailch3ck').pipe(map$1((response) => {
                if (response.Success) {
                    return { emExError: true };
                }
                else {
                    return null;
                }
            }));
        }
        return of(null);
    }
    //Credit card expiration validator
    CheckExpirationDate() {
        return (control) => {
            const value = control.value;
            if (!value) {
                return null;
            }
            //Assigns month and year values according to user input.
            const [month, year] = value.split('/').map(Number);
            //Check if the user entered a valid format.
            if (!month || !year || month < 1 || month > 12) {
                return { invalidCardDate: 'Invalid card date.' };
            }
            //Get the current date and assign to their own constants.
            const currentDate = new Date();
            const currentMonth = currentDate.getMonth() + 1;
            const currentYear = currentDate.getFullYear() % 100;
            //Check if the date is expired.
            if (year < currentYear || (year === currentYear && month < currentMonth)) {
                return { expiredCardDate: 'This card is expired.' };
            }
            return null;
        };
    }
    ;
    // Display Name Availablility Validation
    CheckDisname(Form, ControlName) {
        let eventValue = Form ? Form.get(ControlName)?.value : null;
        if (eventValue) {
            return this.http.post({ checkd: eventValue }, 'Ch3kD').pipe(map$1((response) => {
                if (response.Success) {
                    return { disNameError: true };
                }
                else {
                    return null;
                }
            }));
        }
        return of(null);
    }
    // Validate Form - Check if form is valid
    FormValid(FormData) {
        if (this.Debug === true) {
            console.log(FormData);
        }
        if (!FormData.valid) {
            this.ErrorHandling.setError({ Success: false, Message: "Correct any blank fields, or fields marked in red before submitting the form." });
            return false;
        }
        else {
            return true;
        }
    }
    // Validate that the text input is a valid youtube link
    ValidateYoutubeLink(control) {
        const regex = /^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/.+$/;
        if (control.value && !regex.test(control.value)) {
            return { invalidYoutubeLink: true };
        }
        return null;
    }
    getYouTubeEmbedUrl_Library(videoUrl) {
        const youtubeRegex = /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(.+)$/;
        const match = videoUrl.match(youtubeRegex);
        if (match) {
            const videoId = match[1];
            const embedUrl = `https://www.youtube.com/embed/${videoId}`;
            return embedUrl;
        }
        else {
            //throw new Error('Invalid YouTube video URL');
            return 'https://www.youtube.com/embed/v4_frrKg8SQ'; // set default video if not valid youtube video 
        }
    }
    // validate that the text input is valid link
    ValidateLink(control) {
        // Return null if the control is not touched and is pristine
        if (!control.touched && control.pristine) {
            return null;
        }
        // Regular expression check
        const regex = /^(http(s)?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w- ;,./?%&=]*)?$/;
        if (!regex.test(control.value)) {
            return { invalidLink: true };
        }
        return null;
    }
    // NEW SUBMIT FORM HANDLER 
    async submitForm(Form, Caller /* API Caller */, Restrict = false) {
        // Debug - Form Input
        if (this.Debug === true) {
            console.log({ "Form Data": Form.value });
        }
        // HONEYPOT
        if (!this.HoneyPot(Form.value.website)) {
            return this.ErrorHandling.setError({ "Message": 'Form under maintenance', "Success": false });
        }
        // FORM VALIDIATION 
        if (!this.FormValid(Form)) {
            return this.ErrorHandling.setError({ "Message": 'Form Invalid! ' + this.FormError.getAllErrorMessages(Form), "Success": false });
        }
        // CHECK DATA IN 
        let DataIn = this.getTouchedAndDirtyValues(Form);
        if (!DataIn) {
            return this.ErrorHandling.setError({ "Message": 'Nothing to update', "Success": true });
        }
        // Merge Form Value array and caller itno array 
        let AllDataIn = { ...this.getTouchedAndDirtyValues(Form), ...{ "CALL": Caller } };
        // reset form entries
        //Form.reset(); // reset form values
        let Data = await firstValueFrom(this.HTTPCall.TakeAction(AllDataIn, Restrict));
        // Form.reset();
        return Data;
    }
    async updateInfo(ProfileForm) {
        let Form_info = this.getTouchedAndDirtyValues(ProfileForm); // Save Form info so it is not reset
        let Response = await this.submitForm(ProfileForm, this.Keys.UExtra_EditKey, true);
        // update token with new info
        if (Response.Success === true) {
            delete Form_info.website; // remove website 
            await this.userService.updateSession(Form_info); // Update Login Info
        }
        return Response;
    }
    // Submit Form
    // PHASE OUT  - key difference is no need for sub and that it returns full json response
    async onSubmit(Form, Caller /* API Caller */) {
        // Debug - Form Input
        if (this.Debug === true) {
            console.log(Form.value);
        }
        // HONEYPOT
        if (!this.HoneyPot(Form.value.website)) {
            return false;
        }
        // FORM VALIDIATION 
        if (!this.FormValid(Form)) {
            return false;
        }
        // Sub
        const User = await this.userService.getData();
        Form.value.Sub = User ? User.Ky : null;
        // POST - OLD WAY 
        return new Promise((resolve, reject) => {
            this.HTTPCall.post(Form.value, Caller).subscribe(async (response) => {
                if (await response.Success) {
                    this.ErrorHandling.setError(response);
                    Form.reset(); // reset form values
                    resolve(true);
                }
                else {
                    this.ErrorHandling.setError(response);
                    resolve(false);
                }
            }, (error) => {
                reject(error);
            });
        });
    }
    getTouchedAndDirtyValues(form) {
        let formValues = {};
        Object.keys(form.controls).forEach(key => {
            const control = form.get(key);
            if (control && control.touched && !control.pristine) {
                formValues[key] = control.value;
            }
        });
        return formValues;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormService, deps: [{ token: ErrorHandlingService }, { token: ApiService }, { token: IndexedDBService }, { token: FormErrorComponent }, { token: KeysComponent }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: ErrorHandlingService }, { type: ApiService }, { type: IndexedDBService }, { type: FormErrorComponent }, { type: KeysComponent }]; } });
// dont use var use in class instead
var US_States = [
    'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia',
    'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland',
    'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey',
    'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina',
    'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
];

class NewPassFormComponent {
    constructor(formBuilder, Keys, FormService, router, userService) {
        this.formBuilder = formBuilder;
        this.Keys = Keys;
        this.FormService = FormService;
        this.router = router;
        this.userService = userService;
        // Vars
        this.Pass = '';
        // icon
        this.eye_off_outline = eyeOffOutline;
        this.eye_outline = eyeOutline;
        this.key_outline = keyOutline;
        //view
        this.view = lRouteKey;
        // Password show feature 
        this.ShowPassword = false;
        this.ShowPassword2 = false;
        this.NewPassform = this.formBuilder.group({
            website: [''],
            passre: ['', [Validators.required, this.FormService.ValidatePassword]],
            passre2: ['', [Validators.required, this.FormService.ValidatePassword]],
        }, { validator: this.FormService.CheckPassword });
    }
    ngOnInit() {
        this.userService.USERDATA$.pipe(take(1)).subscribe((data) => {
            this.User = data;
        });
    }
    // Submit Form
    onSubmit() {
        // Set Params intop submit form 
        let urlParams = new URLSearchParams(window.location.search);
        let urlParamsSent = {};
        urlParams.forEach((value, key) => {
            urlParamsSent[key] = value;
        });
        // add urlParamsSent to NewPassform value
        for (const key in urlParamsSent) {
            this.NewPassform.addControl(key, this.formBuilder.control(urlParamsSent[key]));
        }
        this.FormService.onSubmit(this.NewPassform, this.User.CALL.Pass_Reset_NewPass);
    }
    requestPassLink() {
        this.router.navigate(["/" + this.view.forgotPassword]);
    }
    togglePasswordVisibility() {
        this.ShowPassword = !this.ShowPassword;
    }
    togglePasswordVisibility2() {
        this.ShowPassword2 = !this.ShowPassword2;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NewPassFormComponent, deps: [{ token: i1$2.FormBuilder }, { token: KeysComponent }, { token: FormService }, { token: i1.Router }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: NewPassFormComponent, selector: "login-newpassform", inputs: { Pass: "Pass" }, ngImport: i0, template: "<div class=\"section\">\n    <div>\n        <h1>\n            <span>\n                Reset Your Password\n            </span>\n        </h1>\n        <h3>\n            Enter your new password or <a class=\"a\" (click)=\"requestPassLink()\"> request a reset link</a>.\n        </h3>\n        <br />\n        \n        \n        <form [formGroup]=\"NewPassform\" (ngSubmit)=\"onSubmit()\">\n            <input type=\"text\" name=\"website\" style=\"display: none;\">\n\n            <div style=\"display: flex;\">\n                <input aria-label=\"Password input field\" type=\"{{ ShowPassword ? 'text' : 'password' }}\" formControlName=\"passre\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(NewPassform.get('passre'))}\" placeholder=\"Password\" />\n                \n                <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility()\">\n                    <a alt=\"view/hide password\" title=\"view/hide password\">\n                        <span *ngIf=\"ShowPassword == false\" class=\"material-symbols-outlined\">\n                            <ion-icon size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                        </span>\n                        <span *ngIf=\"ShowPassword == true\" class=\"material-symbols-outlined\">\n                            <ion-icon size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n                        </span>\n                    </a>\n                </div>\n            </div>\n            <formErrorMessage [control]=\"NewPassform.get('passre')\"></formErrorMessage>\n\n            <br />\n            <div style=\"display: flex;\">\n                <input aria-label=\"Password verification input field\" type=\"{{ ShowPassword2 ? 'text' : 'password' }}\" formControlName=\"passre2\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(NewPassform.get('passre2'))}\" placeholder=\"Re-Type Password\" />\n                \n                <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility2()\">\n                    <a alt=\"view/hide password\" title=\"view/hide password\">\n                        <span *ngIf=\"ShowPassword2 == false\" class=\"material-symbols-outlined\">\n                            <ion-icon size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                        </span>\n                        <span *ngIf=\"ShowPassword2 == true\" class=\"material-symbols-outlined\">\n                            <ion-icon size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n                        </span>\n                    </a>\n                </div>\n            </div>\n            <formErrorMessage [control]=\"NewPassform.get('passre2')\"></formErrorMessage>\n            <formErrorMessage [control]=\"NewPassform\"></formErrorMessage>\n            <br />\n            \n            <button aria-label=\"Submit button\" [disabled]=\"NewPassform.invalid\" type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n                <span class=\"material-symbols-outlined\">\n                    <ion-icon size=\"large\" [icon]=\"key_outline\"></ion-icon>\n                </span>\n                Reset Password\n            </button>\n        </form>\n    </div>\n\n</div>", styles: [".pass_hi{margin:auto}.a{cursor:pointer}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: NewPassFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'login-newpassform', template: "<div class=\"section\">\n    <div>\n        <h1>\n            <span>\n                Reset Your Password\n            </span>\n        </h1>\n        <h3>\n            Enter your new password or <a class=\"a\" (click)=\"requestPassLink()\"> request a reset link</a>.\n        </h3>\n        <br />\n        \n        \n        <form [formGroup]=\"NewPassform\" (ngSubmit)=\"onSubmit()\">\n            <input type=\"text\" name=\"website\" style=\"display: none;\">\n\n            <div style=\"display: flex;\">\n                <input aria-label=\"Password input field\" type=\"{{ ShowPassword ? 'text' : 'password' }}\" formControlName=\"passre\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(NewPassform.get('passre'))}\" placeholder=\"Password\" />\n                \n                <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility()\">\n                    <a alt=\"view/hide password\" title=\"view/hide password\">\n                        <span *ngIf=\"ShowPassword == false\" class=\"material-symbols-outlined\">\n                            <ion-icon size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                        </span>\n                        <span *ngIf=\"ShowPassword == true\" class=\"material-symbols-outlined\">\n                            <ion-icon size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n                        </span>\n                    </a>\n                </div>\n            </div>\n            <formErrorMessage [control]=\"NewPassform.get('passre')\"></formErrorMessage>\n\n            <br />\n            <div style=\"display: flex;\">\n                <input aria-label=\"Password verification input field\" type=\"{{ ShowPassword2 ? 'text' : 'password' }}\" formControlName=\"passre2\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(NewPassform.get('passre2'))}\" placeholder=\"Re-Type Password\" />\n                \n                <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility2()\">\n                    <a alt=\"view/hide password\" title=\"view/hide password\">\n                        <span *ngIf=\"ShowPassword2 == false\" class=\"material-symbols-outlined\">\n                            <ion-icon size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                        </span>\n                        <span *ngIf=\"ShowPassword2 == true\" class=\"material-symbols-outlined\">\n                            <ion-icon size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n                        </span>\n                    </a>\n                </div>\n            </div>\n            <formErrorMessage [control]=\"NewPassform.get('passre2')\"></formErrorMessage>\n            <formErrorMessage [control]=\"NewPassform\"></formErrorMessage>\n            <br />\n            \n            <button aria-label=\"Submit button\" [disabled]=\"NewPassform.invalid\" type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n                <span class=\"material-symbols-outlined\">\n                    <ion-icon size=\"large\" [icon]=\"key_outline\"></ion-icon>\n                </span>\n                Reset Password\n            </button>\n        </form>\n    </div>\n\n</div>", styles: [".pass_hi{margin:auto}.a{cursor:pointer}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.FormBuilder }, { type: KeysComponent }, { type: FormService }, { type: i1.Router }, { type: IndexedDBService }]; }, propDecorators: { Pass: [{
                type: Input
            }] } });

class LoadingSpinnerComponent {
    //Photo: string = this.globals.getMainLogoImage(); // using logo box instead
    constructor(LoadingSpinner, userService) {
        this.LoadingSpinner = LoadingSpinner;
        this.userService = userService;
        this.isLoading = false;
    }
    ngOnInit() {
        // ERROR HANDLING
        this.LoadingSpinner.spinner$.subscribe((spinner) => {
            //window.scrollTo(0, 0);
            this.isLoading = spinner;
        });
        // this.userSubscription = this.userService.USERDATA$.subscribe(
        //   (userData) => {
        //     let SettingCheck = userData ? userData.CONFIG : null;
        //     this.buttons = userData.SETTINGS.UserNav_Footer;
        //     // if(SettingCheck){
        //     //   this.buttons = userData.SETTINGS.UserNav_Footer;  
        //     // }
        //   }
        // );
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingSpinnerComponent, deps: [{ token: LoadingSpinnerService }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LoadingSpinnerComponent, selector: "app-loadingspinner", inputs: { isLoading: "isLoading" }, ngImport: i0, template: "<div *ngIf=\"isLoading\" class=\"overlay-container\">\n    <div class=\"loading-spinner\">\n      <logo-box class=\"Spin\" [styling]=\"'width: 50px; margin: auto;'\" [AltText]=\"'Loading...'\" ></logo-box>\n      <!-- <img class=\"Spin\" style=\"height: 50px; width: 50px;\" [src]=\"Photo\" alt=\"Loading...\" /> -->\n      <p>Loading...</p>\n    </div>\n  </div>", styles: [".Spin{animation:spin 3s infinite ease-out}@keyframes spin{0%{transform:rotate(0)}10%{transform:rotate(360deg)}90%{filter:invert(1);transform:rotate(360deg)}to{transform:rotate(360deg)}}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: LogoBoxComponent, selector: "logo-box", inputs: ["styling", "Boxstyling", "AltText", "Logo", "TagOn"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoadingSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-loadingspinner', template: "<div *ngIf=\"isLoading\" class=\"overlay-container\">\n    <div class=\"loading-spinner\">\n      <logo-box class=\"Spin\" [styling]=\"'width: 50px; margin: auto;'\" [AltText]=\"'Loading...'\" ></logo-box>\n      <!-- <img class=\"Spin\" style=\"height: 50px; width: 50px;\" [src]=\"Photo\" alt=\"Loading...\" /> -->\n      <p>Loading...</p>\n    </div>\n  </div>", styles: [".Spin{animation:spin 3s infinite ease-out}@keyframes spin{0%{transform:rotate(0)}10%{transform:rotate(360deg)}90%{filter:invert(1);transform:rotate(360deg)}to{transform:rotate(360deg)}}\n"] }]
        }], ctorParameters: function () { return [{ type: LoadingSpinnerService }, { type: IndexedDBService }]; }, propDecorators: { isLoading: [{
                type: Input
            }] } });

class LoginformComponent {
    togglePasswordVisibility() {
        this.ShowPassword = !this.ShowPassword;
    }
    constructor(formBuilder, Keys, FormService, router, userService) {
        this.formBuilder = formBuilder;
        this.Keys = Keys;
        this.FormService = FormService;
        this.router = router;
        this.userService = userService;
        // Password show feature 
        this.ShowPassword = false;
        this.eye_outline = eyeOutline; // icon
        this.eye_off_outline = eyeOffOutline;
        this.log_in_outline = logInOutline;
        this.Remember = false;
        //input email
        this.defaultEmail = '';
        //view
        this.view = lRouteKey;
        // Submit Form
        this.HideLogin = false;
        this.LoginForm = this.formBuilder.group({
            website: [''],
            usemal: ['', [Validators.required, Validators.email, Validators.minLength(7), Validators.maxLength(50)]],
            pqwrd: ['', [Validators.required]],
            rememberme: [false]
        });
    }
    ngOnInit() {
        this.userSubscription = this.userService.USERDATA$.subscribe((data) => {
            this.User = data;
        });
        //changes the email input to the inputed one
        this.LoginForm.patchValue({
            usemal: this.defaultEmail
        });
    }
    async onSubmit() {
        this.HideLogin = true;
        await this.FormService.onSubmit(this.LoginForm, this.User.CALL.Login); // first for login
        this.HideLogin = false;
    }
    ngOnDestroy() {
        this.userSubscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoginformComponent, deps: [{ token: i1$2.FormBuilder }, { token: KeysComponent }, { token: FormService }, { token: i1.Router }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LoginformComponent, selector: "login-form", inputs: { defaultEmail: "defaultEmail" }, ngImport: i0, template: "<form [formGroup]=\"LoginForm\" (ngSubmit)=\"onSubmit()\">\n    <h1>\n        <span>\n            Welcome Back!\n        </span>\n    </h1>\n    <h3>\n        Enter your credentials to <b>login</b>.\n    </h3>\n    <br />\n    <input type=\"text\" formControlName=\"website\" style=\"display: none;\">\n    <input type=\"email\" autocomplete=\"email\"\n        [ngClass]=\"{'is-invalid': this.FormService.isInvalid(LoginForm.get('usemal'))}\" formControlName=\"usemal\"\n        placeholder=\"Email\" />\n    <formErrorMessage [control]=\"LoginForm.get('usemal')\"></formErrorMessage>\n    <br />\n\n    <div style=\"display: flex;\">\n        <input autocomplete=\"current-password\" type=\"{{ ShowPassword ? 'text' : 'password' }}\" formControlName=\"pqwrd\"\n            [ngClass]=\"{'is-invalid': this.FormService.isInvalid(LoginForm.get('pqwrd'))}\" placeholder=\"Password\" />\n\n        <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility()\">\n            <a alt=\"view/hide password\" title=\"view/hide password\">\n                <!-- visibility -->\n                <ion-icon class=\"EyeIcon\" *ngIf=\"ShowPassword == false\" size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                <!-- visibility_off -->\n                <ion-icon class=\"EyeIcon\" *ngIf=\"ShowPassword == true\" size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n            </a>\n        </div>\n    </div>\n    <formErrorMessage [control]=\"LoginForm.get('pqwrd')\"></formErrorMessage>\n\n    <br />\n    <div style=\"display: flex; padding: 0.5rem; justify-content: flex-start;\">\n        <input type=\"checkbox\" formControlName=\"rememberme\" style=\"max-height: 10px; width: min-content; margin: auto 0px;\" />\n        <span style=\"cursor: pointer;\">\n            Stay logged in | <a class=\"button\"\n                (click)=\"this.router.navigate(['/'+this.view.forgotPassword.path])\">Forgot your password?</a>\n        </span>\n    </div>\n\n    <br />\n    <div style=\"text-align: right;\">\n        <!-- <hr style=\"background: var(--color)\"> -->\n        <app-loadingspinner></app-loadingspinner>\n        <button *ngIf=\"!HideLogin\" aria-label=\"Sign in button\" type=\"submit\" class=\"button button2\"\n            style=\"padding-right: 1rem; font-size: 1.5rem;\">\n            <ion-icon size=\"large\" [icon]=\"log_in_outline\"></ion-icon>\n            Sign In\n        </button>\n    </div>\n</form>", styles: [".pass_hi{margin:auto 0;display:flex}.EyeIcon{margin:auto auto auto 2px;display:block}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }, { kind: "component", type: LoadingSpinnerComponent, selector: "app-loadingspinner", inputs: ["isLoading"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoginformComponent, decorators: [{
            type: Component,
            args: [{ selector: 'login-form', template: "<form [formGroup]=\"LoginForm\" (ngSubmit)=\"onSubmit()\">\n    <h1>\n        <span>\n            Welcome Back!\n        </span>\n    </h1>\n    <h3>\n        Enter your credentials to <b>login</b>.\n    </h3>\n    <br />\n    <input type=\"text\" formControlName=\"website\" style=\"display: none;\">\n    <input type=\"email\" autocomplete=\"email\"\n        [ngClass]=\"{'is-invalid': this.FormService.isInvalid(LoginForm.get('usemal'))}\" formControlName=\"usemal\"\n        placeholder=\"Email\" />\n    <formErrorMessage [control]=\"LoginForm.get('usemal')\"></formErrorMessage>\n    <br />\n\n    <div style=\"display: flex;\">\n        <input autocomplete=\"current-password\" type=\"{{ ShowPassword ? 'text' : 'password' }}\" formControlName=\"pqwrd\"\n            [ngClass]=\"{'is-invalid': this.FormService.isInvalid(LoginForm.get('pqwrd'))}\" placeholder=\"Password\" />\n\n        <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility()\">\n            <a alt=\"view/hide password\" title=\"view/hide password\">\n                <!-- visibility -->\n                <ion-icon class=\"EyeIcon\" *ngIf=\"ShowPassword == false\" size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                <!-- visibility_off -->\n                <ion-icon class=\"EyeIcon\" *ngIf=\"ShowPassword == true\" size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n            </a>\n        </div>\n    </div>\n    <formErrorMessage [control]=\"LoginForm.get('pqwrd')\"></formErrorMessage>\n\n    <br />\n    <div style=\"display: flex; padding: 0.5rem; justify-content: flex-start;\">\n        <input type=\"checkbox\" formControlName=\"rememberme\" style=\"max-height: 10px; width: min-content; margin: auto 0px;\" />\n        <span style=\"cursor: pointer;\">\n            Stay logged in | <a class=\"button\"\n                (click)=\"this.router.navigate(['/'+this.view.forgotPassword.path])\">Forgot your password?</a>\n        </span>\n    </div>\n\n    <br />\n    <div style=\"text-align: right;\">\n        <!-- <hr style=\"background: var(--color)\"> -->\n        <app-loadingspinner></app-loadingspinner>\n        <button *ngIf=\"!HideLogin\" aria-label=\"Sign in button\" type=\"submit\" class=\"button button2\"\n            style=\"padding-right: 1rem; font-size: 1.5rem;\">\n            <ion-icon size=\"large\" [icon]=\"log_in_outline\"></ion-icon>\n            Sign In\n        </button>\n    </div>\n</form>", styles: [".pass_hi{margin:auto 0;display:flex}.EyeIcon{margin:auto auto auto 2px;display:block}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.FormBuilder }, { type: KeysComponent }, { type: FormService }, { type: i1.Router }, { type: IndexedDBService }]; }, propDecorators: { defaultEmail: [{
                type: Input
            }] } });

class UserRegComponent {
    constructor(formBuilder, Keys, router, FormService, userService) {
        this.formBuilder = formBuilder;
        this.Keys = Keys;
        this.router = router;
        this.FormService = FormService;
        this.userService = userService;
        this.eye_outline = eyeOutline; // icon
        this.eye_off_outline = eyeOffOutline;
        this.log_in_outline = logInOutline;
        //view
        this.view = lRouteKey;
        //input email
        this.defaultEmail = '';
        // Password show feature 
        this.ShowPassword = false;
        this.ShowPassword2 = false;
        this.RegForm = this.formBuilder.group({
            website: [''],
            nusemal: ['', [Validators.required, Validators.email, Validators.minLength(7), Validators.maxLength(85)]],
            //dis_name: ['', [Validators.minLength(3), Validators.maxLength(50), Validators.required]],
            firstname: ['', [this.FormService.ValidateName]],
            //lastname: ['', [this.FormService.ValidateName]],
            passre: ['', [Validators.required, this.FormService.ValidatePassword]],
            passre2: ['', [Validators.required, this.FormService.ValidatePassword]],
            acceptTerms: ['', Validators.requiredTrue]
        });
    }
    ngOnInit() {
        //changes the email input to the inputed one
        this.RegForm.patchValue({
            nusemal: this.defaultEmail
        });
        this.userService.USERDATA$.pipe(take$1(1)).subscribe((data) => {
            this.User = data;
        });
    }
    openPrivacy() {
        window.open('/policies', '_blank');
    }
    openTerms() {
        window.open('/terms', '_blank');
    }
    async CheckExi(ControlName, Type) {
        // run validation
        let ErrorTrack = null;
        switch (Type) {
            case 'email':
                ErrorTrack = await firstValueFrom(this.FormService.CheckEmail(this.RegForm, ControlName));
                break;
            case 'dis_name':
                ErrorTrack = await firstValueFrom(this.FormService.CheckDisname(this.RegForm, ControlName));
                break;
        }
        // Set Dynamic Errors
        let currentErrors = this.RegForm.controls[ControlName].errors;
        if (ErrorTrack) {
            let newErrors = { ...currentErrors, ...ErrorTrack };
            this.RegForm.controls[ControlName].setErrors(newErrors);
        }
    }
    togglePasswordVisibility() {
        this.ShowPassword = !this.ShowPassword;
    }
    togglePasswordVisibility2() {
        this.ShowPassword2 = !this.ShowPassword2;
    }
    // Submit Form
    onSubmit() {
        this.FormService.onSubmit(this.RegForm, this.User.CALL.New_User_Reg);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserRegComponent, deps: [{ token: i1$2.FormBuilder }, { token: KeysComponent }, { token: i1.Router }, { token: FormService }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: UserRegComponent, selector: "login-signupform", inputs: { defaultEmail: "defaultEmail" }, ngImport: i0, template: "<form [formGroup]=\"RegForm\" (ngSubmit)=\"onSubmit()\">\n    <h1>\n        <span>\n            New Around Here?\n        </span>\n    </h1>\n    <h3>\n        Create an account\n    </h3>\n    <p>\n        *When handling sensitive information we utilize industry standards as well as additional security measures. For more information <a class=\"a\" (click)=\"openPrivacy()\">click here</a>\n    </p>\n\n    <br />\n    <input type=\"text\" formControlName=\"website\" style=\"display: none;\">\n    <input \n        type=\"email\" \n        formControlName=\"nusemal\" \n        placeholder=\"Enter Email (used as your official login)\"\n        minlength=\"7\" \n        maxlength=\"85\" \n        title=\"Email (used as login)\"\n        required\n        (blur)=\"CheckExi('nusemal','email')\"\n        [ngClass]=\"{'is-invalid': this.FormService.isInvalid(RegForm.get('nusemal'))}\" \n         />\n    <formErrorMessage [control]=\"RegForm.get('nusemal')\"></formErrorMessage>\n    \n    <!-- \n    <br />\n     <input \n        type=\"text\"\n        formControlName=\"dis_name\" \n        placeholder=\"Enter your PUBLIC username...\" \n        title=\"Your public username\"\n        minlength=\"3\" \n        maxlength=\"50\" \n        required\n        (ngModelChange)=\"CheckExi('dis_name','dis_name')\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(RegForm.get('dis_name'))}\" />\n    <formErrorMessage [control]=\"RegForm.get('dis_name')\"></formErrorMessage> -->\n\n\n    <br />\n    <!-- <br />\n    <h3>\n        Personal Information\n    </h3>\n    <p>\n        So we know you are not a robot.\n    </p> -->\n    <input \n        style=\"width: 100%;\" \n        type=\"text\" \n        minlength=\"3\" \n        maxlength=\"40\"\n        placeholder=\"Your First Name\" \n        pattern=\"[a-zA-Z]+\"\n        title=\"Enter your first name...\" \n        required\n        formControlName=\"firstname\"\n        aria-label=\"First Name input field\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(RegForm.get('firstname'))}\">\n        <formErrorMessage [control]=\"RegForm.get('firstname')\"></formErrorMessage>\n        <br />\n\n        <!-- <input \n        style=\"width: 100%;\" \n        type=\"text\" \n        minlength=\"3\" \n        maxlength=\"40\"\n        placeholder=\"Your Last Name...\" \n        pattern=\"[a-zA-Z]+\"\n        title=\"Enter your last name...\" \n        required\n        formControlName=\"lastname\"\n        aria-label=\"Last Name input field\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(RegForm.get('lastname'))}\">\n        <formErrorMessage [control]=\"RegForm.get('lastname')\"></formErrorMessage>  <br /> -->\n\n      \n        <br />\n        <h4>Password</h4>\n        <p style=\"margin: 0px;\">Must contain one number, one uppercase letter, one lowercase letter, and\n            minimum 8 characters</p>\n\n        <div style=\"display: flex;\">\n            <input aria-label=\"Password input field\" type=\"{{ ShowPassword ? 'text' : 'password' }}\" formControlName=\"passre\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(RegForm.get('passre'))}\" placeholder=\"Password\" />\n            <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility()\">\n                <a alt=\"view/hide password\" title=\"view/hide password\">\n                    <span *ngIf=\"ShowPassword == false\" class=\"material-symbols-outlined\">\n                        <!-- visibility -->\n                        <ion-icon size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                    </span>\n                    <span *ngIf=\"ShowPassword == true\" class=\"material-symbols-outlined\">\n                        <!-- visibility_off -->\n                        <ion-icon size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n                    </span>\n                </a>\n            </div>\n        </div>\n        <formErrorMessage [control]=\"RegForm.get('passre')\"></formErrorMessage>\n\n        <br />\n        <div style=\"display: flex;\">\n            <input aria-label=\"Password verification input field\" type=\"{{ ShowPassword2 ? 'text' : 'password' }}\" formControlName=\"passre2\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(RegForm.get('passre2'))}\" placeholder=\"Re-Type Password\" />\n            \n            <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility2()\">\n                <a alt=\"view/hide password\" title=\"view/hide password\">\n                    <span *ngIf=\"ShowPassword2 == false\" class=\"material-symbols-outlined\">\n                        <!-- visibility -->\n                        <ion-icon size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                    </span>\n                    <span *ngIf=\"ShowPassword2 == true\" class=\"material-symbols-outlined\">\n                        <!-- visibility_off -->\n                        <ion-icon size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n                    </span>\n                </a>\n            </div>\n        </div>\n        <formErrorMessage [control]=\"RegForm.get('passre2')\"></formErrorMessage>\n        <formErrorMessage [control]=\"RegForm\"></formErrorMessage>\n        <br />\n        <div style=\"display: flex; padding: 0.5rem; justify-content: flex-start;\" [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(RegForm.get('acceptTerms')) }\">\n            <input style=\"max-height: 10px; width: min-content; margin: auto 0px;\" type=\"checkbox\" required formControlName=\"acceptTerms\">\n            <span style=\"font-size: 12px;\"> \n                I accept the <a class=\"a\" (click)=\"openTerms()\" target=\"_blank\">terms of use</a> \n                and\n                <a class=\"a\" (click)=\"openPrivacy()\" target=\"_blank\">privacy policies</a>\n            </span>\n        </div>\n\n        <br />\n        <div style=\"text-align: right;\">\n            <app-loadingspinner></app-loadingspinner> \n            <button aria-label=\"Create account button\" [disabled]=\"RegForm.invalid\" type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n                <ion-icon size=\"large\" [icon]=\"log_in_outline\"></ion-icon>\n                Create Account\n            </button>\n        </div>\n</form>", styles: [".pass_hi{margin:auto}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1$2.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i1$2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1$2.PatternValidator, selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]", inputs: ["pattern"] }, { kind: "directive", type: i1$2.CheckboxRequiredValidator, selector: "input[type=checkbox][required][formControlName],input[type=checkbox][required][formControl],input[type=checkbox][required][ngModel]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }, { kind: "component", type: LoadingSpinnerComponent, selector: "app-loadingspinner", inputs: ["isLoading"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserRegComponent, decorators: [{
            type: Component,
            args: [{ selector: 'login-signupform', template: "<form [formGroup]=\"RegForm\" (ngSubmit)=\"onSubmit()\">\n    <h1>\n        <span>\n            New Around Here?\n        </span>\n    </h1>\n    <h3>\n        Create an account\n    </h3>\n    <p>\n        *When handling sensitive information we utilize industry standards as well as additional security measures. For more information <a class=\"a\" (click)=\"openPrivacy()\">click here</a>\n    </p>\n\n    <br />\n    <input type=\"text\" formControlName=\"website\" style=\"display: none;\">\n    <input \n        type=\"email\" \n        formControlName=\"nusemal\" \n        placeholder=\"Enter Email (used as your official login)\"\n        minlength=\"7\" \n        maxlength=\"85\" \n        title=\"Email (used as login)\"\n        required\n        (blur)=\"CheckExi('nusemal','email')\"\n        [ngClass]=\"{'is-invalid': this.FormService.isInvalid(RegForm.get('nusemal'))}\" \n         />\n    <formErrorMessage [control]=\"RegForm.get('nusemal')\"></formErrorMessage>\n    \n    <!-- \n    <br />\n     <input \n        type=\"text\"\n        formControlName=\"dis_name\" \n        placeholder=\"Enter your PUBLIC username...\" \n        title=\"Your public username\"\n        minlength=\"3\" \n        maxlength=\"50\" \n        required\n        (ngModelChange)=\"CheckExi('dis_name','dis_name')\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(RegForm.get('dis_name'))}\" />\n    <formErrorMessage [control]=\"RegForm.get('dis_name')\"></formErrorMessage> -->\n\n\n    <br />\n    <!-- <br />\n    <h3>\n        Personal Information\n    </h3>\n    <p>\n        So we know you are not a robot.\n    </p> -->\n    <input \n        style=\"width: 100%;\" \n        type=\"text\" \n        minlength=\"3\" \n        maxlength=\"40\"\n        placeholder=\"Your First Name\" \n        pattern=\"[a-zA-Z]+\"\n        title=\"Enter your first name...\" \n        required\n        formControlName=\"firstname\"\n        aria-label=\"First Name input field\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(RegForm.get('firstname'))}\">\n        <formErrorMessage [control]=\"RegForm.get('firstname')\"></formErrorMessage>\n        <br />\n\n        <!-- <input \n        style=\"width: 100%;\" \n        type=\"text\" \n        minlength=\"3\" \n        maxlength=\"40\"\n        placeholder=\"Your Last Name...\" \n        pattern=\"[a-zA-Z]+\"\n        title=\"Enter your last name...\" \n        required\n        formControlName=\"lastname\"\n        aria-label=\"Last Name input field\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(RegForm.get('lastname'))}\">\n        <formErrorMessage [control]=\"RegForm.get('lastname')\"></formErrorMessage>  <br /> -->\n\n      \n        <br />\n        <h4>Password</h4>\n        <p style=\"margin: 0px;\">Must contain one number, one uppercase letter, one lowercase letter, and\n            minimum 8 characters</p>\n\n        <div style=\"display: flex;\">\n            <input aria-label=\"Password input field\" type=\"{{ ShowPassword ? 'text' : 'password' }}\" formControlName=\"passre\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(RegForm.get('passre'))}\" placeholder=\"Password\" />\n            <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility()\">\n                <a alt=\"view/hide password\" title=\"view/hide password\">\n                    <span *ngIf=\"ShowPassword == false\" class=\"material-symbols-outlined\">\n                        <!-- visibility -->\n                        <ion-icon size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                    </span>\n                    <span *ngIf=\"ShowPassword == true\" class=\"material-symbols-outlined\">\n                        <!-- visibility_off -->\n                        <ion-icon size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n                    </span>\n                </a>\n            </div>\n        </div>\n        <formErrorMessage [control]=\"RegForm.get('passre')\"></formErrorMessage>\n\n        <br />\n        <div style=\"display: flex;\">\n            <input aria-label=\"Password verification input field\" type=\"{{ ShowPassword2 ? 'text' : 'password' }}\" formControlName=\"passre2\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(RegForm.get('passre2'))}\" placeholder=\"Re-Type Password\" />\n            \n            <div style=\"margin: auto 0px; display: flex;\" class=\"pass_hi\" (click)=\"togglePasswordVisibility2()\">\n                <a alt=\"view/hide password\" title=\"view/hide password\">\n                    <span *ngIf=\"ShowPassword2 == false\" class=\"material-symbols-outlined\">\n                        <!-- visibility -->\n                        <ion-icon size=\"large\" [icon]=\"eye_outline\"></ion-icon>\n                    </span>\n                    <span *ngIf=\"ShowPassword2 == true\" class=\"material-symbols-outlined\">\n                        <!-- visibility_off -->\n                        <ion-icon size=\"large\" [icon]=\"eye_off_outline\"></ion-icon>\n                    </span>\n                </a>\n            </div>\n        </div>\n        <formErrorMessage [control]=\"RegForm.get('passre2')\"></formErrorMessage>\n        <formErrorMessage [control]=\"RegForm\"></formErrorMessage>\n        <br />\n        <div style=\"display: flex; padding: 0.5rem; justify-content: flex-start;\" [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(RegForm.get('acceptTerms')) }\">\n            <input style=\"max-height: 10px; width: min-content; margin: auto 0px;\" type=\"checkbox\" required formControlName=\"acceptTerms\">\n            <span style=\"font-size: 12px;\"> \n                I accept the <a class=\"a\" (click)=\"openTerms()\" target=\"_blank\">terms of use</a> \n                and\n                <a class=\"a\" (click)=\"openPrivacy()\" target=\"_blank\">privacy policies</a>\n            </span>\n        </div>\n\n        <br />\n        <div style=\"text-align: right;\">\n            <app-loadingspinner></app-loadingspinner> \n            <button aria-label=\"Create account button\" [disabled]=\"RegForm.invalid\" type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n                <ion-icon size=\"large\" [icon]=\"log_in_outline\"></ion-icon>\n                Create Account\n            </button>\n        </div>\n</form>", styles: [".pass_hi{margin:auto}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.FormBuilder }, { type: KeysComponent }, { type: i1.Router }, { type: FormService }, { type: IndexedDBService }]; }, propDecorators: { defaultEmail: [{
                type: Input
            }] } });

class PassresetComponent {
    constructor(formBuilder, Keys, FormService, userService) {
        this.formBuilder = formBuilder;
        this.Keys = Keys;
        this.FormService = FormService;
        this.userService = userService;
        //icons
        this.email_outline = mailOutline;
        //is this necessary?
        this.Email = '';
        this.PassResetForm = this.formBuilder.group({
            website: [''],
            usepass: ['', [Validators.required, Validators.email, Validators.minLength(7), Validators.maxLength(50)]],
        });
    }
    ngOnInit() {
        this.userService.USERDATA$.pipe(take(1)).subscribe((data) => {
            this.User = data;
        });
    }
    // Submit Form
    onSubmit() {
        this.FormService.onSubmit(this.PassResetForm, this.User.CALL.Pass_Reset);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PassresetComponent, deps: [{ token: i1$2.FormBuilder }, { token: KeysComponent }, { token: FormService }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: PassresetComponent, selector: "login-passreset", inputs: { Email: "Email" }, ngImport: i0, template: "<div class=\"section\">\n\n    <app-loadingspinner></app-loadingspinner> \n\n    <div>\n        <h1>\n            <span>\n                Password Recovery\n            </span>\n        </h1>\n        <h3>\n            Enter your login email, and check your inbox for a reset link.\n        </h3>\n        <br />\n        \n        <form [formGroup]=\"PassResetForm\" (ngSubmit)=\"onSubmit()\">\n            <input type=\"text\" name=\"website\" style=\"display: none;\">\n            <input aria-label=\"Email input field\" type=\"email\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(PassResetForm.get('usepass'))}\" formControlName=\"usepass\" placeholder=\"Email\" />\n            <formErrorMessage [control]=\"PassResetForm.get('usepass')\"></formErrorMessage>\n            <br />\n            <button aria-label=\"Submit button\" type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n                <span class=\"material-symbols-outlined\">\n                    <ion-icon size=\"large\" [icon]=\"email_outline\"></ion-icon>\n                </span>\n                Send Reset Link\n            </button>\n        </form>\n    </div>\n\n</div>", styles: [""], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }, { kind: "component", type: LoadingSpinnerComponent, selector: "app-loadingspinner", inputs: ["isLoading"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PassresetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'login-passreset', template: "<div class=\"section\">\n\n    <app-loadingspinner></app-loadingspinner> \n\n    <div>\n        <h1>\n            <span>\n                Password Recovery\n            </span>\n        </h1>\n        <h3>\n            Enter your login email, and check your inbox for a reset link.\n        </h3>\n        <br />\n        \n        <form [formGroup]=\"PassResetForm\" (ngSubmit)=\"onSubmit()\">\n            <input type=\"text\" name=\"website\" style=\"display: none;\">\n            <input aria-label=\"Email input field\" type=\"email\" [ngClass]=\"{'is-invalid': this.FormService.isInvalid(PassResetForm.get('usepass'))}\" formControlName=\"usepass\" placeholder=\"Email\" />\n            <formErrorMessage [control]=\"PassResetForm.get('usepass')\"></formErrorMessage>\n            <br />\n            <button aria-label=\"Submit button\" type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n                <span class=\"material-symbols-outlined\">\n                    <ion-icon size=\"large\" [icon]=\"email_outline\"></ion-icon>\n                </span>\n                Send Reset Link\n            </button>\n        </form>\n    </div>\n\n</div>" }]
        }], ctorParameters: function () { return [{ type: i1$2.FormBuilder }, { type: KeysComponent }, { type: FormService }, { type: IndexedDBService }]; }, propDecorators: { Email: [{
                type: Input
            }] } });

class LogoutComponent {
    constructor(router, User) {
        this.router = router;
        this.User = User;
        //view
        this.view = lRouteKey;
    }
    async logout() {
        await this.User.logoutSession();
        this.router.navigate(["/" + this.view.login.path]); // refresh the page
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LogoutComponent, deps: [{ token: i1.Router }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LogoutComponent, selector: "login-logout", ngImport: i0, template: "<h1>\n    Are you sure you want to logout?\n</h1>\n<button (click)=\"logout()\">Yes</button>\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LogoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'login-logout', template: "<h1>\n    Are you sure you want to logout?\n</h1>\n<button (click)=\"logout()\">Yes</button>\n" }]
        }], ctorParameters: function () { return [{ type: i1.Router }, { type: IndexedDBService }]; } });

class LoginComponent {
    constructor(route) {
        this.route = route;
        //customizability
        this.fullKit = true;
        this.logoBox = false;
        this.error = false;
        this.background = false;
        this.footer = false;
        this.routeKey = lRouteKey;
        this.routeView = this.route.snapshot.url[0] ? this.route.snapshot.url[0]['path'] : ''; // controls view of the page
        this.selectedTab = this.routeKey.login.path; // for switch button
    }
    ngOnInit() {
        if (this.routeView == this.routeKey.createAccount.path) {
            this.selectedTab = this.routeView;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoginComponent, deps: [{ token: i1.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LoginComponent, selector: "user-login", inputs: { fullKit: "fullKit", logoBox: "logoBox", error: "error", background: "background", footer: "footer" }, ngImport: i0, template: "<logo-box *ngIf=\"fullKit || logoBox\"></logo-box>\n<br />\n<background *ngIf=\"fullKit || background\"></background>\n\n<div *ngIf=\"routeView === routeKey.login.path || routeView === routeKey.createAccount.path  || !routeView\" class=\"section2\">\n    <div class=\"AddSectionPad\">\n        <ion-segment [(ngModel)]=\"selectedTab\" mode=\"ios\">\n            <ion-segment-button value=\"{{routeKey.login.path }}\">\n                Login\n            </ion-segment-button>\n            <ion-segment-button value=\"{{routeKey.createAccount.path }}\">\n                New Account\n            </ion-segment-button>\n        </ion-segment>\n\n        <div [ngSwitch]=\"selectedTab\">\n            <div *ngSwitchCase=\"routeKey.login.path \" class=\"AddSectionPad\">\n                <login-form></login-form>\n            </div>\n            <div *ngSwitchCase=\"routeKey.createAccount.path \">\n                <div class=\"AddSectionPad\">\n                    <login-signupform></login-signupform>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n<div *ngIf=\"routeView === routeKey.forgotPassword.path \" class=\"section2 AddSectionPad\">\n    <login-passreset></login-passreset>\n</div>\n<div *ngIf=\"routeView === routeKey.passwordReset.path \" class=\"section2 AddSectionPad\">\n    <login-newpassform></login-newpassform>\n</div>\n<div *ngIf=\"routeView === routeKey.logout.path \" class=\"section2 AddSectionPad\">\n    <login-logout></login-logout>\n</div>\n<!-- <hub-footer *ngIf=\"footer\"></hub-footer> -->", styles: [""], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: i3.NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: i4.IonSegment, selector: "ion-segment", inputs: ["color", "disabled", "mode", "scrollable", "selectOnFocus", "swipeGesture", "value"] }, { kind: "component", type: i4.IonSegmentButton, selector: "ion-segment-button", inputs: ["disabled", "layout", "mode", "type", "value"] }, { kind: "directive", type: i4.SelectValueAccessor, selector: "ion-select, ion-radio-group, ion-segment, ion-datetime" }, { kind: "component", type: BackgroundComponent, selector: "background", inputs: ["BackgroundImage"] }, { kind: "component", type: LogoBoxComponent, selector: "logo-box", inputs: ["styling", "Boxstyling", "AltText", "Logo", "TagOn"] }, { kind: "component", type: NewPassFormComponent, selector: "login-newpassform", inputs: ["Pass"] }, { kind: "component", type: LoginformComponent, selector: "login-form", inputs: ["defaultEmail"] }, { kind: "component", type: UserRegComponent, selector: "login-signupform", inputs: ["defaultEmail"] }, { kind: "component", type: PassresetComponent, selector: "login-passreset", inputs: ["Email"] }, { kind: "component", type: LogoutComponent, selector: "login-logout" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoginComponent, decorators: [{
            type: Component,
            args: [{ selector: 'user-login', template: "<logo-box *ngIf=\"fullKit || logoBox\"></logo-box>\n<br />\n<background *ngIf=\"fullKit || background\"></background>\n\n<div *ngIf=\"routeView === routeKey.login.path || routeView === routeKey.createAccount.path  || !routeView\" class=\"section2\">\n    <div class=\"AddSectionPad\">\n        <ion-segment [(ngModel)]=\"selectedTab\" mode=\"ios\">\n            <ion-segment-button value=\"{{routeKey.login.path }}\">\n                Login\n            </ion-segment-button>\n            <ion-segment-button value=\"{{routeKey.createAccount.path }}\">\n                New Account\n            </ion-segment-button>\n        </ion-segment>\n\n        <div [ngSwitch]=\"selectedTab\">\n            <div *ngSwitchCase=\"routeKey.login.path \" class=\"AddSectionPad\">\n                <login-form></login-form>\n            </div>\n            <div *ngSwitchCase=\"routeKey.createAccount.path \">\n                <div class=\"AddSectionPad\">\n                    <login-signupform></login-signupform>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n<div *ngIf=\"routeView === routeKey.forgotPassword.path \" class=\"section2 AddSectionPad\">\n    <login-passreset></login-passreset>\n</div>\n<div *ngIf=\"routeView === routeKey.passwordReset.path \" class=\"section2 AddSectionPad\">\n    <login-newpassform></login-newpassform>\n</div>\n<div *ngIf=\"routeView === routeKey.logout.path \" class=\"section2 AddSectionPad\">\n    <login-logout></login-logout>\n</div>\n<!-- <hub-footer *ngIf=\"footer\"></hub-footer> -->" }]
        }], ctorParameters: function () { return [{ type: i1.ActivatedRoute }]; }, propDecorators: { fullKit: [{
                type: Input
            }], logoBox: [{
                type: Input
            }], error: [{
                type: Input
            }], background: [{
                type: Input
            }], footer: [{
                type: Input
            }] } });

var eRouteKey = {
    ecommerce: { path: 'pricing', canActivate: true },
    cart: { path: 'cart', canActivate: true },
    productView: { path: 'product-view', canActivate: true },
    productTier: { path: 'product-tier', canActivate: true },
    checkout: { path: 'checkout', canActivate: true }
};

// For Package Categories /////////////////////////////////////////////////
var NavList = ["Packaged", "Hosting", "Security", "Development", "Branding"];
// For Package Info /////////////////////////////////////////////////
let ID$1 = 0;
var Packages = [
    {
        ID: ID$1++,
        Title: "Launch a Website",
        Description: "Beginner website hosting package. Includes website development, Server, Domain Name, SEO, and on-call maintenance services.",
        Tiers: [
            { Title: '', Price: 400, Length: "One-Time", Extra: "" }
        ],
        Type: NavList[0],
        Inclusions: ["Assigned Professional Website Developer", "Planning Meetings (1 x 30 Strategic Planning Meeting,1 x 30 minute Pre-Launch Meeting, 1 x 15 minute Post-Launch Meeting)", "Website Framework (Navigation Bar, Landing Page, About Page, Contact Page, 404 Error Page)", "Responsive/Scalable Design", "Optimized UI/UX", "Minified CodeBase", "6 Stock Photos (+/-)", "4 Hours Complimentary Maintenance", "Includes additional services"],
        Policies: "We will develop the website according to your specifications and requirements. This includes creating the website layout, design, and functionality. We will provide support for any issues or questions you may have regarding your website development. Website development support is available upon request. If you require support, please contact us to discuss your needs. We will ensure that the website is responsive and compatible across various devices and screen sizes.  We will optimize the website to improve its performance and speed. We will create an engaging and informative landing page or home page that effectively communicates the brand message and captures the user's attention. We will design an about page that tells the story of the business, its mission, and its key team members. We will develop a contact page with a user-friendly form and accurate contact information. We will develop additional features and functionalities for the website upon request. We will optimize the website for search engines to improve its ranking and visibility. Customer must provide some content and branding, or opt into additional services. For Meetings, it is the responsibility of the customer to schedule and attend the meetings. If the customer does not attend the meetings, the meetings will be considered completed and the customer will be responsible for any missed information. Websites come with complimentary website developments (up to 1 hour each month or 3 hours total per year). If you require more development, please contact us to discuss your needs. We will provide technical support upon request for website-related issues (if they arise from our code).",
        Keywords: ["Website", "Custom Website", "Website Launch", "Host", "New Website"]
    },
    //   {
    //   Title: "Advanced Website (Add On)",
    //   Description: "Advanced website hosting package. Includes all 'Basic Website' inclusions and additional advanced website/design services, such as branding (logo and color codes), SEO.",
    //   Price: 500,
    //   ID: 1,
    //   Type: "Package",
    //   Inclusions: [""],
    //   Policies: "You must provide some content and branding. We will write and edit the website content to ensure clarity, consistency, and accuracy."
    // },
    {
        ID: ID$1++,
        Title: "Launch a Brand",
        Description: "We handle all aspects of custom creating a unique and memorable brand portfolio, including logo design copies, color scheme HEXCodes, typography, and other visual elements. You receive a packet containing all materials, hand crafted by our graphic design team.",
        Tiers: [
            { Title: '', Price: 200, Length: "One-Time", Extra: "" }
        ],
        Type: NavList[0],
        Inclusions: ["Assigned Graphic Designer", "Planning Meetings (1 x 30 Strategic Planning Meeting,1 x 30 minute Pre-Launch Meeting, 1 x 15 minute Post-Launch Meeting)", "Logo Design File Copies (.PNG, .TIFF, and .JPEG)", "Hexadecimal Color Chart with Integrated Color Scheme", "Custom Selected Typography"],
        Policies: "You must provide some content and branding.",
        Keywords: ["Branding", "Logo", "Color", "Typography"]
    }
];

// Services For the Shop /////////////////////////////////////////////////
let ID = 100000;
var Services = [
    {
        ID: ID++,
        Type: NavList[1],
        Title: "Server Accessibility (Hosting)",
        Description: "We host the website on a dedicated server with 99.9% uptime. The size of your server load will vary based on the size of your website. Includes 1GB of Storage.",
        Inclusions: [
            "1GB of Disk Space",
            "Additional storage available for growing server space.",
            "99.9% Uptime",
            "Custom Email Account(s)",
            "Security and Maintenance",
            "Unmetered Bandwidth",
            "Assigned Customer Service Agent",
            // "FTP Access *Upon request",
        ],
        Policies: "Each account is allocated minimum 1GB of disk space for storing website files, emails, and databases. You will be notified if you exceed that limit, after which your account will enter a 10 day grace period, where you may chose to purchase more storage space, or free current storage space in order to return to the allocated space. Additional storage is available for purchase upon request. If a customer excessively exceeds the limited storage space (i.e. continually exceeds allocated space, or is still exceeding storage space following the grace period), Tiger Eye Technology reserves the right to halt services to the account, until a sustainable solution is provided for exceeding storage space use. We guarantee 99.9% uptime for your website. If your website is down for more than 0.1% of the time in a given month, we will provide a comparable credit for the next month's hosting fee. Custom email accounts are available upon request. Upon receipt of email account setup request, email accounts will be made available within 3-5 business days. Maximum of 3 emails per hosting plan, unless otherwise agreed upon. Accounts are allowed more emails with additional purchase. Database for your website. We will provide support for the database, including regular backups and maintenance. We will provide security measures to protect your website and data from threats such as hacking, malware, and unauthorized access. We will provide 24/7 support for any issues or questions you may have regarding your hosting account. FTP access is available upon request. FTP access allows you to upload, download, and manage files on your server. If you require FTP access, please contact us to set up your account.",
        Tiers: [
            { Price: 5, Length: "Month", Extra: "" },
            { Price: 60, Length: "Year", Extra: "" },
            { Price: 180, Length: "3 Years", Extra: "" },
        ],
        AssociatedServices: [0],
        Keywords: ["Server", "Hosting", "Dedicated Server", "Uptime", "Storage", "Bandwidth", "FTP", "Email", "Security", "Maintenance"]
    },
    // {
    //   Title: "Single Web Page",
    //   Description: "We create an engaging and informative landing page or home page that effectively communicates the brand message and captures the user's attention. with compelling visuals, clear call-to-action buttons, and relevant content to encourage user interaction.",
    //   Price: [
    //     { Basic: 80, Description: "Includes 3 elements - About synposis, Contact synopsis, and 1 other element." },
    //     { Advanced: 120, Description: "Includes 5 elements - About synposis, Contact synopsis, and 3 other elements." },
    //     { AdvancedAnimated: 200, Description: "Includes 5 elements - About synposis, Contact synopsis, and 3 other elements, plus 3 animations, advanced styling and layouts, and page loader." }
    //   ],
    //   ID: 12,
    //   Type: "Development"
    // },
    {
        ID: ID++,
        Type: NavList[1],
        Title: "Domain Name (Hosting)",
        Description: "We register and manage the domain name for the website, and ensure it is securely connected to the World Wide Web. Domain name management is crucial to maintaining the integrity of your online presence and protecting its digital identity.",
        Tiers: [
            { Price: 65, Length: "Month", Extra: "" },
            { Price: 50, Length: "3 Years", Extra: "" }
        ],
        Inclusions: [
            "Domain Name Selection Assistance",
            "Domain Name Registration/Management",
            "Domain Name Renewal",
            "Domain Name Transfer",
            "Domain Name Security/Privacy",
        ],
        Policies: "Upon purchase of a Domain Name Service through Tiger Eye Technology, you will be invited tov an optional Domain selection process. This involves selecting a relevant and memorable domain name for your website. Following selection,Your domain name will be registered and available within 3 to 14 business days of your purchase date. If the domain name is not available, we will contact you to discuss alternative options. Domain names automatically renew each year unless otherwise agreed upon. You will be notified 30 days prior to the renewal date. If you do not wish to renew your domain name, you must notify us in writing at least 30 days prior to the renewal date. If you do not notify us in writing, your domain name will be renewed automatically. For three year plans, speak to a representative for more information. In some occasions, Tiger Eye Technology will handle setup of Nameserver and DNS, usually when a Domain Name is purchased with a Server Hosting Plan. For more information, speak to a representative. If you wish to transfer your domain name to another registrar, you must notify us in writing at least 30 days prior to the renewal date. Upon Receipt of notice, we will provide you with the timetable and expected completion time of the transfer. Most transfers occur within 7 to 14 business days. Security measures to protect the domain from threats such as phishing, cybersquatting, and unauthorized transfers are included with payment.",
        AssociatedServices: [0],
        Keywords: ["Domain", "Domain Name", "Domain Registration", "Domain Management", "Domain Renewal", "Domain Transfer", "Domain Security", "Domain Privacy"]
    },
    {
        ID: ID++,
        Type: NavList[1],
        Title: "Integrated Database (Hosting)",
        Description: "Database setup and configuration so your site can handle data storage. Required for web systems, user management systems, or data handling websites",
        Tiers: [
            { Price: 5, Length: "Monthly", Extra: "" },
            { Price: 60, Length: "Annually", Extra: "" },
            { Price: 180, Length: "3 Years", Extra: "" },
        ],
        Inclusions: [
            "Database Configuration",
            "Assigned Database Manager",
            "Database Security - including secure routing and encryption",
            "Database Backups* Available upon request",
        ],
        Policies: "We will configure and manage the database for your website. This includes setting up the database, configuring it to work with your website, and managing it to ensure it runs smoothly. We will provide support for the database, including regular backups and maintenance - available upon request. If support requests exceeds 30 minutes in a given 30 day period, additional fees may be charged. Backups will be provided upon request. If you do not request a backup, no backup will be taken. Backup requests will be fulfilled in the order in which they are received. Upon receipt of a backup request, requests are fulfilled within 1 - 7 business days. We will provide security measures to protect your website and data from threats such as hacking, malware, and unauthorized access. These practices will include data escaping, amongst other industry standard practices. We will provide support for any issues or questions you may have regarding your database, via your assigned database management specialist, and their availability. Database management specialists are required to respond within 1 hour to 3 business days, depending on the severity of the issue.",
        AssociatedServices: [],
        Keywords: ["Database", "Database Configuration", "Database Management", "Database Security", "Database Backups"]
    },
    {
        ID: ID++,
        Type: NavList[2],
        Title: "HTTPS Configuration",
        Description: "We implement HTTPS to ensure secure communication between your website and the user's browser.",
        Tiers: [
            { Price: 5, Length: "One-time", Extra: "" }
        ],
        Inclusions: [
            "HTTPS Configuration",
        ],
        Policies: "We will configure the website to use HTTPS, which ensures secure communication between the website and the user's browser. This is important for protecting sensitive information such as login credentials, payment details, and personal data. We will provide support for any issues or questions you may have regarding your HTTPS configuration. HTTPS configuration support is available upon request. If you require support, please contact us to discuss your needs.",
        AssociatedServices: [0],
        Keywords: ["HTTPS", "Secure", "Security"]
    },
    {
        ID: ID++,
        Type: NavList[2],
        Title: "SSL Certificate",
        Description: "We install an SSL certificate to ensure secure communication between the website and the user's browser. Most web browsers will display a padlock icon in the address bar to indicate that the website is secure.",
        Tiers: [
            { Price: 10, Length: "One-time", Extra: "" }
        ],
        Inclusions: [
            "SSL Certificate Installation",
            "SSL Certificate Management",
            "SSL Certificate Renewal",
            "SSL Certificate Support",
        ],
        Policies: "We will install an SSL certificate on your website to ensure secure communication between the website and the user's browser. This is important for protecting sensitive information such as login credentials, payment details, and personal data. We will provide support for any issues or questions you may have regarding your SSL certificate. SSL certificate support is available upon request. If you require support, please contact us to discuss your needs. SSL certificates automatically renew each year unless otherwise agreed upon. You will be notified 30 days prior to the renewal date. If you do not wish to renew your SSL certificate, you must notify us in writing at least 30 days prior to the renewal date. If you do not notify us in writing, your SSL certificate will be renewed automatically.",
        AssociatedServices: [0],
        Keywords: ["SSL", "SSL Certificate", "SSL Installation", "SSL Management", "SSL Renewal", "SSL Support"]
    },
    {
        ID: ID++,
        Type: NavList[3],
        Title: "Website Development/Graphic Design",
        Description: "Flexible Website Development Services for any need. We can develop website elements or graphics, add features, improve SEO, Create Responsive Design, improve performance, or update existing website content. Billed per hour following a project consultation *Tiger Eye Technology Complimentary Service",
        Inclusions: [
            "Project Strategic Planning Meeting *Tiger Eye Technology Complimentary Service",
            "Custom Project Request can include: Responsive Design, Content/Content Planning, Performance Optimization, Landing Page, About Page, Contact Page, Further Development, SEO, etc.",
        ],
        Policies: "Website Development/Design will begin following a project consultation. Approval is required prior to project start. Approval will be needed for: quote approval, half-payment, and project deliverables. Project deliverables will include expected deadlines. Invoices will be available upon request. For Development work involving pre-existing websites, we will require access to the website's backend, and any other relevant information. To prevent project delay, please be prepared to provide this information upon request. ",
        Tiers: [
            { Price: 20, Length: "15 minutes", Extra: "" }
        ],
        AssociatedServices: [0],
        Keywords: ["Website Development", "Graphic Design", "Responsive Design", "SEO", "Performance", "Content", "Content Planning", "Landing Page", "About Page", "Contact Page", "Further Development"]
    },
    {
        ID: ID++,
        Type: NavList[3],
        Title: "Strategic Consulting",
        Description: "Our professional team will meet with you to work through concepts, generate content, pull leg-work, create plans of action, create accountability schedules, provide industry insight, and other such necessities on your behalf. Includes 30 minute content planning meeting with design specialist.",
        Inclusions: [
            "30 Minute Content Planning Meeting",
            "Meeting can include: Provided Industry Insight, Content Generation, Accountability Scheduling, and other such necessities.",
        ],
        Policies: "Half-Payment is expected prior to scheduling consultation meeting. Upon conclusion of meeting, final payment is expected. Deliverables will be decided upon on a per-meeting basis. Invoices will be available upon request. ",
        Tiers: [
            { Price: 40, Length: "One-time", Extra: "" }
        ],
        AssociatedServices: [0, 5],
        Keywords: ["Strategic Consulting", "Consulting", "Content Planning", "Content Generation", "Accountability Scheduling", "Industry Insight"]
    },
    {
        ID: ID++,
        Type: NavList[3],
        Title: "SEO",
        Description: "We optimize the website for search engines to improve its ranking and visibility.",
        Inclusions: [
            "Can include: SEO Optimization (On-Page), Keyword Research, Content Creation, Link building, Compliance with Search Engine Guidelines)",
            "SEO Support",
        ],
        Policies: "We will optimize the website for search engines to improve its ranking and visibility. This includes optimizing the website content, meta tags, and other elements to make it more search engine friendly. We will provide support for any issues or questions you may have regarding your SEO. SEO support is available upon request. If you require support, please contact us to discuss your needs.",
        Tiers: [
            { Price: 25, Length: "Hourly", Extra: "" }
        ],
        AssociatedServices: [],
        Keywords: ["SEO", "SEO Optimization", "Keyword Research", "Content Creation", "Link Building", "Compliance with Search Engine Guidelines"]
    },
    {
        ID: ID++,
        Type: NavList[4],
        Title: "Logo Design",
        Description: "Our team of premier designers will custom create a unique and memorable brand logo for your business/project. Includes .png, .jpeg, .tiff files",
        Inclusions: [
            "Design Session (1 x 30 minute Design Session)",
            "Graphic Design Labor",
            "Logo Design Portfolio",
            "Logo Design Support",
        ],
        Policies: "Logo Design will begin with a design session, after which a quote will be approved prior to the start of the project. Project will include creating a unique and memorable brand logo for the business. This includes designing the logo, creating different versions of the logo via premier graphic design methods, and providing the logo in different file formats. We will provide support for any issues or questions you may have regarding your logo design, and make available the draft logo design throughout the project, upon request. If you require support, please contact us to discuss your needs.",
        Tiers: [
            { Price: 100, Length: "One-time", Extra: "" }
        ],
        AssociatedServices: [5],
        Keywords: ["Logo", "Logo Design", "Graphic Design", "Logo Portfolio"]
    },
    {
        ID: ID++,
        Type: NavList[4],
        Title: "Hexadecimal Color Scheme",
        Description: "We create a personalized color scheme for the business, hand selecting colors to create a memorable and identifiable experience for existing/potential customers. Includes HEXCodes.",
        Inclusions: [
            "Design Session (1 x 30 minute Design Session)",
            "Color Scheme Research",
            "Color Scheme Support",
        ],
        Policies: "Color Scheme Design will begin with a design session, after which a quote will be approved prior to the start of the project. Project will include creating a personalized color scheme for the business. This includes designing the color scheme, creating different versions of the color scheme, and providing the color scheme in different file formats. We will provide support for any issues or questions you may have regarding your color scheme design, and make available the draft color scheme design throughout the project, upon request. If you require support, please contact us to discuss your needs.",
        Tiers: [
            { Price: 100, Length: "One-time", Extra: "" }
        ],
        AssociatedServices: [5],
        Keywords: ["Color Scheme", "Color Scheme Design", "Color Scheme Research", "Color Scheme Support"]
    },
    {
        ID: ID++,
        Type: NavList[4],
        Title: "Typography",
        Description: "We create a personalized font scheme for the business, to create an immersive brand experience. Seamless integration of typography into the brand experience is crucial for brand recognition and customer retention.",
        Inclusions: [
            "Design Session (1 x 30 minute Design Session)",
            "Typography Research",
            "Typography Support",
        ],
        Policies: "Typography Design will begin with a design session, after which a quote will be approved prior to the start of the project. Project will include creating a personalized font scheme for the business. This includes designing the font scheme, creating different versions of the font scheme, and providing the font scheme in different file formats. We will provide support for any issues or questions you may have regarding your font scheme design, and make available the draft font scheme design throughout the project, upon request. If you require support, please contact us to discuss your needs.",
        Tiers: [
            { Price: 100, Length: "One-time", Extra: "" }
        ],
        AssociatedServices: [],
        Keywords: ["Typography", "Typography Design", "Typography Research", "Typography Support"]
    },
    // {
    //   Title: "Social Media Marketing",
    //   Description: "We manage and promote the website on social media platforms to increase its visibility and reach.",
    //   Price: {
    //     Monthly: 50,
    //   },
    //   ID: 20,
    //   Type: "Marketing"
    // },
    // {
    //   Title: "Email Marketing",
    //   Description: "We manage and promote the website through email marketing campaigns to increase its visibility and reach.",
    //   Price: {
    //     Monthly: 50,
    //   },
    //   ID: 21,
    //   Type: "Marketing"
    // },
    // {
    //   Title: "Content Marketing",
    //   Description: "We manage and promote the website through content marketing to increase its visibility and reach.",
    //   Price: {
    //     Monthly: 50,
    //   },
    //   ID: 22,
    //   Type: "Marketing"
    // },
    // {
    //   Title: "Search Engine Marketing",
    //   Description: "We manage and promote the website through search engine marketing to increase its visibility and reach.",
    //   Price: {
    //     Monthly: 50,
    //   },
    //   ID: 23,
    //   Type: "Marketing"
    // },
    // {
    //   Title: "Consulting",
    //   Description: "We provide consulting services for website development, marketing, and branding.",
    //   Price: {
    //     hourly: 50,
    //   },
    //   ID: 24,
    //   Type: "Consulting"
    // },
];
var WebsiteAdvancedServices = [
    "E-Commerce Launch",
    "Membership systems",
    "Forums",
    "Reservations Systems",
    "Listing Systems",
    "Directories",
    "Custom Coding",
    "Custom Landing Page Design and Development",
    "Registration Systems",
    "Scheduling Systems",
    "Implementation of Security Measures",
    "High Traffic Website Optimization",
    "Media/news websites with extended category functionality",
];

class EC_Functions {
    constructor(router, userService, http) {
        this.router = router;
        this.userService = userService;
        this.http = http;
        /*
            THIS FILE TO ACT AS CONTROLLER OF ALL DATA AND FUNCTIONS FOR E-COMMERCE PAGE(s)
        */
        /*
    
            Bugs:
            
    
        */
        // VARS //////////////////////////////////////////////////
        this.cartItems = new BehaviorSubject([]);
        this.Cart = this.cartItems.asObservable(); //a subscription that when updated, updates every component subscribed to it
        //
        this.cartTotal = new BehaviorSubject(0);
        this.CartTotal = this.cartTotal.asObservable(); //a subscription that when updated, updates every component subscribed to it
        //
        this.AllAvailable = [...Services, ...Packages]; //all available service and package items
        //view
        this.view = eRouteKey;
        this.lView = lRouteKey;
        this.apiUrl = 'https://api.exchangerate-api.com/v4/latest/USD';
        this.Checkout = this.Checkout.bind(this);
        this.isCartEmpty = this.isCartEmpty.bind(this);
    }
    //change AllAvailable
    ChangePackages(input) {
        this.AllAvailable = input;
    }
    // Method to get the current value of the variable
    // CART INTERACTION FUNCTIONS //////////////////////////////////////////////
    getCartt(update = false) {
        //for broken cart uncomment below
        //this.ClearCart()
        const cartJson = localStorage.getItem("cart") ?? "[]"; //gets local storage for page reload scenario
        let newCart = JSON.parse(cartJson); //remove formating
        this.cartItems.next(newCart); //update the cart subscription
        let cart = this.cartItems.value; //set return var to the value of the cartitems
        // console.log(cart)
        //return a formated version of the cart instead of its value if needed
        if (update) {
            return this.removeUndefinedProperties(newCart);
        }
        return cart;
    }
    //handles the cart and differing ways of interacting with it
    UpdateCart(item, Type = "add", num = null) {
        //num can either be an index to subtract, number to set to, or tier to filter in when adding item to cart
        const currentItems = this.getCartt(true); //gets formatted cart
        let updatedItems = []; //sets up the newcart array
        let itemContainsTier = false; //inits the if tiered boolean
        //checks if item contains the same tiers
        for (const [key, value] of Object.entries(currentItems)) {
            //inits every item of the formatted cart
            const selectItem = value;
            let i;
            //if substracting, num is not an index
            if (Type === "sub") {
                i = 0;
            }
            else {
                i = num;
            }
            //the item is being compared to every item in the cart one by one
            //and if the compared item has some of the same tiers then the item has tiers
            //this is done as cart items will always remove the tiers that where not selected in the item info
            if (selectItem.Tiers.some((tier) => tier.Price === item.Tiers[i ?? 0].Price &&
                tier.Length === item.Tiers[i ?? 0].Length &&
                JSON.stringify(tier.Extra) === JSON.stringify(item.Tiers[i ?? 0].Extra))) {
                itemContainsTier = true;
            }
        }
        // HANDLE ITEM ALREADY EXISTS IN CART AND CONTAINS SAME TIERS
        if (currentItems[item.ID] && itemContainsTier) {
            if (Type === "add") {
                //loop throught the items of cart and add 1 to the quantity of item that matches item given
                for (const [key, value] of Object.entries(currentItems)) {
                    const selectItem = value;
                    if (selectItem.ID === item.ID
                        //safeguard measure
                        && typeof (selectItem.Quantity) !== "undefined") {
                        selectItem.Quantity += 1;
                    }
                }
            }
            else if (Type === "set") {
                //loop throught the items of cart and set to num for item that matches item given
                for (const [key, value] of Object.entries(currentItems)) {
                    const selectItem = value;
                    if (selectItem.ID === item.ID
                        //safeguard measure
                        && typeof (selectItem.Quantity) !== "undefined" && num !== null) {
                        selectItem.Quantity = num;
                        if (selectItem.Quantity <= 0) {
                            delete currentItems[item.ID]; // remove item with the same ID from cart
                        }
                    }
                }
            }
            else if (Type === "sub") {
                //loop throught the items of cart and remove 1 to the quantity of item that matches item given
                for (const [key, value] of Object.entries(currentItems)) {
                    const selectItem = value;
                    if (selectItem.ID === item.ID
                        //safeguard measure
                        && typeof (selectItem.Quantity) !== "undefined") {
                        selectItem.Quantity -= 1;
                        if (selectItem.Quantity <= 0) {
                            delete currentItems[item.ID]; // remove item with the same ID from cart
                        }
                    }
                }
            }
            else if (Type === "clear") {
                delete currentItems[item.ID]; // remove item with the same ID from cart
            }
            updatedItems = currentItems; //update after currentItems got modified either by removing or changing quantity
        }
        else {
            // Add Item (Doesn't exist already or has different tier)
            item.Quantity = 1;
            //if adding item with multiple tiers, filter only to selected num tier
            if (num !== null) {
                let filteredTiers = item.Tiers.filter((_, i) => i === num);
                //set tier to the filtered tier
                item.Tiers = filteredTiers;
            }
            //create & sort keys by ID (removing duplicate IDs)
            updatedItems = [...Object.values(currentItems), item].reduce((acc, curr) => {
                acc[curr.ID] = curr;
                return acc;
            }, {});
        }
        localStorage.setItem("cart", JSON.stringify(updatedItems)); //jsonfy the updated cart and set it to local storage
        this.cartItems.next(updatedItems); //update the cart subscription with new one
        return;
    }
    ClearCart() {
        //update subscription with empty cart
        this.cartItems.next([]);
        //synch local storage
        localStorage.removeItem("cart");
        return;
    }
    ConstructStoreItems() {
        return this.AllAvailable;
    }
    ViewProductInfo(ID, Refresh = true) {
        let productArray = this.AllAvailable;
        // get item that has ID in objects object array
        let filtered = productArray.filter((item) => item.ID === ID);
        const [filteredItem] = filtered;
        localStorage.setItem("ProductView", JSON.stringify(filteredItem));
        if (Refresh) {
            this.router.navigate(["/product-view"]);
        }
    }
    getPrice(item) {
        let price;
        price = item.Tiers[0].Price * (item.Quantity ?? 1);
        return price;
    }
    getcartTotal(cart, convert = null) {
        let total = 0;
        // Loop through the cart summing by multiplying the price and quantity of the tier selected
        for (const [key, value] of Object.entries(cart)) {
            const IndiItem = value;
            let itemTotal = IndiItem.Tiers[0].Price * (IndiItem.Quantity ?? 1);
            // Convert to EUR if 'convert' is 'EUR'
            if (convert?.toUpperCase() === 'EUR') {
                itemTotal *= 0.93; // 11/1/2024 Example conversion rate from USD to EUR
                // convert total to 000.00 format
                itemTotal = Math.round(itemTotal * 100) / 100;
            }
            total += itemTotal;
        }
        //this.cartTotal.next(Number(total)); // THIS BROKE MY CODE Update subscription of total with new total
        return total;
    }
    ConvertCurrency(amount, roundTo = null) {
        amount *= 0.93; // 11/1/2024 Example conversion rate from USD to EUR
        if (roundTo === "decimal") {
            amount = Math.round(amount * 100) / 100;
        }
        else {
            amount = Math.round(amount);
        }
        return amount;
    }
    // E-COMMERCE PAGE NAVIGATION FUNCTIONS ////////////////////////////////////
    async Checkout() {
        // code that show checkout page
        if (this.isCartEmpty() == false) {
            this.router.navigate(['/' + this.view.checkout.path]);
        }
    }
    async ViewCart() {
        //Check if user is logged in before continuing to the cart page.
        const IsUserLoggedIn = await (this.userService.isLoggedIn());
        if (IsUserLoggedIn) {
            //Check if the cart contains items first.
            if (!this.isCartEmpty()) {
                this.router.navigate(['/' + this.view.cart.path]);
            }
        }
        //If not logged in, then go log in.
        else if (!IsUserLoggedIn) {
            this.router.navigate(['/' + this.lView.login.path]);
        }
    }
    isCartEmpty() {
        let cart = this.getCartt();
        if (Object.keys(cart).length > 0) {
            return false; //Cart isn't empty.
        }
        else {
            return true; //Cart is empty.
        }
    }
    // Helper Functions //////////////////////////////////////////////////////
    removeUndefinedProperties(obj) {
        const cleanedObj = {};
        for (const key in obj) {
            if (key !== 'undefined' && obj.hasOwnProperty(key)) {
                cleanedObj[key] = obj[key];
            }
        }
        return cleanedObj; //return formatted cart
    }
    getUsdToEurRate() {
        return this.http.get(this.apiUrl).pipe(map$1((response) => response.rates.EUR));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: EC_Functions, deps: [{ token: i1.Router }, { token: IndexedDBService }, { token: i1$1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: EC_Functions, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: EC_Functions, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i1.Router }, { type: IndexedDBService }, { type: i1$1.HttpClient }]; } });

class ShopNavComponent {
    constructor() {
        this.NavItems = NavList;
    }
    scrollToSection(sectionId) {
        const element = document.getElementById(sectionId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShopNavComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ShopNavComponent, selector: "ec-shop-nav", ngImport: i0, template: "<div class=\"NavItems\">\n    <div (click)=\"scrollToSection(nav)\" *ngFor=\"let nav of NavItems\">\n        <p>\n            {{ nav }}\n        </p>\n    </div>\n</div>", styles: [".NavItems{display:flex;justify-content:space-around;padding:10px 0;position:sticky;background:#290c3cb3;flex-wrap:wrap}.NavItems div{text-align:center;padding:5px;cursor:pointer;color:#fff;border-bottom:solid 2px white;border-top:solid 2px white}.NavItems div:hover{color:var(--color3);border-bottom:solid 2px var(--color3);border-top:solid 2px var(--color3)}.NavItems div p{font-size:.8rem}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShopNavComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ec-shop-nav', template: "<div class=\"NavItems\">\n    <div (click)=\"scrollToSection(nav)\" *ngFor=\"let nav of NavItems\">\n        <p>\n            {{ nav }}\n        </p>\n    </div>\n</div>", styles: [".NavItems{display:flex;justify-content:space-around;padding:10px 0;position:sticky;background:#290c3cb3;flex-wrap:wrap}.NavItems div{text-align:center;padding:5px;cursor:pointer;color:#fff;border-bottom:solid 2px white;border-top:solid 2px white}.NavItems div:hover{color:var(--color3);border-bottom:solid 2px var(--color3);border-top:solid 2px var(--color3)}.NavItems div p{font-size:.8rem}\n"] }]
        }] });

class TickMarkerComponent {
    constructor(EC_Func, userService) {
        this.EC_Func = EC_Func;
        this.userService = userService;
        this.hide = false;
        this.Cart = this.EC_Func.getCartt();
    }
    ngOnInit() {
        // Update Cart and Associated Vars 
        this.EC_Func.Cart.subscribe(items => {
            this.Cart = items;
        });
        this.userService.USERDATA$.pipe(take$1(1)).subscribe((data) => {
            this.CustomPackages = data.SETTINGS.Packages;
        });
        if (this.CustomPackages) {
            this.hide = true;
        }
    }
    //update cart given the the item in cart that matches ID and operator
    updateQuantity(id, delta) {
        if (typeof (delta) === "string") {
            if (delta === "+") {
                this.EC_Func.UpdateCart(this.Cart[id], "add");
            }
            else {
                this.EC_Func.UpdateCart(this.Cart[id], "sub");
            }
        }
        else {
            this.EC_Func.UpdateCart(this.Cart[id], "set", delta);
        }
    }
    getQuantity(id) {
        return this.Cart[id].Quantity ?? 0;
    }
    //get value from input, parse to num and call updatequantity with it
    updateC(id, event) {
        const inputElement = event.target;
        if (inputElement && inputElement.value !== null) {
            const value = inputElement.value;
            const numericValue = parseFloat(value);
            if (!isNaN(numericValue)) {
                this.updateQuantity(id, numericValue);
            }
            inputElement.value = '';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TickMarkerComponent, deps: [{ token: EC_Functions }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: TickMarkerComponent, selector: "app-tick-marker", inputs: { id: "id" }, ngImport: i0, template: "<div class='cart-item' *ngIf=\"!hide\" >\n    <!-- subtract -->\n    <button class=\"minus\" (click)=\"updateQuantity(id, '-')\">-</button>\n    <!-- set -->\n    <input type=\"number\" id=\"numberInput\" (change)=\"updateC(id, $event)\" [placeholder]=\"getQuantity(id)\">\n    <!-- add -->\n    <button class=\"plus\" (click)=\"updateQuantity(id, '+')\">+</button>\n</div>", styles: [".cart-item{display:flex;align-items:center;justify-content:space-between;padding:10px;border:1px solid #ccc;border-radius:5px;margin-bottom:10px}.quantity-btn{background-color:#f0f0f0;border:1px solid #ccc;color:#333;font-size:16px;padding:8px 12px;cursor:pointer;border-radius:5px}.quantity-btn:hover{background-color:#e0e0e0}.quantity-btn.minus{margin-right:5px}.quantity-btn.plus{margin-left:5px}.quantity-input{width:1px;margin:0 10px;padding:8px;font-size:16px;border:1px solid #ccc;border-radius:5px;text-align:center}input[type=number]{appearance:textfield}input[type=number]::-webkit-outer-spin-button,input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: TickMarkerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-tick-marker', template: "<div class='cart-item' *ngIf=\"!hide\" >\n    <!-- subtract -->\n    <button class=\"minus\" (click)=\"updateQuantity(id, '-')\">-</button>\n    <!-- set -->\n    <input type=\"number\" id=\"numberInput\" (change)=\"updateC(id, $event)\" [placeholder]=\"getQuantity(id)\">\n    <!-- add -->\n    <button class=\"plus\" (click)=\"updateQuantity(id, '+')\">+</button>\n</div>", styles: [".cart-item{display:flex;align-items:center;justify-content:space-between;padding:10px;border:1px solid #ccc;border-radius:5px;margin-bottom:10px}.quantity-btn{background-color:#f0f0f0;border:1px solid #ccc;color:#333;font-size:16px;padding:8px 12px;cursor:pointer;border-radius:5px}.quantity-btn:hover{background-color:#e0e0e0}.quantity-btn.minus{margin-right:5px}.quantity-btn.plus{margin-left:5px}.quantity-input{width:1px;margin:0 10px;padding:8px;font-size:16px;border:1px solid #ccc;border-radius:5px;text-align:center}input[type=number]{appearance:textfield}input[type=number]::-webkit-outer-spin-button,input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}\n"] }]
        }], ctorParameters: function () { return [{ type: EC_Functions }, { type: IndexedDBService }]; }, propDecorators: { id: [{
                type: Input
            }] } });

class ItemsdisplayComponent {
    constructor(EC_Func, router) {
        this.EC_Func = EC_Func;
        this.router = router;
        // Vars
        this.Total = 0;
        //to show total
        // getTotal() {
        //   return Object.values(this.Cart).reduce((total, item: any) => {
        //     const price = item.Tiers[0].Price;  // Assuming you're using the first tier for the price
        //     const quantity = item.Quantity ?? 1; // Default to 1 if no quantity is provided
        //     return total + price * quantity;
        //   }, 0);
        // }
        this.Checkout = this.EC_Func.Checkout;
        this.showCheckout = this.EC_Func.Checkout;
        this.isCartEmpty = this.EC_Func.isCartEmpty;
        this.ClearCart = this.EC_Func.ClearCart;
        this.getCartt = this.EC_Func.getCartt;
        this.getcartTotal = this.EC_Func.getcartTotal;
        this.Cart = this.EC_Func.getCartt();
        this.Total = this.EC_Func.getcartTotal(this.Cart);
    }
    ngOnInit() {
        // Update Cart and Associated Vars 
        this.EC_Func.Cart.subscribe(items => {
            this.Cart = items;
            this.Total = this.EC_Func.getcartTotal(this.Cart);
        });
    }
    trackByFn(index, item) {
        return item.id; // or any unique property of the item
    }
    Price_OutputFilter(Input) {
        return Input[0].Price.toLocaleString('en-US', { style: 'currency', currency: 'USD' }) + " / " + (Input[0].Length ?? " ");
    }
    Remove(item) {
        this.EC_Func.UpdateCart(item, "clear");
    }
    Clear() {
        this.EC_Func.ClearCart();
    }
    //side cart --> cart --> checkout
    CheckoutOrView() {
        if (this.router.url === '/cart') {
            this.EC_Func.Checkout();
        }
        else {
            this.EC_Func.ViewCart();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ItemsdisplayComponent, deps: [{ token: EC_Functions }, { token: i1.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ItemsdisplayComponent, selector: "ec-itemsdisplay", ngImport: i0, template: "<div class=\"ItemsHolderBox\">\n    <div class=\"StickySelector\" style=\"margin-top: -50px;\">\n        <button class=\"is-primary\" style=\"font-size: 0.8em;\" (click)=\"Clear()\">Remove All</button>\n    </div>\n\n    <div *ngIf=\"isCartEmpty() == false\">\n        <div class=\"ItemBox\" *ngFor=\"let item of Cart | keyvalue; trackBy: trackByFn\">\n            <div class=\"\" style=\"padding: 0.5em;\">\n                <button class=\"button button2\" style=\"font-size: 0.5em;\" (click)=\"Remove(item.value)\">X</button>\n                <h5><b>{{ item.value.Title }}</b></h5>\n                <p>\n                    {{ item.value.Description | slice:0:30 }}...\n                    <br />\n                    <a style=\"cursor: pointer; color: var(--Color2D)\"\n                        (click)=\"this.EC_Func.ViewProductInfo(item.value.ID)\">View</a>\n                </p>\n                <div style=\"text-align: right; margin-top: -100px;\">\n                    <p>{{ Price_OutputFilter(item.value.Tiers) }}</p>\n                    <p>\n                        x {{ item.value.Quantity ?? 1 }}\n                    </p>\n                    <p>\n                        SubTotal = {{ getcartTotal(Cart) | currency }} <span class=\"CurrencyEurope\">({{ getcartTotal(Cart,'EUR') |\n                            currency:'EUR' }})</span>\n                    </p>\n                </div>\n                <app-tick-marker [id]=\"item.value.ID\"></app-tick-marker>\n            </div>\n        </div>\n    </div>\n\n    <div *ngIf=\"isCartEmpty() == true\">\n        <div class=\"ItemBox\">\n            <p>Your cart is empty!</p>\n        </div>\n    </div>\n</div>\n<hr>\n<div class=\"ButtonSelector\">\n    <div class=\"total\">\n        <h4>Total: {{ getcartTotal(Cart) | currency }} <span class=\"CurrencyEurope\">({{ getcartTotal(Cart,'EUR') | currency:'EUR' }})</span>\n        </h4>\n    </div>\n\n    <button *ngIf=\"this.router.url != '/checkout'\" class=\"is-primary\" (click)=\"CheckoutOrView()\">\n        <a>Checkout</a>\n    </button>\n</div>", styles: [".ItemsHolderBox{padding:.5rem}.ItemBox{background:linear-gradient(45deg,#ffffff,transparent);color:var(--Color2);padding:.5rem;border:solid 2px white;box-shadow:var(--box-shadow);margin:.25rem}.StickySelector{position:sticky;top:0;right:0;display:flex;justify-content:flex-end}.ButtonSelector{padding:1rem;display:flex;justify-content:space-around}.ButtonSelector button{padding:.5rem;background:var(--color);color:#fff;border:none;cursor:pointer}.CurrencyEurope{color:var(--Color2L)}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: TickMarkerComponent, selector: "app-tick-marker", inputs: ["id"] }, { kind: "pipe", type: i3.SlicePipe, name: "slice" }, { kind: "pipe", type: i3.CurrencyPipe, name: "currency" }, { kind: "pipe", type: i3.KeyValuePipe, name: "keyvalue" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ItemsdisplayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ec-itemsdisplay', template: "<div class=\"ItemsHolderBox\">\n    <div class=\"StickySelector\" style=\"margin-top: -50px;\">\n        <button class=\"is-primary\" style=\"font-size: 0.8em;\" (click)=\"Clear()\">Remove All</button>\n    </div>\n\n    <div *ngIf=\"isCartEmpty() == false\">\n        <div class=\"ItemBox\" *ngFor=\"let item of Cart | keyvalue; trackBy: trackByFn\">\n            <div class=\"\" style=\"padding: 0.5em;\">\n                <button class=\"button button2\" style=\"font-size: 0.5em;\" (click)=\"Remove(item.value)\">X</button>\n                <h5><b>{{ item.value.Title }}</b></h5>\n                <p>\n                    {{ item.value.Description | slice:0:30 }}...\n                    <br />\n                    <a style=\"cursor: pointer; color: var(--Color2D)\"\n                        (click)=\"this.EC_Func.ViewProductInfo(item.value.ID)\">View</a>\n                </p>\n                <div style=\"text-align: right; margin-top: -100px;\">\n                    <p>{{ Price_OutputFilter(item.value.Tiers) }}</p>\n                    <p>\n                        x {{ item.value.Quantity ?? 1 }}\n                    </p>\n                    <p>\n                        SubTotal = {{ getcartTotal(Cart) | currency }} <span class=\"CurrencyEurope\">({{ getcartTotal(Cart,'EUR') |\n                            currency:'EUR' }})</span>\n                    </p>\n                </div>\n                <app-tick-marker [id]=\"item.value.ID\"></app-tick-marker>\n            </div>\n        </div>\n    </div>\n\n    <div *ngIf=\"isCartEmpty() == true\">\n        <div class=\"ItemBox\">\n            <p>Your cart is empty!</p>\n        </div>\n    </div>\n</div>\n<hr>\n<div class=\"ButtonSelector\">\n    <div class=\"total\">\n        <h4>Total: {{ getcartTotal(Cart) | currency }} <span class=\"CurrencyEurope\">({{ getcartTotal(Cart,'EUR') | currency:'EUR' }})</span>\n        </h4>\n    </div>\n\n    <button *ngIf=\"this.router.url != '/checkout'\" class=\"is-primary\" (click)=\"CheckoutOrView()\">\n        <a>Checkout</a>\n    </button>\n</div>", styles: [".ItemsHolderBox{padding:.5rem}.ItemBox{background:linear-gradient(45deg,#ffffff,transparent);color:var(--Color2);padding:.5rem;border:solid 2px white;box-shadow:var(--box-shadow);margin:.25rem}.StickySelector{position:sticky;top:0;right:0;display:flex;justify-content:flex-end}.ButtonSelector{padding:1rem;display:flex;justify-content:space-around}.ButtonSelector button{padding:.5rem;background:var(--color);color:#fff;border:none;cursor:pointer}.CurrencyEurope{color:var(--Color2L)}\n"] }]
        }], ctorParameters: function () { return [{ type: EC_Functions }, { type: i1.Router }]; } });

class SidecartComponent {
    constructor(EC_Func) {
        this.EC_Func = EC_Func;
        // Control Side Nav Cart
        this.ShowCart = false;
        // Vars
        this.Total = 0;
        this.Cart = this.EC_Func.getCartt();
        this.Total = this.EC_Func.getcartTotal(this.Cart);
    }
    Cart_Display() {
        this.ShowCart = !this.ShowCart;
    }
    ngOnInit() {
        // Update Cart and Associated Vars 
        this.EC_Func.Cart.subscribe(items => {
            this.Cart = items;
            this.Total = this.EC_Func.getcartTotal(this.Cart);
        });
    }
    trackByFn(index, item) {
        return item.ID; // or any unique property of the item
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SidecartComponent, deps: [{ token: EC_Functions }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SidecartComponent, selector: "ec-sidecart", ngImport: i0, template: "<div class=\"BackgroundPatternOverlay\">\n    <div (click)=\"Cart_Display()\" class=\"SideNavButton\" onload=\"loadSideNavCart()\">\n        <p>\n            <button class=\"button button2\"><</button>\n        </p>\n    </div>\n\n    <div class=\"sideNavCart\" [ngClass]=\"{'sideNavCart_open ': ShowCart, '': !ShowCart}\">\n        <div class=\"SideNavTitle\">\n            <p (click)=\"Cart_Display()\" class=\"SideNavButton\">\n                <button class=\"button button2\">></button>\n            </p>\n            <h4 style=\"margin-left: 20px;\">\n                My Selection | {{ Total | currency }}\n            </h4>\n        </div>\n        <ec-itemsdisplay></ec-itemsdisplay>\n    </div>\n</div>", styles: [".SideNavButton{position:fixed;top:50%;right:0;background-color:var(--color);width:20px;padding:5px;box-shadow:var(--box-shadow);cursor:pointer}.sideNavCart{position:fixed;top:0;right:0;width:300px;height:100%;background-color:var(--color4);z-index:1000;transform:translate(100%);transition:transform .3s ease-in-out;box-shadow:-5px 0 5px -5px #00000080;overflow-y:auto}.sideNavCart h4{color:#fff}.sideNavCart_open{transform:translate(0)}.closeButton{cursor:pointer;color:#fff}.SideNavTitle{display:flex;position:sticky;top:0;background:var(--color4);padding:.5rem}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: ItemsdisplayComponent, selector: "ec-itemsdisplay" }, { kind: "pipe", type: i3.CurrencyPipe, name: "currency" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SidecartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ec-sidecart', template: "<div class=\"BackgroundPatternOverlay\">\n    <div (click)=\"Cart_Display()\" class=\"SideNavButton\" onload=\"loadSideNavCart()\">\n        <p>\n            <button class=\"button button2\"><</button>\n        </p>\n    </div>\n\n    <div class=\"sideNavCart\" [ngClass]=\"{'sideNavCart_open ': ShowCart, '': !ShowCart}\">\n        <div class=\"SideNavTitle\">\n            <p (click)=\"Cart_Display()\" class=\"SideNavButton\">\n                <button class=\"button button2\">></button>\n            </p>\n            <h4 style=\"margin-left: 20px;\">\n                My Selection | {{ Total | currency }}\n            </h4>\n        </div>\n        <ec-itemsdisplay></ec-itemsdisplay>\n    </div>\n</div>", styles: [".SideNavButton{position:fixed;top:50%;right:0;background-color:var(--color);width:20px;padding:5px;box-shadow:var(--box-shadow);cursor:pointer}.sideNavCart{position:fixed;top:0;right:0;width:300px;height:100%;background-color:var(--color4);z-index:1000;transform:translate(100%);transition:transform .3s ease-in-out;box-shadow:-5px 0 5px -5px #00000080;overflow-y:auto}.sideNavCart h4{color:#fff}.sideNavCart_open{transform:translate(0)}.closeButton{cursor:pointer;color:#fff}.SideNavTitle{display:flex;position:sticky;top:0;background:var(--color4);padding:.5rem}\n"] }]
        }], ctorParameters: function () { return [{ type: EC_Functions }]; } });

class ShopViewComponent {
    constructor(EC_Func, router) {
        this.EC_Func = EC_Func;
        this.router = router;
        //view
        this.view = eRouteKey;
        // E-Commerce Setup
        this.NavItems = NavList; // organize by Type
        this.AllAvailable = this.EC_Func.ConstructStoreItems();
        this.CustomServices = WebsiteAdvancedServices;
        this.ViewProductInfo = this.EC_Func.ViewProductInfo;
    }
    // Functions
    addToCart(item) {
        if (item && item.Tiers) {
            let priceKeys = Object.keys(item.Tiers).length;
            //If the product's price has more than 1 key, it has multiple tiers.
            if (priceKeys > 1) {
                this.EC_Func.ViewProductInfo(item.ID);
            }
            else {
                this.EC_Func.UpdateCart(item);
            }
        }
    }
    filterServices(Category) {
        return this.AllAvailable.filter(s => s.Type === Category);
    }
    // Product
    projectRequest() {
        // redirect to project request page 
        // in the future create contact.route
        this.router.navigate(['/contact']);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShopViewComponent, deps: [{ token: EC_Functions }, { token: i1.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ShopViewComponent, selector: "ec-shop-view", ngImport: i0, template: "<div style=\"padding: 2rem; background: white;\">\n    <br />\n    <br />\n    <div>\n        <h1>Available Services</h1>\n        <h2>Browse our selection of available services below</h2>\n    </div>\n    <br />\n    <br />\n</div>\n\n<div class=\"BackgroundPattern\">\n    <ec-sidecart></ec-sidecart>\n    <ec-shop-nav></ec-shop-nav>\n</div>\n\n<div class=\"CategoryDisplay\" *ngFor=\"let Category of NavItems\">\n    <br />\n    <h1 [id]=\"this.Category\">\n        {{ this.Category }}\n    </h1>\n    \n    <div class=\"Products_Display\" *ngFor=\"let service of filterServices(Category)\">\n        <div class=\"Product_Info\" (click)=\"ViewProductInfo(service.ID)\">\n            <h3>{{ service.Title}}</h3>\n            <p>{{ service.Description }}</p>\n        </div>\n        <input class=\"is-primary\" type=\"button\" value=\"Add to Cart\" (click)=\"addToCart(service)\">\n    </div>\n</div>\n", styles: [".CategoryDisplay{padding:.5rem}.CategoryDisplay h1{color:var(--color);padding:1rem}.Products_Display{display:flex;justify-content:space-between;margin:0 20px;padding:20px 0;border-bottom:1px solid #e0e0e0}.Product_Info{border-radius:10px;box-shadow:var(--box-shadow);padding:1rem;cursor:pointer}.Product_Info a{color:var(--color)}.Products_Display div{width:75%}.Products_Display button{background-color:var(--color);color:#fff;padding:10px 20px;width:100px;height:65px;margin:auto;border:none;cursor:pointer;box-shadow:var(--box-shadow);border-radius:var(--borderradius);font-size:12px}.Products_Display button:hover{background-color:gold;color:#000}h2{color:var(--color)}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: ShopNavComponent, selector: "ec-shop-nav" }, { kind: "component", type: SidecartComponent, selector: "ec-sidecart" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShopViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ec-shop-view', template: "<div style=\"padding: 2rem; background: white;\">\n    <br />\n    <br />\n    <div>\n        <h1>Available Services</h1>\n        <h2>Browse our selection of available services below</h2>\n    </div>\n    <br />\n    <br />\n</div>\n\n<div class=\"BackgroundPattern\">\n    <ec-sidecart></ec-sidecart>\n    <ec-shop-nav></ec-shop-nav>\n</div>\n\n<div class=\"CategoryDisplay\" *ngFor=\"let Category of NavItems\">\n    <br />\n    <h1 [id]=\"this.Category\">\n        {{ this.Category }}\n    </h1>\n    \n    <div class=\"Products_Display\" *ngFor=\"let service of filterServices(Category)\">\n        <div class=\"Product_Info\" (click)=\"ViewProductInfo(service.ID)\">\n            <h3>{{ service.Title}}</h3>\n            <p>{{ service.Description }}</p>\n        </div>\n        <input class=\"is-primary\" type=\"button\" value=\"Add to Cart\" (click)=\"addToCart(service)\">\n    </div>\n</div>\n", styles: [".CategoryDisplay{padding:.5rem}.CategoryDisplay h1{color:var(--color);padding:1rem}.Products_Display{display:flex;justify-content:space-between;margin:0 20px;padding:20px 0;border-bottom:1px solid #e0e0e0}.Product_Info{border-radius:10px;box-shadow:var(--box-shadow);padding:1rem;cursor:pointer}.Product_Info a{color:var(--color)}.Products_Display div{width:75%}.Products_Display button{background-color:var(--color);color:#fff;padding:10px 20px;width:100px;height:65px;margin:auto;border:none;cursor:pointer;box-shadow:var(--box-shadow);border-radius:var(--borderradius);font-size:12px}.Products_Display button:hover{background-color:gold;color:#000}h2{color:var(--color)}\n"] }]
        }], ctorParameters: function () { return [{ type: EC_Functions }, { type: i1.Router }]; } });

class ProductTierComponent {
    constructor(EC_Func, router) {
        this.EC_Func = EC_Func;
        this.router = router;
        //view
        this.view = eRouteKey;
        this.checkmark = checkmark;
        this.ProductInclusions = [];
        this.Convert = this.EC_Func.ConvertCurrency;
    }
    ngOnInit() {
        this.ProductTiers = this.Product.Tiers;
        this.ProductInclusions = this.Product.Inclusions;
        //console.log(this.ProductTiers); // for testing purposes
    }
    onClick(index) {
        if (this.CustomPackages) {
            this.EC_Func.UpdateCart(this.Product, "add", index);
            this.router.navigate(['/' + this.view.checkout.path]);
        }
        else {
            this.EC_Func.UpdateCart(this.Product, "add", index);
            this.router.navigate(['/' + this.view.ecommerce.path]);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProductTierComponent, deps: [{ token: EC_Functions }, { token: i1.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ProductTierComponent, selector: "ec-product-tier", inputs: { Product: "Product", CustomPackages: "CustomPackages" }, ngImport: i0, template: "<div *ngFor=\"let tier of ProductTiers; let i = index\" class=\"product-tier-card\">\n    <h1>\n        {{tier.Title}}\n    </h1>\n    <hr>\n    <h1>\n        {{tier.Price ?  (Convert(tier.Price) | currency:'EUR') : \"Priced by Request\"}} <p> {{tier.Length ? '/' + tier.Length : \"\" }}</p>\n    </h1>\n    <div class=\"productInner\">\n        <p *ngFor=\"let includes of ProductInclusions\"><ion-icon style=\"color: green;\" [icon]=\"checkmark\"></ion-icon> {{includes}}</p>\n        <p *ngFor=\"let extras of tier.Extra\"><ion-icon style=\"color: green;\" [icon]=\"checkmark\"></ion-icon> {{extras}}</p>\n    </div>\n    <br />\n    <br />\n    <ion-button (click)=\"onClick(i)\">Instant Purchase</ion-button>\n</div>", styles: [".product-tier-card{display:inline-block;vertical-align:top;border-radius:25px;padding:2rem;margin:.5rem;background:linear-gradient(45deg,var(--Color),var(--ColorD),var(--ColorL));color:#fff;box-shadow:1px 1px 5px 1px var(--accentColor);text-align:center;max-width:350px}.productInner{background:#fff;border-radius:15px;padding:.5em;box-shadow:0 0 8px #595959;border:solid 2px #c3c3c3;color:#000;margin:auto}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: i4.IonButton, selector: "ion-button", inputs: ["buttonType", "color", "disabled", "download", "expand", "fill", "form", "href", "mode", "rel", "routerAnimation", "routerDirection", "shape", "size", "strong", "target", "type"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "pipe", type: i3.CurrencyPipe, name: "currency" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProductTierComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ec-product-tier', template: "<div *ngFor=\"let tier of ProductTiers; let i = index\" class=\"product-tier-card\">\n    <h1>\n        {{tier.Title}}\n    </h1>\n    <hr>\n    <h1>\n        {{tier.Price ?  (Convert(tier.Price) | currency:'EUR') : \"Priced by Request\"}} <p> {{tier.Length ? '/' + tier.Length : \"\" }}</p>\n    </h1>\n    <div class=\"productInner\">\n        <p *ngFor=\"let includes of ProductInclusions\"><ion-icon style=\"color: green;\" [icon]=\"checkmark\"></ion-icon> {{includes}}</p>\n        <p *ngFor=\"let extras of tier.Extra\"><ion-icon style=\"color: green;\" [icon]=\"checkmark\"></ion-icon> {{extras}}</p>\n    </div>\n    <br />\n    <br />\n    <ion-button (click)=\"onClick(i)\">Instant Purchase</ion-button>\n</div>", styles: [".product-tier-card{display:inline-block;vertical-align:top;border-radius:25px;padding:2rem;margin:.5rem;background:linear-gradient(45deg,var(--Color),var(--ColorD),var(--ColorL));color:#fff;box-shadow:1px 1px 5px 1px var(--accentColor);text-align:center;max-width:350px}.productInner{background:#fff;border-radius:15px;padding:.5em;box-shadow:0 0 8px #595959;border:solid 2px #c3c3c3;color:#000;margin:auto}\n"] }]
        }], ctorParameters: function () { return [{ type: EC_Functions }, { type: i1.Router }]; }, propDecorators: { Product: [{
                type: Input
            }], CustomPackages: [{
                type: Input
            }] } });

class ProductViewComponent {
    constructor(userService, EC_Func) {
        this.userService = userService;
        this.EC_Func = EC_Func;
        this.IsTiered = false;
        this.ShowCategories = false; // to change if categories is displayed or not 
        // NEW GLOBALS UPDATE
        this.userService.USERDATA$.pipe(take(1)).subscribe((userData) => {
            this.CustomPackages = userData.SETTINGS.Packages;
            this.EC_Func.ChangePackages(this.CustomPackages);
            this.EC_Func.ViewProductInfo(this.CustomPackages[0].ID, false);
        });
    }
    ngOnInit() {
        // if (this.CustomPackages) {
        //     this.EC_Func.ChangePackages(this.CustomPackages);
        //     this.EC_Func.ViewProductInfo(this.CustomPackages[0].ID, false);
        // }
        this.product = localStorage.getItem("ProductView"); //Get the service we want to view more information on.
        const productJson = localStorage.getItem("ProductView") ?? "[]"; // Use an empty array if nothing is in local storage
        this.product = JSON.parse(productJson);
        if (this.product && this.product.Tiers) {
            let priceKeys = Object.keys(this.product.Tiers).length;
            //If the product's price has more than 1 key, it has tiers.
            if (priceKeys > 1) {
                this.IsTiered = true;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProductViewComponent, deps: [{ token: IndexedDBService }, { token: EC_Functions }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ProductViewComponent, selector: "ec-product-view", inputs: { CustomPackages: "CustomPackages", ShowCategories: "ShowCategories" }, ngImport: i0, template: "<div class=\"ProductViewBox\">\n    <h1>{{this.product.Title}}</h1>\n    <p>{{this.product.Description}}</p>\n    <br />\n    <div *ngIf=\"ShowCategories\" style=\"display: inline-flex; flex-wrap: wrap;\" >\n        <p style=\"margin: auto; color: grey; font-style: italic;\">\n            Categories:\n        </p>\n        <p *ngFor=\"let key of this.product.Keywords\" class=\"tag\">{{key}}</p>\n        <br />\n    </div>\n    \n    <!-- <hr> -->\n    <ec-product-tier [Product]=\"product\" [CustomPackages] = \"this.CustomPackages\"></ec-product-tier>\n    <br />\n</div>", styles: [".ProductViewBox{padding:2rem}.tag{background-color:var(--Color2);color:#fff;padding:.5rem;border-radius:5px;margin:.5rem}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: ProductTierComponent, selector: "ec-product-tier", inputs: ["Product", "CustomPackages"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProductViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ec-product-view', template: "<div class=\"ProductViewBox\">\n    <h1>{{this.product.Title}}</h1>\n    <p>{{this.product.Description}}</p>\n    <br />\n    <div *ngIf=\"ShowCategories\" style=\"display: inline-flex; flex-wrap: wrap;\" >\n        <p style=\"margin: auto; color: grey; font-style: italic;\">\n            Categories:\n        </p>\n        <p *ngFor=\"let key of this.product.Keywords\" class=\"tag\">{{key}}</p>\n        <br />\n    </div>\n    \n    <!-- <hr> -->\n    <ec-product-tier [Product]=\"product\" [CustomPackages] = \"this.CustomPackages\"></ec-product-tier>\n    <br />\n</div>", styles: [".ProductViewBox{padding:2rem}.tag{background-color:var(--Color2);color:#fff;padding:.5rem;border-radius:5px;margin:.5rem}\n"] }]
        }], ctorParameters: function () { return [{ type: IndexedDBService }, { type: EC_Functions }]; }, propDecorators: { CustomPackages: [{
                type: Input
            }], ShowCategories: [{
                type: Input
            }] } });

// TESTING //////////////////
// export const environment = {
//     production: false,
//     stripePublishableKey: 'pk_test_51MX9JsJnTVlMHcuF3OXZrB4RWkNITjb3vOkxSl70WRzb7FXcYJIL9OJN2TkV5xFwTlVNpGrBJG1vZiWR38x6Osm800bRFS24SD',
// };
// LIVE //////////////////
const environment = {
    production: true,
    stripePublishableKey: 'pk_live_51MX9JsJnTVlMHcuFYA6RMZXmwBPsIMwZejqdPnFx4qBw3ablkIVivA5nFvANCpJNwPQXZRzKpX4iSX99Vn51v4uO00pWcvj09S',
};

class StripeService {
    constructor(ngZone) {
        this.ngZone = ngZone;
        this.stripeInstance = null;
        this.cleanupInterval = null;
        this.stripePublicKey = environment.stripePublishableKey;
    }
    initStripe(publishableKey) {
        return new Promise((resolve, reject) => {
            if (this.stripeInstance) {
                resolve(this.stripeInstance);
                return;
            }
            const script = document.createElement('script');
            script.src = 'https://js.stripe.com/v3/';
            script.async = true;
            script.onload = () => {
                this.stripeInstance = window.Stripe(publishableKey);
                resolve(this.stripeInstance);
            };
            script.onerror = (error) => reject(error);
            document.head.appendChild(script);
        });
    }
    async getStripe() {
        return await this.initStripe(this.stripePublicKey);
    }
    async getStripeElements() {
        const stripe = await this.initStripe(this.stripePublicKey);
        return stripe?.elements() || null;
    }
    cleanup() {
        this.ngZone.runOutsideAngular(() => {
            if (this.cleanupInterval) {
                clearInterval(this.cleanupInterval);
            }
            const performCleanup = () => {
                // Remove Stripe-related iframes
                const iframes = document.querySelectorAll('iframe[src*="stripe.com"]');
                iframes.forEach(iframe => iframe.remove());
                // Remove Stripe-related elements
                const stripeElements = document.querySelectorAll('[id^="stripe-"]');
                stripeElements.forEach(element => element.remove());
                // Remove Stripe script
                const stripeScript = document.querySelector('script[src*="stripe.com"]');
                if (stripeScript) {
                    stripeScript.remove();
                }
                // Clear Stripe from window object
                if (window.Stripe) {
                    delete window.Stripe;
                }
                // Reset Stripe instance
                this.stripeInstance = null;
            };
            // Perform initial cleanup
            performCleanup();
            // Continue cleaning up periodically for a short duration
            this.cleanupInterval = setInterval(performCleanup, 100);
            // Stop the periodic cleanup after 2 seconds
            setTimeout(() => {
                if (this.cleanupInterval) {
                    clearInterval(this.cleanupInterval);
                    this.cleanupInterval = null;
                }
            }, 2000);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: StripeService, deps: [{ token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: StripeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: StripeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i0.NgZone }]; } });

class PaymentService {
    constructor(http, API, ECF, stripeService) {
        this.http = http;
        this.API = API;
        this.ECF = ECF;
        this.stripeService = stripeService;
        this.stripe = null;
    }
    async getStripe() {
        if (!this.stripe) {
            this.stripe = await this.stripeService.getStripe();
        }
        return this.stripe;
    }
    createPaymentIntent(paymentMethod, customer) {
        const cart = this.ECF.getCartt();
        const total = this.ECF.getcartTotal(cart);
        const details = {
            "CALL": "eC0mm3rce",
            "amount": total * 100,
            "currency": "usd",
            "payment_method": paymentMethod.id,
            "customer": customer
        };
        return this.API.post(details, "eC0mm3rce");
    }
    async createPaymentMethod(card, customerID, billingDetails) {
        const stripe = await this.getStripe();
        if (!stripe || !card) {
            console.error('Card information is incomplete or invalid.');
            return undefined;
        }
        try {
            const { paymentMethod, error } = await stripe.createPaymentMethod({
                type: 'card',
                card: card,
                billing_details: billingDetails
            });
            if (error) {
                console.error('Stripe createPaymentMethod error:', error);
                return undefined;
            }
            else if (paymentMethod) {
                //Set customer ID.
                paymentMethod.customer = customerID;
                return paymentMethod;
            }
            return undefined;
        }
        catch (error) {
            console.error('Error creating payment method:', error);
            return undefined;
        }
    }
    async confirmPayment(clientSecret, paymentMethod) {
        const stripe = await this.getStripe();
        if (!stripe) {
            console.error('Stripe instance is not available.');
            return;
        }
        try {
            const { paymentIntent, error } = await stripe.confirmCardPayment(clientSecret, {
                payment_method: paymentMethod.id,
            });
            if (error) {
                console.error('Error confirming payment:', error);
            }
            else if (paymentIntent) {
                //console.log('PaymentIntent confirmed:', paymentIntent);
                // Send payment confirmation to your backend
                const paymentDetails = { "CALL": "eC0mm3rce", "paymentIntentId": paymentIntent.id, "paymentMethodId": paymentMethod.id };
                const response = await this.API.post(paymentIntent.id, "c0nf1rm");
                const result = await response.json();
                //console.log('Backend response:', result);
                if (result.status === 'succeeded') {
                    // Handle successful payment here
                    //console.log('Payment succeeded');
                }
                else {
                    // Handle other payment statuses here
                    //console.log('Payment not completed:', result.status);
                }
            }
        }
        catch (error) {
            //console.error('Error confirming payment:', error);
        }
    }
    cleanup() {
        this.stripe = null;
        this.stripeService.cleanup();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PaymentService, deps: [{ token: i1$1.HttpClient }, { token: ApiService }, { token: EC_Functions }, { token: StripeService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PaymentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: PaymentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1$1.HttpClient }, { type: ApiService }, { type: EC_Functions }, { type: StripeService }]; } });

class ProfilePhotoComponent {
    constructor(indexedDBService, errorHandlingService, Keys, http, Router) {
        this.indexedDBService = indexedDBService;
        this.errorHandlingService = errorHandlingService;
        this.Keys = Keys;
        this.http = http;
        this.Router = Router;
        this.Type = 'view';
        this.style = {};
        this.AllowGoToProfile = false;
        this.User = {};
        this.photoFailSafe = '/assets/Stockphoto.png';
        this.photoStyle = { 'background-image': '' };
        this.photoUploadIcon = cameraReverseOutline;
        this.isLoading$ = new BehaviorSubject(false);
        this.profilePhoto$ = new BehaviorSubject('/assets/Stockphoto.png');
        this.allowedFileTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        this.AllowedFileTypes = this.allowedFileTypes.join(', ');
        this.maxSizeInBytes = 30 * 1024 * 1024; // 30 MB
        this.PhotoLink = ';';
    }
    ngOnInit() {
        this.userSubscription = this.indexedDBService.USERDATA$.pipe(take$1(1)).subscribe(userData => {
            this.User = userData;
            let SettingCheck = userData ? userData.CONFIG : null;
            if (SettingCheck) {
                this.Domain = userData.CONFIG.URL;
                this.API = userData.CONFIG.URL + userData.CONFIG.API;
                this.Debug = userData.CONFIG.DEBUG;
            }
            if (this.PicUrl) {
                // this.profilePhoto$.next(this.PicUrl);
                // this.getProfilePhotoStyle();
                // console.log(this.profilePhoto$.value);
                this.renderProfilePhoto(this.PicUrl);
            }
            else {
                if (userData?.pictures) {
                    this.renderProfilePhoto(userData.pictures);
                }
            }
        });
    }
    ngOnDestroy() {
        this.userSubscription?.unsubscribe();
    }
    onFileSelected(event) {
        const file = event.target.files?.[0];
        if (!file) {
            this.errorHandlingService.setError({ Success: false, Message: 'No file selected.' });
            return;
        }
        if (!this.isValidFile(file))
            return;
        this.uploadPhoto(file);
    }
    getProfilePhoto() {
        this.renderProfilePhoto();
    }
    getProfilePhotoStyle() {
        let link = this.profilePhoto$.value;
        this.photoStyle = {
            'background-image': `url(${this.profilePhoto$.value})`,
            ...this.style
        };
        this.PhotoLink = link;
    }
    openFileInput() {
        this.fileInput?.nativeElement.click();
    }
    isValidFile(file) {
        if (!this.allowedFileTypes.includes(file.type)) {
            this.errorHandlingService.setError({
                Success: false,
                Message: `Invalid file format. Please select a ${this.allowedFileTypes.join(', ')} image.`
            });
            return false;
        }
        if (file.size > this.maxSizeInBytes) {
            this.errorHandlingService.setError({
                Success: false,
                Message: `File size exceeds ${this.maxSizeInBytes / 1024 / 1024}MB. Please select a smaller file.`
            });
            return false;
        }
        return true;
    }
    uploadPhoto(file) {
        this.isLoading$.next(true);
        const formData = new FormData();
        formData.append('file', file);
        formData.append('Type', 'ProfilePhoto');
        formData.append('current', this.profilePhoto$.value);
        formData.append('CALL', this.Keys.ProPhoto);
        formData.append('Sub', this.User.Ky);
        if (this.Debug === true) {
            console.log(Array.from(formData.entries()));
        }
        this.http.post(this.API, formData).pipe(catchError$1((error) => {
            this.errorHandlingService.setError({ Success: false, Message: error.message });
            return of(null);
        }), finalize(() => this.isLoading$.next(false))).subscribe(response => {
            if (this.Debug === true) {
                console.log(response);
            }
            if (response.Success) {
                this.indexedDBService.updateSession({ pictures: response.Token });
                this.errorHandlingService.setError(response.Message);
                setTimeout(() => {
                    //this.Router.navigate(['/profile']);
                    window.location.reload();
                }, 2000);
            }
            else {
                this.errorHandlingService.setError(response.Message);
            }
        });
    }
    async renderProfilePhoto(url) {
        if (!url) {
            url = '/assets/Stockphoto.png';
        } // fallback image
        // FORCE DOMAIN LINK TO URL
        url = this.Domain + url;
        try {
            await this.http.head(url).toPromise();
            let link = `${url}?t=${new Date().getTime()}`;
            await this.profilePhoto$.next(link);
            this.getProfilePhotoStyle();
        }
        catch {
            this.profilePhoto$.next(this.photoFailSafe);
            this.errorHandlingService.setError({ Success: false, Message: 'Failed to load profile photo- error updating' }); // frontend error message
            this.getProfilePhotoStyle();
        }
    }
    profile() {
        if (this.Type !== 'edit' && this.AllowGoToProfile === true) {
            this.Router.navigate(['/profile']);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProfilePhotoComponent, deps: [{ token: IndexedDBService }, { token: ErrorHandlingService }, { token: KeysComponent }, { token: i1$1.HttpClient }, { token: i1.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ProfilePhotoComponent, selector: "profilePhoto", inputs: { Type: "Type", style: "style", PicUrl: "PicUrl", AllowGoToProfile: "AllowGoToProfile" }, viewQueries: [{ propertyName: "fileInput", first: true, predicate: ["fileInput"], descendants: true }], ngImport: i0, template: "<div class=\"profile-photo-container\" [ngStyle]=\"photoStyle\" (click)=\"profile()\">\n  <ng-container *ngIf=\"(isLoading$ | async) === false; else loading\">\n    <form class=\"profile_up\" *ngIf=\"Type === 'edit'\" method=\"post\" enctype=\"multipart/form-data\">\n      <div style=\"width: 100%; height: 100%;\" (click)=\"openFileInput()\">\n        <ion-icon [icon]=\"photoUploadIcon\" class=\"PhotoIcon\"></ion-icon>\n        <input type=\"file\" #fileInput accept=\"{{AllowedFileTypes}}\" (change)=\"onFileSelected($event)\"\n          style=\"display: none;\">\n        <p class=\"EditLabel\">\n          Only {{AllowedFileTypes}} Allowed\n        </p>\n      </div>\n    </form>\n\n  </ng-container>\n  <ng-template #loading>\n    <div class=\"loading-indicator\">\n      <p>Loading...</p>\n    </div>\n  </ng-template>\n</div>\n\n<!-- \n<form *ngIf=\"Type === 'edit'\" class=\"profile-photo-form\">\n  <label for=\"fileInput\" class=\"profile-photo-label\">\n    <ion-icon [icon]=\"photoUploadIcon\" class=\"photo-icon\"></ion-icon>\n    <span class=\"edit-label\">Click to Update</span>\n  </label>\n  <input \n    id=\"fileInput\"\n    type=\"file\" \n    accept=\"image/jpeg, image/jpg, image/png, image/gif\"\n    (change)=\"onFileSelected($event)\" \n    class=\"file-input\">\n</form> -->\n\n<!-- <div *ngIf=\"!isLoading; else Loading\" alt=\"Profile Picture\" class=\"profile-pic\" [ngStyle]=\"getProfilePhotoStyle()\">\n  <form class=\"profile_up\" *ngIf=\"Type === 'edit'\" method=\"post\" enctype=\"multipart/form-data\">\n    <div style=\"width: 100%; height: 100%;\" (click)=\"openFileInput()\">\n      <ion-icon [icon]=\"PhotoUpload\" class=\"PhotoIcon\"></ion-icon>\n      <input type=\"file\" #fileInput accept=\"image/jpeg, image/jpg, image/png, image/gif\"\n        (change)=\"onFileSelected($event)\" style=\"display: none;\">\n      <p class=\"EditLabel\">\n        Click to Update\n      </p>\n    </div>\n  </form>\n</div>\n<ng-template #Loading>\n  <p>\n    Loading...\n  </p>\n</ng-template> -->", styles: [".profile-photo-container{background-size:cover;background-position:center;height:100%;background-image:url(/assets/Stockphoto.png)}.profile-photo-container img{position:relative;width:100%;height:300px}.profile_up{display:flex;flex-direction:column;height:100%}.PhotoIcon{z-index:1;position:relative;height:100%;width:100%;opacity:.3;background:#fff}.EditLabel{max-height:20%;margin-top:-25%;line-height:1;padding:.8em;color:var(--accentColor);background:var(--Color);z-index:1;position:relative;cursor:pointer;border-radius:15px 15px 0 0;box-shadow:4px -3px 8px #0006}.EditLabel:hover{color:var(--accentColor)}.loading-indicator{background:#ffffffa6;height:100%}.loading-indicator p{padding:50% 0%}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "pipe", type: i3.AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProfilePhotoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'profilePhoto', template: "<div class=\"profile-photo-container\" [ngStyle]=\"photoStyle\" (click)=\"profile()\">\n  <ng-container *ngIf=\"(isLoading$ | async) === false; else loading\">\n    <form class=\"profile_up\" *ngIf=\"Type === 'edit'\" method=\"post\" enctype=\"multipart/form-data\">\n      <div style=\"width: 100%; height: 100%;\" (click)=\"openFileInput()\">\n        <ion-icon [icon]=\"photoUploadIcon\" class=\"PhotoIcon\"></ion-icon>\n        <input type=\"file\" #fileInput accept=\"{{AllowedFileTypes}}\" (change)=\"onFileSelected($event)\"\n          style=\"display: none;\">\n        <p class=\"EditLabel\">\n          Only {{AllowedFileTypes}} Allowed\n        </p>\n      </div>\n    </form>\n\n  </ng-container>\n  <ng-template #loading>\n    <div class=\"loading-indicator\">\n      <p>Loading...</p>\n    </div>\n  </ng-template>\n</div>\n\n<!-- \n<form *ngIf=\"Type === 'edit'\" class=\"profile-photo-form\">\n  <label for=\"fileInput\" class=\"profile-photo-label\">\n    <ion-icon [icon]=\"photoUploadIcon\" class=\"photo-icon\"></ion-icon>\n    <span class=\"edit-label\">Click to Update</span>\n  </label>\n  <input \n    id=\"fileInput\"\n    type=\"file\" \n    accept=\"image/jpeg, image/jpg, image/png, image/gif\"\n    (change)=\"onFileSelected($event)\" \n    class=\"file-input\">\n</form> -->\n\n<!-- <div *ngIf=\"!isLoading; else Loading\" alt=\"Profile Picture\" class=\"profile-pic\" [ngStyle]=\"getProfilePhotoStyle()\">\n  <form class=\"profile_up\" *ngIf=\"Type === 'edit'\" method=\"post\" enctype=\"multipart/form-data\">\n    <div style=\"width: 100%; height: 100%;\" (click)=\"openFileInput()\">\n      <ion-icon [icon]=\"PhotoUpload\" class=\"PhotoIcon\"></ion-icon>\n      <input type=\"file\" #fileInput accept=\"image/jpeg, image/jpg, image/png, image/gif\"\n        (change)=\"onFileSelected($event)\" style=\"display: none;\">\n      <p class=\"EditLabel\">\n        Click to Update\n      </p>\n    </div>\n  </form>\n</div>\n<ng-template #Loading>\n  <p>\n    Loading...\n  </p>\n</ng-template> -->", styles: [".profile-photo-container{background-size:cover;background-position:center;height:100%;background-image:url(/assets/Stockphoto.png)}.profile-photo-container img{position:relative;width:100%;height:300px}.profile_up{display:flex;flex-direction:column;height:100%}.PhotoIcon{z-index:1;position:relative;height:100%;width:100%;opacity:.3;background:#fff}.EditLabel{max-height:20%;margin-top:-25%;line-height:1;padding:.8em;color:var(--accentColor);background:var(--Color);z-index:1;position:relative;cursor:pointer;border-radius:15px 15px 0 0;box-shadow:4px -3px 8px #0006}.EditLabel:hover{color:var(--accentColor)}.loading-indicator{background:#ffffffa6;height:100%}.loading-indicator p{padding:50% 0%}\n"] }]
        }], ctorParameters: function () { return [{ type: IndexedDBService }, { type: ErrorHandlingService }, { type: KeysComponent }, { type: i1$1.HttpClient }, { type: i1.Router }]; }, propDecorators: { Type: [{
                type: Input
            }], style: [{
                type: Input
            }], PicUrl: [{
                type: Input
            }], AllowGoToProfile: [{
                type: Input
            }], fileInput: [{
                type: ViewChild,
                args: ['fileInput', { static: false }]
            }] } });

class VideodisplayComponent {
    constructor(sanitizer, formService, userService) {
        this.sanitizer = sanitizer;
        this.formService = formService;
        this.userService = userService;
        this.videoLink = '';
        this.autoplay = false;
        this.VideoSrc = 'External';
        this.VideoIcon = videocamOff;
    }
    ngOnInit() {
        // Ensure Domain is set 
        this.userService.USERDATA$.pipe(take$1(1)).subscribe((userData) => {
            this.Domain = userData.CONFIG.URL;
            if (!this.videoLink) {
                // use take and susbcribe to getuserService user data 
                this.userService.USERDATA$.pipe(take$1(1)).subscribe((userData) => {
                    this.videoLink = userData?.video ?? userData?.videoR ?? userData?.videoH;
                    if (this.videoLink) {
                        this.safeVideoLink = this.filterVideoLink(this.videoLink);
                    }
                });
            }
            else {
                this.safeVideoLink = this.filterVideoLink(this.videoLink);
            }
        });
    }
    ngOnChanges(changes) {
        if (changes['videoLink']) {
            this.safeVideoLink = this.filterVideoLink(this.videoLink);
        }
    }
    filterVideoLink(url) {
        this.VideoSrc = !url.includes(this.Domain) ? 'External' : 'Internal';
        const sanitizedUrl = url.includes('youtube') || url.includes('youtu.be')
            ? this.formService.getYouTubeEmbedUrl_Library(url)
            : url;
        return this.sanitizer.bypassSecurityTrustResourceUrl(sanitizedUrl);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: VideodisplayComponent, deps: [{ token: i1$3.DomSanitizer }, { token: FormService }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: VideodisplayComponent, selector: "app-videodisplay", inputs: { videoLink: "videoLink", autoplay: "autoplay" }, usesOnChanges: true, ngImport: i0, template: "\n<div *ngIf=\"safeVideoLink; else NoVideo\">\n  <div *ngIf=\"VideoSrc == 'External'\">\n    <div class=\"video-container\">\n      <iframe id=\"videoautogen\" [src]=\"safeVideoLink\" frameborder=\"0\"\n        allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen [attr.autoplay]=\"autoplay ? '' : null\"></iframe>\n    </div>\n  </div>\n  <div *ngIf=\"VideoSrc == 'Internal'\">\n    <div class=\"video-container2\">\n      <video class=\"video_\" controls [attr.autoplay]=\"autoplay ? '' : null\">\n        <source id=\"videoautogen\" [src]=\"safeVideoLink\" type=\"video/mp4\">\n        Your browser does not support the video tag.\n      </video>\n    </div>\n  </div>\n</div>\n<ng-template #NoVideo>\n  <div class=\"video-container\">\n    <h3 class=\"centered-text\">\n      No Video Available\n      <br />\n      <ion-icon [icon]=\"VideoIcon\"></ion-icon>\n    </h3>\n  </div>\n</ng-template>", styles: [".video-container{position:relative;width:100%;padding-bottom:56.25%;height:0;overflow:hidden;background:var(--color3)}.video-container iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0}.centered-text{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;width:100%}.video-container2{position:relative;width:100%;height:100%;display:flex;justify-content:center;align-items:center}.video_{width:100%;height:100%;max-height:80vh;object-fit:contain}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: VideodisplayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-videodisplay', template: "\n<div *ngIf=\"safeVideoLink; else NoVideo\">\n  <div *ngIf=\"VideoSrc == 'External'\">\n    <div class=\"video-container\">\n      <iframe id=\"videoautogen\" [src]=\"safeVideoLink\" frameborder=\"0\"\n        allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen [attr.autoplay]=\"autoplay ? '' : null\"></iframe>\n    </div>\n  </div>\n  <div *ngIf=\"VideoSrc == 'Internal'\">\n    <div class=\"video-container2\">\n      <video class=\"video_\" controls [attr.autoplay]=\"autoplay ? '' : null\">\n        <source id=\"videoautogen\" [src]=\"safeVideoLink\" type=\"video/mp4\">\n        Your browser does not support the video tag.\n      </video>\n    </div>\n  </div>\n</div>\n<ng-template #NoVideo>\n  <div class=\"video-container\">\n    <h3 class=\"centered-text\">\n      No Video Available\n      <br />\n      <ion-icon [icon]=\"VideoIcon\"></ion-icon>\n    </h3>\n  </div>\n</ng-template>", styles: [".video-container{position:relative;width:100%;padding-bottom:56.25%;height:0;overflow:hidden;background:var(--color3)}.video-container iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0}.centered-text{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;width:100%}.video-container2{position:relative;width:100%;height:100%;display:flex;justify-content:center;align-items:center}.video_{width:100%;height:100%;max-height:80vh;object-fit:contain}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$3.DomSanitizer }, { type: FormService }, { type: IndexedDBService }]; }, propDecorators: { videoLink: [{
                type: Input
            }], autoplay: [{
                type: Input
            }] } });

class FormCreatorComponent {
    constructor(cdr, formService) {
        this.cdr = cdr;
        this.formService = formService;
        this.InputItem = {
            Title: 'First Name',
            Name: 'firstname',
            Type: 'text',
            Vars: '',
            Style: '',
            Category: 'Test',
            Placeholder: ''
        };
        this.labelStyle = '';
        this.videoLink = '';
        this.showVideo = true;
    }
    ngOnInit() {
        this.updateVideoLink(this.InputItem.Placeholder ?? '');
    }
    ngOnChanges(changes) {
        if (changes['InputItem'] && !changes['InputItem'].firstChange) {
            this.updateVideoLink(this.InputItem.Placeholder ?? '');
        }
    }
    updateVideoLink(url) {
        this.videoLink = url;
        this.showVideo = false;
        this.cdr.detectChanges();
        setTimeout(() => {
            this.showVideo = true;
            this.cdr.detectChanges();
        }, 0);
    }
    onInputChange(event) {
        const inputElement = event.target;
        this.updateVideoLink(inputElement.value);
    }
    isInvalid(entry) {
        return this.formService.isInvalid(entry);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormCreatorComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: FormService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FormCreatorComponent, selector: "form-creator", inputs: { InputItem: "InputItem", formGroup: "formGroup", labelStyle: "labelStyle" }, usesOnChanges: true, ngImport: i0, template: "<div [formGroup]=\"formGroup\" *ngIf=\"InputItem\">\n    <label [style]=\"labelStyle\">{{ InputItem.Title }}</label><span style=\"margin-left: 5px;\">{{InputItem.Span}}</span>\n    <div [ngSwitch]=\"InputItem.Type\">\n        <input *ngSwitchCase=\"'text'\" type=\"text\" [formControlName]=\"InputItem.Name\"\n            [ngClass]=\"{'is-invalid': isInvalid(formGroup.get(InputItem.Name))}\" [placeholder]=\"InputItem.Placeholder\"\n            [style]=\"InputItem.Style\" />\n        <textarea *ngSwitchCase=\"'textarea'\" [formControlName]=\"InputItem.Name\"\n            [ngClass]=\"{'is-invalid': isInvalid(formGroup.get(InputItem.Name))}\" [placeholder]=\"InputItem.Placeholder\"\n            [style]=\"InputItem.Style\"></textarea>\n        <select *ngSwitchCase=\"'select'\" [formControlName]=\"InputItem.Name\"\n            [ngClass]=\"{'is-invalid': isInvalid(formGroup.get(InputItem.Name))}\" [style]=\"InputItem.Style\">\n            <option *ngFor=\"let option of InputItem.Vars\" [value]=\"option\">{{ option }}</option>\n        </select>\n        <input *ngSwitchCase=\"'number'\" type=\"number\" [formControlName]=\"InputItem.Name\"\n            [ngClass]=\"{'is-invalid': isInvalid(formGroup.get(InputItem.Name))}\" [style]=\"InputItem.Style\">\n        <div *ngSwitchCase=\"'video'\">\n            <div *ngIf=\"showVideo; else NoVideo\">\n                <app-videodisplay [videoLink]=\"videoLink\"></app-videodisplay>\n            </div>\n            <ng-template #NoVideo>\n                <app-videodisplay [videoLink]=\"videoLink ?? InputItem.Placeholder\"></app-videodisplay>\n                <!-- <p>\n                    Showing {{InputItem.Placeholder}} as a placeholder video.\n                </p> -->\n            </ng-template>\n\n            <br />\n            <input [formControlName]=\"InputItem.Name\" type=\"text\" [value]=\"InputItem.Placeholder\" (input)=\"onInputChange($event)\" [ngClass]=\"{'is-invalid': isInvalid(InputItem.Placeholder)}\">\n            <p>\n              *For best results, use YouTube Links.\n            </p>\n        </div>\n        <div *ngSwitchCase=\"'picture'\">\n            <profilePhoto [Type]=\"'edit'\" class=\"ProfilePhotoBox\"></profilePhoto>\n        </div>\n    </div>\n    <formErrorMessage [control]=\"formGroup.get(InputItem.Name)\"></formErrorMessage>\n</div>\n\n", styles: [".ProfilePhotoBox{width:180px;height:230px;display:inline-block}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i3.NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: i3.NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: i1$2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1$2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i1$2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }, { kind: "component", type: ProfilePhotoComponent, selector: "profilePhoto", inputs: ["Type", "style", "PicUrl", "AllowGoToProfile"] }, { kind: "component", type: VideodisplayComponent, selector: "app-videodisplay", inputs: ["videoLink", "autoplay"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormCreatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'form-creator', template: "<div [formGroup]=\"formGroup\" *ngIf=\"InputItem\">\n    <label [style]=\"labelStyle\">{{ InputItem.Title }}</label><span style=\"margin-left: 5px;\">{{InputItem.Span}}</span>\n    <div [ngSwitch]=\"InputItem.Type\">\n        <input *ngSwitchCase=\"'text'\" type=\"text\" [formControlName]=\"InputItem.Name\"\n            [ngClass]=\"{'is-invalid': isInvalid(formGroup.get(InputItem.Name))}\" [placeholder]=\"InputItem.Placeholder\"\n            [style]=\"InputItem.Style\" />\n        <textarea *ngSwitchCase=\"'textarea'\" [formControlName]=\"InputItem.Name\"\n            [ngClass]=\"{'is-invalid': isInvalid(formGroup.get(InputItem.Name))}\" [placeholder]=\"InputItem.Placeholder\"\n            [style]=\"InputItem.Style\"></textarea>\n        <select *ngSwitchCase=\"'select'\" [formControlName]=\"InputItem.Name\"\n            [ngClass]=\"{'is-invalid': isInvalid(formGroup.get(InputItem.Name))}\" [style]=\"InputItem.Style\">\n            <option *ngFor=\"let option of InputItem.Vars\" [value]=\"option\">{{ option }}</option>\n        </select>\n        <input *ngSwitchCase=\"'number'\" type=\"number\" [formControlName]=\"InputItem.Name\"\n            [ngClass]=\"{'is-invalid': isInvalid(formGroup.get(InputItem.Name))}\" [style]=\"InputItem.Style\">\n        <div *ngSwitchCase=\"'video'\">\n            <div *ngIf=\"showVideo; else NoVideo\">\n                <app-videodisplay [videoLink]=\"videoLink\"></app-videodisplay>\n            </div>\n            <ng-template #NoVideo>\n                <app-videodisplay [videoLink]=\"videoLink ?? InputItem.Placeholder\"></app-videodisplay>\n                <!-- <p>\n                    Showing {{InputItem.Placeholder}} as a placeholder video.\n                </p> -->\n            </ng-template>\n\n            <br />\n            <input [formControlName]=\"InputItem.Name\" type=\"text\" [value]=\"InputItem.Placeholder\" (input)=\"onInputChange($event)\" [ngClass]=\"{'is-invalid': isInvalid(InputItem.Placeholder)}\">\n            <p>\n              *For best results, use YouTube Links.\n            </p>\n        </div>\n        <div *ngSwitchCase=\"'picture'\">\n            <profilePhoto [Type]=\"'edit'\" class=\"ProfilePhotoBox\"></profilePhoto>\n        </div>\n    </div>\n    <formErrorMessage [control]=\"formGroup.get(InputItem.Name)\"></formErrorMessage>\n</div>\n\n", styles: [".ProfilePhotoBox{width:180px;height:230px;display:inline-block}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ChangeDetectorRef }, { type: FormService }]; }, propDecorators: { InputItem: [{
                type: Input
            }], formGroup: [{
                type: Input
            }], labelStyle: [{
                type: Input
            }] } });

class LoginPopUpComponent {
    constructor(formBuilder, Keys, router, FormService) {
        this.formBuilder = formBuilder;
        this.Keys = Keys;
        this.router = router;
        this.FormService = FormService;
        //ion icons
        this.log_in_outline = logInOutline;
        //switch between email form, login form, and signup form
        this.ErrorTrack = null;
        this.view = lRouteKey;
        this.loginTrue = null;
        this.RegForm = this.formBuilder.group({
            website: [''],
            nusemal: ['', [Validators.required, Validators.email, Validators.minLength(7), Validators.maxLength(85)]],
            disName: ['', [Validators.minLength(3), Validators.maxLength(50), Validators.required]]
        });
    }
    async CheckExi(ControlName, Type) {
        // run validation
        this.ErrorTrack = await firstValueFrom(this.FormService.CheckEmail(this.RegForm, ControlName));
        if (this.ErrorTrack) {
            // this.navigationService.navigateTo(this.view.login);
            this.loginTrue = true;
        }
        else {
            // this.navigationService.navigateTo(this.view.createAccount);
            this.loginTrue = false;
        }
    }
    openPrivacy() {
        //not implemented
        this.router.navigate(['/policies']);
    }
    get defaultEmail() {
        ;
        return this.RegForm.get('nusemal')?.value ?? '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoginPopUpComponent, deps: [{ token: i1$2.FormBuilder }, { token: KeysComponent }, { token: i1.Router }, { token: FormService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LoginPopUpComponent, selector: "login-pop-up", ngImport: i0, template: "<div *ngIf=\"loginTrue == null\">\n<form [formGroup]=\"RegForm\" (ngSubmit)=\"CheckExi('nusemal','email')\" >\n    <logo-box [styling]=\"'width: 50px;'\"></logo-box>\n    <h1>\n        <span>\n            Account Access Required\n        </span>\n    </h1>\n    <h3>\n        That page is restricted! Enter your email to gain access ...\n    </h3>\n    <br />\n\n    <input type=\"text\" formControlName=\"website\" style=\"display: none;\">\n    <input \n        type=\"email\" \n        formControlName=\"nusemal\" \n        placeholder=\"Enter your Email\"\n        minlength=\"7\" \n        maxlength=\"85\" \n        title=\"Your Email\"\n        required\n        [ngClass]=\"{'is-invalid': this.FormService.isInvalid(RegForm.get('nusemal'))}\" \n         /><formErrorMessage [control]=\"RegForm.get('nusemal')\"></formErrorMessage>\n         <p>\n            *Not used for spam email lists or sold to third parties.\n         </p>\n    <!-- <p>\n            *When handling sensitive information we utilize industry standards as well as additional security measures. For more information <a class=\"a\" (click)=\"openPrivacy()\">click here</a>\n    </p> -->\n    \n\n    <div class=\"has-text-right\">\n        <hr style=\"background: var(--color)\">\n        <app-loadingspinner></app-loadingspinner> \n        <button aria-label=\"Create account button\" type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n            <ion-icon size=\"large\" [icon]=\"log_in_outline\"></ion-icon>\n            Continue\n        </button>\n    </div>\n</form>\n</div>\n<div>\n    <div class=\"AddSectionPad\" *ngIf=\"loginTrue\">\n        <login-form [defaultEmail]=\"defaultEmail\"></login-form>\n    </div>\n    <div class=\"AddSectionPad\" *ngIf=\"loginTrue == false\">\n        <login-signupform [defaultEmail]=\"defaultEmail\"></login-signupform>\n    </div>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1$2.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i1$2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }, { kind: "component", type: LoadingSpinnerComponent, selector: "app-loadingspinner", inputs: ["isLoading"] }, { kind: "component", type: LogoBoxComponent, selector: "logo-box", inputs: ["styling", "Boxstyling", "AltText", "Logo", "TagOn"] }, { kind: "component", type: LoginformComponent, selector: "login-form", inputs: ["defaultEmail"] }, { kind: "component", type: UserRegComponent, selector: "login-signupform", inputs: ["defaultEmail"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoginPopUpComponent, decorators: [{
            type: Component,
            args: [{ selector: 'login-pop-up', template: "<div *ngIf=\"loginTrue == null\">\n<form [formGroup]=\"RegForm\" (ngSubmit)=\"CheckExi('nusemal','email')\" >\n    <logo-box [styling]=\"'width: 50px;'\"></logo-box>\n    <h1>\n        <span>\n            Account Access Required\n        </span>\n    </h1>\n    <h3>\n        That page is restricted! Enter your email to gain access ...\n    </h3>\n    <br />\n\n    <input type=\"text\" formControlName=\"website\" style=\"display: none;\">\n    <input \n        type=\"email\" \n        formControlName=\"nusemal\" \n        placeholder=\"Enter your Email\"\n        minlength=\"7\" \n        maxlength=\"85\" \n        title=\"Your Email\"\n        required\n        [ngClass]=\"{'is-invalid': this.FormService.isInvalid(RegForm.get('nusemal'))}\" \n         /><formErrorMessage [control]=\"RegForm.get('nusemal')\"></formErrorMessage>\n         <p>\n            *Not used for spam email lists or sold to third parties.\n         </p>\n    <!-- <p>\n            *When handling sensitive information we utilize industry standards as well as additional security measures. For more information <a class=\"a\" (click)=\"openPrivacy()\">click here</a>\n    </p> -->\n    \n\n    <div class=\"has-text-right\">\n        <hr style=\"background: var(--color)\">\n        <app-loadingspinner></app-loadingspinner> \n        <button aria-label=\"Create account button\" type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n            <ion-icon size=\"large\" [icon]=\"log_in_outline\"></ion-icon>\n            Continue\n        </button>\n    </div>\n</form>\n</div>\n<div>\n    <div class=\"AddSectionPad\" *ngIf=\"loginTrue\">\n        <login-form [defaultEmail]=\"defaultEmail\"></login-form>\n    </div>\n    <div class=\"AddSectionPad\" *ngIf=\"loginTrue == false\">\n        <login-signupform [defaultEmail]=\"defaultEmail\"></login-signupform>\n    </div>\n</div>\n" }]
        }], ctorParameters: function () { return [{ type: i1$2.FormBuilder }, { type: KeysComponent }, { type: i1.Router }, { type: FormService }]; } });

class CartComponent {
    constructor(EC_Func) {
        this.EC_Func = EC_Func;
        // Vars
        this.Total = 0;
        this.Cart = this.EC_Func.getCartt();
        this.Total = this.EC_Func.getcartTotal(this.Cart);
    }
    ngOnInit() {
        // Update Cart and Associated Vars 
        this.EC_Func.Cart.subscribe(items => {
            this.Cart = items;
            this.Total = this.EC_Func.getcartTotal(this.Cart);
        });
    }
    // Functions 
    Remove(item) {
        this.EC_Func.UpdateCart(item, "clear");
    }
    trackByFn(index, item) {
        return item.ID; // or any unique property of the item
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CartComponent, deps: [{ token: EC_Functions }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: CartComponent, selector: "app-cart", ngImport: i0, template: "\n<div style=\"padding: 1rem;\">\n    <h1>\n        Your Cart\n    </h1>\n    <p>\n        Review your cart below\n    </p>\n</div>\n<ec-itemsdisplay></ec-itemsdisplay>\n\n", styles: [""], dependencies: [{ kind: "component", type: ItemsdisplayComponent, selector: "ec-itemsdisplay" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-cart', template: "\n<div style=\"padding: 1rem;\">\n    <h1>\n        Your Cart\n    </h1>\n    <p>\n        Review your cart below\n    </p>\n</div>\n<ec-itemsdisplay></ec-itemsdisplay>\n\n" }]
        }], ctorParameters: function () { return [{ type: EC_Functions }]; } });

class InvoiceComponent {
    constructor(indexdb) {
        this.indexdb = indexdb;
        this.billingAddress = [];
    }
    ngOnInit() {
        if (this.data && this.data.address) {
            this.billingAddress = Object.entries(this.data.address)
                .filter(([key, value]) => value !== null && value !== undefined && value !== '')
                .map(([key, value]) => ({ key, value }));
        }
    }
    home() {
        //needs to reload the page to get rid of stripe Iframe elements
        window.location.href = '/';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: InvoiceComponent, deps: [{ token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: InvoiceComponent, selector: "lib-invoice", inputs: { data: "data" }, ngImport: i0, template: "<div *ngIf=\"data\" class=\"invoice-info\"\n  style=\"display: flex; flex-direction: column; align-items: center; padding: 20px; width: 100%; max-width: 800px; margin: 0 auto;\">\n  <h2 style=\"font-size: 2em; margin-bottom: 20px;\">\n    Order Details\n  </h2>\n  <p>\n    <strong>Order ID:</strong> {{ data.payment_method }}\n  </p>\n  <hr>\n\n  <!-- Contact Info Section -->\n  <div class=\"info-section\">\n    <h3 style=\"font-size: 1.5em; margin-bottom: 10px;\">Contact Info</h3>\n    <p>\n      <strong>Name:</strong> {{ data.name }}\n    </p>\n    <p>\n      <strong>Email:</strong> {{ data.email }}\n    </p>\n  </div>\n  <hr>\n\n  <!-- Payment Method Section -->\n  <div class=\"info-section\">\n    <h3 style=\"font-size: 1.5em; margin-bottom: 10px;\">\n      Payment Method\n    </h3>\n    <p>\n      <strong>{{ data.cardBrand }} ending in</strong> {{ data.last4 }}</p>\n  </div>\n  <hr>\n\n  <!-- Billing Address Section -->\n  <div class=\"info-section\">\n    <h3 style=\"font-size: 1.5em; margin-bottom: 10px;\">Billing Address</h3>\n    <p *ngFor=\"let item of billingAddress\">\n      <strong>{{ item.key | titlecase }}:</strong> {{ item.value }}\n    </p>\n  </div>\n\n  <!-- <button class=\"is-primary\" (click)=\"print()\">Print Invoice</button> -->\n  <button class=\"is-primary\" (click)=\"home()\">Finish</button>\n</div>", styles: ["hr{background:#000;height:5px;color:#024141;width:100%}.info-section{width:100%;text-align:left}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i3.TitleCasePipe, name: "titlecase" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: InvoiceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-invoice', template: "<div *ngIf=\"data\" class=\"invoice-info\"\n  style=\"display: flex; flex-direction: column; align-items: center; padding: 20px; width: 100%; max-width: 800px; margin: 0 auto;\">\n  <h2 style=\"font-size: 2em; margin-bottom: 20px;\">\n    Order Details\n  </h2>\n  <p>\n    <strong>Order ID:</strong> {{ data.payment_method }}\n  </p>\n  <hr>\n\n  <!-- Contact Info Section -->\n  <div class=\"info-section\">\n    <h3 style=\"font-size: 1.5em; margin-bottom: 10px;\">Contact Info</h3>\n    <p>\n      <strong>Name:</strong> {{ data.name }}\n    </p>\n    <p>\n      <strong>Email:</strong> {{ data.email }}\n    </p>\n  </div>\n  <hr>\n\n  <!-- Payment Method Section -->\n  <div class=\"info-section\">\n    <h3 style=\"font-size: 1.5em; margin-bottom: 10px;\">\n      Payment Method\n    </h3>\n    <p>\n      <strong>{{ data.cardBrand }} ending in</strong> {{ data.last4 }}</p>\n  </div>\n  <hr>\n\n  <!-- Billing Address Section -->\n  <div class=\"info-section\">\n    <h3 style=\"font-size: 1.5em; margin-bottom: 10px;\">Billing Address</h3>\n    <p *ngFor=\"let item of billingAddress\">\n      <strong>{{ item.key | titlecase }}:</strong> {{ item.value }}\n    </p>\n  </div>\n\n  <!-- <button class=\"is-primary\" (click)=\"print()\">Print Invoice</button> -->\n  <button class=\"is-primary\" (click)=\"home()\">Finish</button>\n</div>", styles: ["hr{background:#000;height:5px;color:#024141;width:100%}.info-section{width:100%;text-align:left}\n"] }]
        }], ctorParameters: function () { return [{ type: IndexedDBService }]; }, propDecorators: { data: [{
                type: Input
            }] } });

class CheckoutComponent {
    constructor(router, ECF, userService, formBuilder, formFunctions, paymentService, API, stripeService) {
        this.router = router;
        this.ECF = ECF;
        this.userService = userService;
        this.formBuilder = formBuilder;
        this.formFunctions = formFunctions;
        this.paymentService = paymentService;
        this.API = API;
        this.stripeService = stripeService;
        this.IsUserLoggedIn = true;
        this.stripe = null;
        this.stripePublicKey = environment.stripePublishableKey;
        this.loading = true;
        this.cardComplete = false;
        this.cardError = null;
        this.showInvoice = false;
        this.view = eRouteKey;
        this.lockClosed = lockClosed;
        this.applicableCountries = ['DE', 'US'];
        this.GERMANStates = [
            "Baden-Württemberg", "Bayern", "Berlin", "Brandenburg", "Bremen",
            "Hamburg", "Hessen", "Mecklenburg-Vorpommern", "Niedersachsen",
            "Nordrhein-Westfalen", "Rheinland-Pfalz", "Saarland", "Sachsen",
            "Sachsen-Anhalt", "Schleswig-Holstein", "Thüringen"
        ];
        this.USStates = [
            "Alabama", "Alaska", "Arizona", "Arkansas", "California",
            "Colorado", "Connecticut", "Delaware", "Florida", "Georgia",
            "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa",
            "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland",
            "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri",
            "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey",
            "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio",
            "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina",
            "South Dakota", "Tennessee", "Texas", "Utah", "Vermont",
            "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"
        ];
        this.stateSelectors = [];
        this.cardNumber = '';
        this.cardExp = '';
        this.cardCvv = '';
        this.errorMessage = '';
        this.showOtherStateInput = false;
    }
    async ngOnInit() {
        this.userService.USERDATA$.pipe(take(1)).subscribe((userData) => {
            this.User = userData;
            this.initializeForm();
        });
        this.IsUserLoggedIn = await this.userService.isLoggedIn();
        this.CheckCart();
        try {
            this.stripe = await this.stripeService.getStripe();
            const elements = this.stripe?.elements();
            if (elements) {
                this.card = elements.create('card');
                this.card.mount('#cardElement');
                this.card.on('change', (event) => {
                    this.cardComplete = event.complete;
                    this.cardError = event.error ? event.error.message : null;
                });
                this.loading = false;
            }
        }
        catch (error) {
            this.loading = false;
        }
    }
    initializeForm() {
        this.form = this.formBuilder.group({
            name: [this.User.firstname + ' ' + this.User.lastname, [Validators.required, this.formFunctions.ValidateName]],
            address: ['', [Validators.required]],
            address2: ['', []],
            city: ['', [Validators.required]],
            city2: ['', []],
            state: ['', [Validators.required]],
            state2: ['', []],
            country: ['', [Validators.required]],
            cardNumber: ['', [Validators.required, Validators.minLength(16), Validators.maxLength(16), Validators.pattern("^[0-9]*$")]],
            expDate: ['', [Validators.required, this.formFunctions.CheckExpirationDate()]],
            cvv: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3), Validators.pattern("^[0-9]*$")]],
            zip: ['', [Validators.minLength(5)]],
            zip2: ['', [Validators.minLength(5)]],
            promoCode: ['', [Validators.minLength(3), Validators.maxLength(10)]]
        });
        this.form.get('country')?.valueChanges.subscribe(value => {
            this.updateStateSelectors(value);
            this.updateZipValidators(value);
            this.updateCardElementOptions(value);
        });
        this.form.statusChanges.subscribe(status => {
            this.UpdateButtonColor();
        });
    }
    onStateChange(event) {
        const selectElement = event.target;
        this.showOtherStateInput = selectElement.value === 'Other';
        if (this.showOtherStateInput) {
            this.form.get('otherState')?.setValidators([Validators.required]);
        }
        else {
            this.form.get('otherState')?.clearValidators();
        }
        this.form.get('otherState')?.updateValueAndValidity();
    }
    updateStateSelectors(country) {
        if (country === 'US') {
            this.stateSelectors = this.USStates;
        }
        else if (country === 'DE') {
            this.stateSelectors = this.GERMANStates;
        }
        else {
            this.stateSelectors = [];
        }
    }
    updateCardElementOptions(country) {
        if (this.stripe && this.card) {
            const cardElementOptions = {
                hidePostalCode: country !== 'US'
            };
            this.card.update(cardElementOptions);
        }
    }
    updateZipValidators(country) {
        if (country === 'US') {
            this.form.get('zip')?.setValidators([Validators.required, Validators.minLength(5)]);
            this.form.get('zip2')?.setValidators([Validators.required, Validators.minLength(5)]);
        }
        else {
            this.form.get('zip')?.clearValidators();
            this.form.get('zip2')?.clearValidators();
        }
        this.form.get('zip')?.updateValueAndValidity();
        this.form.get('zip2')?.updateValueAndValidity();
    }
    UpdateButtonColor() {
        const placeOrderButton = document.getElementById('place-order-button');
        if (this.form.valid) {
            placeOrderButton.className = 'btn-valid';
        }
        else {
            // console.log('form invalid', this.form);
            placeOrderButton.className = 'btn-invalid';
        }
    }
    ngOnDestroy() {
        if (this.card) {
            this.card.destroy();
        }
        this.stripeService.cleanup();
        this.stripe = null;
        this.paymentService.cleanup();
    }
    async handlePayment(event) {
        event.preventDefault();
        this.errorMessage = '';
        const [expMonth, expYear] = this.cardExp.split('/').map(value => value.trim());
        try {
            const { paymentMethod, error } = await this.stripe.createPaymentMethod({
                type: 'card',
                card: this.card,
                billing_details: {
                    name: this.form.get('name')?.value,
                    email: this.User.Email,
                    address: {
                        country: this.form.get('country')?.value,
                        line1: this.form.get('address')?.value,
                        city: this.form.get('city')?.value,
                        state: this.form.get('state')?.value,
                        postal_code: this.form.get('zip')?.value,
                    },
                },
            });
            if (error) {
                throw error;
            }
            const customer = {
                id: this.User.Ky,
                name: paymentMethod.billing_details.name,
                email: paymentMethod.billing_details.email,
                address: paymentMethod.billing_details.address,
                cardBrand: paymentMethod.card?.brand,
                last4: paymentMethod.card?.last4
            };
            const Cart = await this.ECF.getCartt();
            const CountryFilter = this.form.get('country')?.value === 'DE' ? 'eur' : 'usd';
            const PaymentData = {
                payment_method: paymentMethod.id,
                currency: CountryFilter,
                amount: this.ECF.getcartTotal(Cart, CountryFilter) * 100,
                customer: customer,
                "CALL": "eC0mm3rce"
            };
            const promoCode = this.form.get('promoCode')?.value;
            if (promoCode) {
                PaymentData.promoCode = promoCode;
            }
            this.API.TakeAction(PaymentData).subscribe((response) => {
                if (!response.Success) {
                    this.errorMessage = response.Message;
                    return;
                }
                this.data = response.Token;
                this.showInvoice = response.Success;
                this.User.SETTINGS.Packages.forEach((item) => {
                    if (item.onSuccess) {
                        let form = new FormGroup({});
                        form.addControl('Verified', this.formBuilder.control(true));
                        form.get('Verified')?.markAsTouched();
                        form.get('Verified')?.markAsDirty();
                        this.formFunctions.updateInfo(form);
                        // clear cart
                        this.ECF.ClearCart();
                    }
                });
            });
            this.errorMessage = 'Payment successful!';
        }
        catch (error) {
            this.errorMessage = error.message;
        }
    }
    CheckCart() {
        const CartIsEmpty = this.ECF.isCartEmpty();
        if (CartIsEmpty) {
            this.router.navigate(['/' + this.view.ecommerce.path]);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CheckoutComponent, deps: [{ token: i1.Router }, { token: EC_Functions }, { token: IndexedDBService }, { token: i1$2.FormBuilder }, { token: FormService }, { token: PaymentService }, { token: ApiService }, { token: StripeService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: CheckoutComponent, selector: "app-checkout", viewQueries: [{ propertyName: "cardElement", first: true, predicate: ["cardElement"], descendants: true }], ngImport: i0, template: "<div class=\"modal\" *ngIf=\"!IsUserLoggedIn\">\n  <div class=\"modal-content\">\n    <login-pop-up></login-pop-up>\n  </div>\n</div>\n\n<logo-box [styling]=\"'max-width: 50px;'\"></logo-box>\n\n<div *ngIf=\"showInvoice\">\n    <br />\n  <div class=\"section\" style=\"background: #ffffffad; margin: 2rem; border-radius: 15px; width: fit-content; margin: auto;\">\n    <lib-invoice [data]=\"data\"></lib-invoice>\n  </div>\n  <br />\n  <br />\n</div>\n\n<div *ngIf=\"!showInvoice\" class=\"section\">\n  <h1 style=\"text-align: center;\">\n    <span>Review Order</span>\n  </h1>\n  <p style=\"text-align: center;\">\n    Secure Checkout Powered By <a href=\"https://stripe.com/\"><img src=\"assets/Stripe-Logo.jpg\" alt=\"Stripe Logo\"\n        style=\"width: 2em; height: 1em; vertical-align: middle;\"></a><ion-icon [icon]=\"lockClosed\"></ion-icon>\n  </p>\n  <br />\n  <div style=\"display: flex; flex-wrap: wrap; width: 100%;\">\n    <app-cart class=\"MainBoxItem\" style=\"flex: 1;\"></app-cart>\n    <br />\n\n    <div class=\"section MainBoxItem\" style=\"flex: 2;\">\n      <h1>Billing Info</h1>\n      <form [formGroup]=\"form\" (submit)=\"handlePayment($event)\">\n        <!-- <h3>Customer Information</h3> -->\n        <form-creator [InputItem]=\"{ Title: 'First Name & Last Name (Bill to)', Name: 'name', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <form-creator [InputItem]=\"{ Title: 'Address', Name: 'address', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <form-creator [InputItem]=\"{ Title: 'City', Name: 'city', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <form-creator [InputItem]=\"{ Title: 'Country', Name: 'country', Type: 'select', Vars: applicableCountries, Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <div *ngIf=\"form.get('country')?.value === 'US'\">\n          <form-creator [InputItem]=\"{ Title: 'Zip/Postal Code', Name: 'zip2', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n          <br />\n        </div>\n\n        <label for=\"state\">State</label>\n        <select id=\"state\" formControlName=\"state\" required [ngClass]=\"{'is-invalid': this.formFunctions.isInvalid(form.get('state'))}\" (change)=\"onStateChange($event);\">\n          <formErrorMessage [control]=\"form.get('state')\"></formErrorMessage>\n          <option value=\"\" disabled selected>Select State</option>\n          <option value=\"Other\">Other</option>\n          <option *ngFor=\"let state of (form.get('country')?.value === 'US' ? USStates : GERMANStates)\" [value]=\"state\"> {{ state }} </option>\n        </select>\n        <br />\n\n        <div *ngIf=\"showOtherStateInput\">\n          <input type=\"text\" formControlName=\"otherState\" placeholder=\"Enter your state\" [ngClass]=\"{'is-invalid': this.formFunctions.isInvalid(form.get('otherState'))}\">\n          <formErrorMessage [control]=\"form.get('otherState')\"></formErrorMessage>\n          <br />\n        </div>\n        \n\n        <form-creator [InputItem]=\"{ Title: 'Promo Code', Name: 'promoCode', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <h3>\n          Payment Information | Powered by <a href=\"https://stripe.com/\"><img src=\"assets/Stripe-Logo.jpg\" alt=\"Stripe Logo\" style=\"width: 2em; height: 1em; vertical-align: middle;\"></a><ion-icon [icon]=\"lockClosed\"></ion-icon>\n        </h3>\n        <div id=\"cardElement\"></div>\n        <div *ngIf=\"cardError\" class=\"error\">{{ cardError }}</div>\n        <br />\n        <div style=\"display: flex; justify-content: flex-start;\">\n          <input style=\"width: 30px;\" id=\"same-as-address\" name=\"same-as-address\" type=\"checkbox\" checked>\n          <label for=\"same-as-address\">Shipping same as customer address</label>\n        </div>\n        <br />\n        <!-- <button id=\"place-order-button\" type=\"submit\" [disabled]=\"!cardComplete\">\n          Place order\n        </button> -->\n        <button type=\"submit\" [disabled]=\"!cardComplete\">\n          Place order\n        </button>\n      </form>\n    </div>\n  </div>\n</div>", styles: [".MainBoxItem{min-width:300px;border-radius:15px;box-shadow:1px 0 3px gray;height:-moz-fit-content;height:fit-content;background:linear-gradient(45deg,#fff 20%,#fff9,#fff);margin:15px 10px}.modal{display:flex;justify-content:center;align-items:center;position:fixed;z-index:1;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:#000;background-color:#0006}.modal-content{background-color:#fefefe;margin:auto;padding:20px;border:1px solid #888;width:50%;max-width:80%}.btn-valid{background-color:green;color:#fff;border:none;padding:10px 20px;font-size:16px;cursor:pointer;transition:background-color .3s ease}.btn-valid:hover{background-color:#006400}.btn-invalid{background-color:gray;color:#fff;border:none;padding:10px 20px;font-size:16px;cursor:not-allowed;transition:background-color .3s ease}.btn-invalid:hover{background-color:gray}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1$2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }, { kind: "component", type: FormCreatorComponent, selector: "form-creator", inputs: ["InputItem", "formGroup", "labelStyle"] }, { kind: "component", type: LogoBoxComponent, selector: "logo-box", inputs: ["styling", "Boxstyling", "AltText", "Logo", "TagOn"] }, { kind: "component", type: LoginPopUpComponent, selector: "login-pop-up" }, { kind: "component", type: CartComponent, selector: "app-cart" }, { kind: "component", type: InvoiceComponent, selector: "lib-invoice", inputs: ["data"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CheckoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-checkout', template: "<div class=\"modal\" *ngIf=\"!IsUserLoggedIn\">\n  <div class=\"modal-content\">\n    <login-pop-up></login-pop-up>\n  </div>\n</div>\n\n<logo-box [styling]=\"'max-width: 50px;'\"></logo-box>\n\n<div *ngIf=\"showInvoice\">\n    <br />\n  <div class=\"section\" style=\"background: #ffffffad; margin: 2rem; border-radius: 15px; width: fit-content; margin: auto;\">\n    <lib-invoice [data]=\"data\"></lib-invoice>\n  </div>\n  <br />\n  <br />\n</div>\n\n<div *ngIf=\"!showInvoice\" class=\"section\">\n  <h1 style=\"text-align: center;\">\n    <span>Review Order</span>\n  </h1>\n  <p style=\"text-align: center;\">\n    Secure Checkout Powered By <a href=\"https://stripe.com/\"><img src=\"assets/Stripe-Logo.jpg\" alt=\"Stripe Logo\"\n        style=\"width: 2em; height: 1em; vertical-align: middle;\"></a><ion-icon [icon]=\"lockClosed\"></ion-icon>\n  </p>\n  <br />\n  <div style=\"display: flex; flex-wrap: wrap; width: 100%;\">\n    <app-cart class=\"MainBoxItem\" style=\"flex: 1;\"></app-cart>\n    <br />\n\n    <div class=\"section MainBoxItem\" style=\"flex: 2;\">\n      <h1>Billing Info</h1>\n      <form [formGroup]=\"form\" (submit)=\"handlePayment($event)\">\n        <!-- <h3>Customer Information</h3> -->\n        <form-creator [InputItem]=\"{ Title: 'First Name & Last Name (Bill to)', Name: 'name', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <form-creator [InputItem]=\"{ Title: 'Address', Name: 'address', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <form-creator [InputItem]=\"{ Title: 'City', Name: 'city', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <form-creator [InputItem]=\"{ Title: 'Country', Name: 'country', Type: 'select', Vars: applicableCountries, Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <div *ngIf=\"form.get('country')?.value === 'US'\">\n          <form-creator [InputItem]=\"{ Title: 'Zip/Postal Code', Name: 'zip2', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n          <br />\n        </div>\n\n        <label for=\"state\">State</label>\n        <select id=\"state\" formControlName=\"state\" required [ngClass]=\"{'is-invalid': this.formFunctions.isInvalid(form.get('state'))}\" (change)=\"onStateChange($event);\">\n          <formErrorMessage [control]=\"form.get('state')\"></formErrorMessage>\n          <option value=\"\" disabled selected>Select State</option>\n          <option value=\"Other\">Other</option>\n          <option *ngFor=\"let state of (form.get('country')?.value === 'US' ? USStates : GERMANStates)\" [value]=\"state\"> {{ state }} </option>\n        </select>\n        <br />\n\n        <div *ngIf=\"showOtherStateInput\">\n          <input type=\"text\" formControlName=\"otherState\" placeholder=\"Enter your state\" [ngClass]=\"{'is-invalid': this.formFunctions.isInvalid(form.get('otherState'))}\">\n          <formErrorMessage [control]=\"form.get('otherState')\"></formErrorMessage>\n          <br />\n        </div>\n        \n\n        <form-creator [InputItem]=\"{ Title: 'Promo Code', Name: 'promoCode', Type: 'text', Vars: [], Style: '', Category: 'Test', Placeholder: '' }\" [formGroup]=\"form\"></form-creator>\n        <br />\n\n        <h3>\n          Payment Information | Powered by <a href=\"https://stripe.com/\"><img src=\"assets/Stripe-Logo.jpg\" alt=\"Stripe Logo\" style=\"width: 2em; height: 1em; vertical-align: middle;\"></a><ion-icon [icon]=\"lockClosed\"></ion-icon>\n        </h3>\n        <div id=\"cardElement\"></div>\n        <div *ngIf=\"cardError\" class=\"error\">{{ cardError }}</div>\n        <br />\n        <div style=\"display: flex; justify-content: flex-start;\">\n          <input style=\"width: 30px;\" id=\"same-as-address\" name=\"same-as-address\" type=\"checkbox\" checked>\n          <label for=\"same-as-address\">Shipping same as customer address</label>\n        </div>\n        <br />\n        <!-- <button id=\"place-order-button\" type=\"submit\" [disabled]=\"!cardComplete\">\n          Place order\n        </button> -->\n        <button type=\"submit\" [disabled]=\"!cardComplete\">\n          Place order\n        </button>\n      </form>\n    </div>\n  </div>\n</div>", styles: [".MainBoxItem{min-width:300px;border-radius:15px;box-shadow:1px 0 3px gray;height:-moz-fit-content;height:fit-content;background:linear-gradient(45deg,#fff 20%,#fff9,#fff);margin:15px 10px}.modal{display:flex;justify-content:center;align-items:center;position:fixed;z-index:1;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:#000;background-color:#0006}.modal-content{background-color:#fefefe;margin:auto;padding:20px;border:1px solid #888;width:50%;max-width:80%}.btn-valid{background-color:green;color:#fff;border:none;padding:10px 20px;font-size:16px;cursor:pointer;transition:background-color .3s ease}.btn-valid:hover{background-color:#006400}.btn-invalid{background-color:gray;color:#fff;border:none;padding:10px 20px;font-size:16px;cursor:not-allowed;transition:background-color .3s ease}.btn-invalid:hover{background-color:gray}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.Router }, { type: EC_Functions }, { type: IndexedDBService }, { type: i1$2.FormBuilder }, { type: FormService }, { type: PaymentService }, { type: ApiService }, { type: StripeService }]; }, propDecorators: { cardElement: [{
                type: ViewChild,
                args: ['cardElement']
            }] } });

class EcommerceComponent {
    constructor(route, EC_Func) {
        this.route = route;
        this.EC_Func = EC_Func;
        this.routeView = this.route.snapshot.url[0] ? this.route.snapshot.url[0]['path'] : ''; // controls view of the page
        this.routeURL = eRouteKey;
        //console.log(this.routeView);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: EcommerceComponent, deps: [{ token: i1.ActivatedRoute }, { token: EC_Functions }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: EcommerceComponent, selector: "ec-ecommerce", ngImport: i0, template: "<background></background>\n<div *ngIf=\"routeView === routeURL.ecommerce.path || !routeView\">\n    <ec-shop-view></ec-shop-view>\n</div>\n<div *ngIf=\"routeView === routeURL.cart.path\">\n    <app-cart></app-cart>\n</div>\n<div *ngIf=\"routeView === routeURL.productView.path\">\n    <ec-product-view></ec-product-view>\n</div>\n<div *ngIf=\"routeView === routeURL.productTier.path\">\n    <ec-product-tier></ec-product-tier>\n</div>\n<div *ngIf=\"routeView === routeURL.checkout.path\">\n    <app-checkout></app-checkout>\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: BackgroundComponent, selector: "background", inputs: ["BackgroundImage"] }, { kind: "component", type: ShopViewComponent, selector: "ec-shop-view" }, { kind: "component", type: ProductViewComponent, selector: "ec-product-view", inputs: ["CustomPackages", "ShowCategories"] }, { kind: "component", type: ProductTierComponent, selector: "ec-product-tier", inputs: ["Product", "CustomPackages"] }, { kind: "component", type: CheckoutComponent, selector: "app-checkout" }, { kind: "component", type: CartComponent, selector: "app-cart" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: EcommerceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ec-ecommerce', template: "<background></background>\n<div *ngIf=\"routeView === routeURL.ecommerce.path || !routeView\">\n    <ec-shop-view></ec-shop-view>\n</div>\n<div *ngIf=\"routeView === routeURL.cart.path\">\n    <app-cart></app-cart>\n</div>\n<div *ngIf=\"routeView === routeURL.productView.path\">\n    <ec-product-view></ec-product-view>\n</div>\n<div *ngIf=\"routeView === routeURL.productTier.path\">\n    <ec-product-tier></ec-product-tier>\n</div>\n<div *ngIf=\"routeView === routeURL.checkout.path\">\n    <app-checkout></app-checkout>\n</div>\n" }]
        }], ctorParameters: function () { return [{ type: i1.ActivatedRoute }, { type: EC_Functions }]; } });

class ContactUsComponent {
    constructor(formBuilder, Keys, FormService, userService) {
        this.formBuilder = formBuilder;
        this.Keys = Keys;
        this.FormService = FormService;
        this.userService = userService;
        this.contactForm = this.formBuilder.group({
            name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(25), Validators.pattern('^[a-zA-Z ]*$')]],
            emailTO: ['', [Validators.required, Validators.email]],
            message: ['', [Validators.required, Validators.maxLength(200), Validators.minLength(3)]],
        });
    }
    ngOnInit() {
        this.userService.USERDATA$.pipe(take$1(1)).subscribe((data) => {
            this.User = data;
        });
        //changes the email input to the inputed one
        this.contactForm.patchValue({
            emailTO: this.User.Email
        });
    }
    // Submit Form
    onSubmit() {
        this.FormService.onSubmit(this.contactForm, this.User.CALL.Send_E_Mail);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ContactUsComponent, deps: [{ token: i1$2.FormBuilder }, { token: KeysComponent }, { token: FormService }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ContactUsComponent, selector: "app-contactus", ngImport: i0, template: "<div class=\"\">\n    <form [formGroup]=\"contactForm\" (ngSubmit)=\"onSubmit()\" style=\"padding: 1rem;\" class=\"\">\n\n        <input type=\"text\" name=\"email_confirm\" style=\"display: none;\">\n        <div>\n            <label class=\"label \">Your Name\n            </label>\n            <input type=\"text\" [placeholder]=\"'J Smith'\" formControlName=\"name\"\n                [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(contactForm.get('name'))}\">\n            <formErrorMessage [control]=\"contactForm.get('name')\"></formErrorMessage>\n        </div>\n        <br />\n        <div>\n            <label class=\"label\">\n                Email\n                <span style=\"font-size: 10px;\">\n                    (we will send a response to this address)\n                </span>\n            </label>\n\n            <input type=\"email\" placeholder=\"firstname@tetech.website...\" name=\"emailTO\" formControlName=\"emailTO\"\n                [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(contactForm.get('emailTO'))}\">\n\n                <formErrorMessage [control]=\"contactForm.get('emailTO')\"></formErrorMessage>\n        </div>\n\n        <br />\n        <div>\n            <label class=\"label\">Your Message</label>\n            <textarea style=\"width: 100%; padding: 0.5rem;\" rows=\"6\" id=\"message\" formControlName=\"message\"\n                maxlength=\"200\" minlength=\"3\" title=\"Maximum 200 characters allowed\" required\n                placeholder=\"Hi! I'd like to speak with someone in regards to...\"\n                [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(contactForm.get('message'))}\">\n            </textarea>\n        </div>\n        <br />\n        \n        <button type=\"submit\" class=\"is-primary\" button is-large>\n            <i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> Send\n        </button>\n    </form>\n\n</div>", styles: [".is-invalid{border:solid 2px red}input{padding:.5rem}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1$2.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i1$2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ContactUsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-contactus', template: "<div class=\"\">\n    <form [formGroup]=\"contactForm\" (ngSubmit)=\"onSubmit()\" style=\"padding: 1rem;\" class=\"\">\n\n        <input type=\"text\" name=\"email_confirm\" style=\"display: none;\">\n        <div>\n            <label class=\"label \">Your Name\n            </label>\n            <input type=\"text\" [placeholder]=\"'J Smith'\" formControlName=\"name\"\n                [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(contactForm.get('name'))}\">\n            <formErrorMessage [control]=\"contactForm.get('name')\"></formErrorMessage>\n        </div>\n        <br />\n        <div>\n            <label class=\"label\">\n                Email\n                <span style=\"font-size: 10px;\">\n                    (we will send a response to this address)\n                </span>\n            </label>\n\n            <input type=\"email\" placeholder=\"firstname@tetech.website...\" name=\"emailTO\" formControlName=\"emailTO\"\n                [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(contactForm.get('emailTO'))}\">\n\n                <formErrorMessage [control]=\"contactForm.get('emailTO')\"></formErrorMessage>\n        </div>\n\n        <br />\n        <div>\n            <label class=\"label\">Your Message</label>\n            <textarea style=\"width: 100%; padding: 0.5rem;\" rows=\"6\" id=\"message\" formControlName=\"message\"\n                maxlength=\"200\" minlength=\"3\" title=\"Maximum 200 characters allowed\" required\n                placeholder=\"Hi! I'd like to speak with someone in regards to...\"\n                [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(contactForm.get('message'))}\">\n            </textarea>\n        </div>\n        <br />\n        \n        <button type=\"submit\" class=\"is-primary\" button is-large>\n            <i class=\"fa fa-envelope\" aria-hidden=\"true\"></i> Send\n        </button>\n    </form>\n\n</div>", styles: [".is-invalid{border:solid 2px red}input{padding:.5rem}\n"] }]
        }], ctorParameters: function () { return [{ type: i1$2.FormBuilder }, { type: KeysComponent }, { type: FormService }, { type: IndexedDBService }]; } });

class ContactComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ContactComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ContactComponent, selector: "app-contact", ngImport: i0, template: "<div class=\"\">\n    <div class=\"\" style=\"padding: 3rem;\">\n        <h1>\n            Contact Us\n        </h1>\n        <p>\n            We regularly check this hotline. Send a message and we'll get back to you in 1 - 3 business days.\n        </p>\n       \n         <app-contactus></app-contactus> \n    </div>\n\n</div>", styles: ["app-contactus{border-radius:.5rem;color:#fff;display:block}\n"], dependencies: [{ kind: "component", type: ContactUsComponent, selector: "app-contactus" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ContactComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-contact', template: "<div class=\"\">\n    <div class=\"\" style=\"padding: 3rem;\">\n        <h1>\n            Contact Us\n        </h1>\n        <p>\n            We regularly check this hotline. Send a message and we'll get back to you in 1 - 3 business days.\n        </p>\n       \n         <app-contactus></app-contactus> \n    </div>\n\n</div>", styles: ["app-contactus{border-radius:.5rem;color:#fff;display:block}\n"] }]
        }] });

var sRouteKey = {
    settings: { path: 'settings', canActivate: true },
    account: { path: 'account', canActivate: true },
    profile: { path: 'profile', canActivate: true },
    help: { path: 'help', canActivate: true }
};

class ProfileComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProfileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ProfileComponent, selector: "settings-profile", inputs: { User: "User" }, ngImport: i0, template: "\n\n<div *ngIf=\"User | async as user; else loading\">\n    <!-- <app-user-card [user]=\"User\"></app-user-card> -->\n</div>\n\n<ng-template #loading>\n    <div>Loading...</div>\n</ng-template> ", styles: [""], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i3.AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProfileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'settings-profile', template: "\n\n<div *ngIf=\"User | async as user; else loading\">\n    <!-- <app-user-card [user]=\"User\"></app-user-card> -->\n</div>\n\n<ng-template #loading>\n    <div>Loading...</div>\n</ng-template> " }]
        }], propDecorators: { User: [{
                type: Input
            }] } });

class HelpComponent {
    constructor() {
        this.Mail = 'info@collegerecruit.us';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HelpComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: HelpComponent, selector: "settings-help", inputs: { User: "User" }, ngImport: i0, template: "<h1>\n    Help / Support\n</h1>\n\n<!-- temporary -->\n<app-contact></app-contact>", styles: [""], dependencies: [{ kind: "component", type: ContactComponent, selector: "app-contact" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HelpComponent, decorators: [{
            type: Component,
            args: [{ selector: 'settings-help', template: "<h1>\n    Help / Support\n</h1>\n\n<!-- temporary -->\n<app-contact></app-contact>" }]
        }], ctorParameters: function () { return []; }, propDecorators: { User: [{
                type: Input
            }] } });

class UserFormComponent {
    constructor(formBuilder, Keys, HTTPCall, FormService, userService, router, alertController) {
        this.formBuilder = formBuilder;
        this.Keys = Keys;
        this.HTTPCall = HTTPCall;
        this.FormService = FormService;
        this.userService = userService;
        this.router = router;
        this.alertController = alertController;
        this.log_in_outline = logInOutline;
        this.key_outline = keyOutline;
        this.closeCircle = closeCircle;
        this.routeKey = lRouteKey;
        this.DeletionPolicy = `
  Following account deletion, we maintain limited data retention to comply with legal obligations, prevent fraud, and resolve disputes. Your Data security is our number one priority. Data is not sent to third parties. After a 365-day period, the retained data will be permanently deleted from our systems unless otherwise required by legal procedures. Under certain circumstances, data is retained for longer.
    Data retained includes:
    - Email address
    - First name
    - Last name
    - Purchase history
    - Correspondences with our support team
    - Associated Meta data
  `;
    }
    ngOnInit() {
        this.userService.USERDATA$.pipe(take$1(1)).subscribe(userData => {
            this.User = userData;
            this.Account_Edit_Form = this.formBuilder.group({
                website: [''],
                eemail: [this.User.Email, [Validators.required, Validators.email, Validators.minLength(7), Validators.maxLength(85)]],
                dispName: [this.User.dis_name, [Validators.minLength(3), Validators.maxLength(50), Validators.required]],
                firstName: [{ value: this.User.firstname, disabled: true }, [this.FormService.ValidateName]],
                lastName: [{ value: this.User.lastname, disabled: true }, [this.FormService.ValidateName]],
            });
        });
    }
    async CheckExi(ControlName, Type) {
        let ErrorTrack = null;
        switch (Type) {
            case 'email':
                ErrorTrack = await firstValueFrom(this.FormService.CheckEmail(this.Account_Edit_Form, ControlName));
                break;
            case 'disname':
                ErrorTrack = await firstValueFrom(this.FormService.CheckDisname(this.Account_Edit_Form, ControlName));
                break;
        }
        let currentErrors = this.Account_Edit_Form.controls[ControlName].errors;
        if (ErrorTrack) {
            let newErrors = { ...currentErrors, ...ErrorTrack };
            this.Account_Edit_Form.controls[ControlName].setErrors(newErrors);
        }
    }
    async onSubmit() {
        this.Account_Edit_Form.value.oemail = this.User.Email;
        let Form_info = this.Account_Edit_Form.value;
        let Success = await this.FormService.onSubmit(this.Account_Edit_Form, this.Keys.UEditKey);
        if (Success === true) {
            await this.userService.updateSession({ Email: Form_info.eemail, dis_name: Form_info.dispName });
            window.location.reload();
        }
    }
    resetPass() {
        this.router.navigate(['/' + this.routeKey.forgotPassword]);
    }
    async requestDelete() {
        const alert = await this.alertController.create({
            header: 'WARNING: No Undo',
            subHeader: 'You will permanently lose access. Are you sure you want to continue?',
            message: this.DeletionPolicy,
            buttons: [{
                    text: 'CONTINUE',
                    cssClass: 'button buttonR',
                    handler: () => {
                        // Send Delete to backend 
                        this.HTTPCall.TakeAction({ CALL: this.User.CALLPriv.User_Delete, oemail: this.User.Email }, true).subscribe((response) => { });
                    }
                },
                {
                    text: 'More Information',
                    handler: () => {
                        this.router.navigate(['/policies']);
                    }
                },
                {
                    text: 'Date Erase Request',
                    handler: () => {
                        this.router.navigate(['/datarequest']);
                    }
                },
                // {
                //   text: 'Cancel',
                //   role: 'cancel'
                // }
            ]
        });
        await alert.present();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserFormComponent, deps: [{ token: i1$2.FormBuilder }, { token: KeysComponent }, { token: ApiService }, { token: FormService }, { token: IndexedDBService }, { token: i1.Router }, { token: i4.AlertController }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: UserFormComponent, selector: "settings-account-form", inputs: { User: "User" }, ngImport: i0, template: "<form [formGroup]=\"Account_Edit_Form\" (ngSubmit)=\"onSubmit()\">\n    <input type=\"text\" formControlName=\"website\" style=\"display: none;\">\n    <h3>\n        Login / Email\n    </h3>\n    <input type=\"email\" formControlName=\"eemail\" placeholder=\"Enter Email (used as your official login)\" minlength=\"7\"\n        maxlength=\"85\" title=\"Your Email (used as your official login)\" required (keyup)=\"CheckExi('eemail','email')\"\n        [ngClass]=\"{'is-invalid': this.FormService.isInvalid(Account_Edit_Form.get('eemail'))}\" />\n\n    <formErrorMessage [control]=\"Account_Edit_Form.get('eemail')\"></formErrorMessage>\n    <br />\n    <h3>\n        User Handle\n    </h3>\n    <input type=\"text\" formControlName=\"dispName\" placeholder=\"Enter your PUBLIC username...\"\n        title=\"Your public username\" minlength=\"3\" maxlength=\"50\" required\n        (ngModelChange)=\"CheckExi('dispName','disname')\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(Account_Edit_Form.get('dispName'))}\" />\n    <formErrorMessage [control]=\"Account_Edit_Form.get('dispName')\"></formErrorMessage>\n    <br />\n\n    <h3>\n        Reset Password\n    </h3>\n\n    <button type=\"button\" aria-label=\"Generate password button\" (click)=\"resetPass()\" class=\"button\"\n        style=\"padding-right: 1rem; font-size: 1.5rem; margin-right: 0.5rem;\">\n        <span>\n            <ion-icon size=\"small\" [icon]=\"key_outline\"></ion-icon>\n        </span>\n        ************\n    </button>\n    <br />\n    <br />\n    \n\n    <h3>\n        First Name / Last Name\n    </h3>\n    <p style=\"color: red;\">\n        *To edit, please visit our support page to send a name edit request.\n    </p>\n    <input style=\"width: 100%;\" type=\"text\" minlength=\"3\" maxlength=\"40\" placeholder=\"Your First Name...\"\n        pattern=\"[a-zA-Z]+\" title=\"Enter your first name...\" required formControlName=\"firstName\"\n        aria-label=\"First Name input field\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(Account_Edit_Form.get('firstName'))}\">\n    <formErrorMessage [control]=\"Account_Edit_Form.get('firstName')\"></formErrorMessage>\n    <br />\n\n\n    <input style=\"width: 100%;\" type=\"text\" minlength=\"3\" maxlength=\"40\" placeholder=\"Your Last Name...\"\n        pattern=\"[a-zA-Z]+\" title=\"Enter your last name...\" required formControlName=\"lastName\"\n        aria-label=\"Last Name input field\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(Account_Edit_Form.get('lastName'))}\">\n    <formErrorMessage [control]=\"Account_Edit_Form.get('lastName')\"></formErrorMessage>\n    <br />\n    <br />\n\n    <div class=\"has-text-right\">\n\n        <app-loadingspinner></app-loadingspinner>\n        <div style=\"display: flex; justify-content: space-between;\">\n            <button type=\"submit\" aria-label=\"Create account button\" [disabled]=\"Account_Edit_Form.invalid\"\n                type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n                <span>\n                    <ion-icon size=\"large\" [icon]=\"log_in_outline\"></ion-icon>\n                </span>\n                Save Changes\n            </button>\n            <button type=\"button\" (click)=\"requestDelete()\" class=\"button buttonR\">\n                <span>\n                    <ion-icon size=\"large\" [icon]=\"closeCircle\"></ion-icon>\n                </span>\n                Delete Account\n            </button>\n        </div>\n    </div>\n    <br />\n</form>", styles: [""], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i1$2.MinLengthValidator, selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]", inputs: ["minlength"] }, { kind: "directive", type: i1$2.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1$2.PatternValidator, selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]", inputs: ["pattern"] }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: FormErrorComponent, selector: "formErrorMessage", inputs: ["control"] }, { kind: "component", type: LoadingSpinnerComponent, selector: "app-loadingspinner", inputs: ["isLoading"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'settings-account-form', template: "<form [formGroup]=\"Account_Edit_Form\" (ngSubmit)=\"onSubmit()\">\n    <input type=\"text\" formControlName=\"website\" style=\"display: none;\">\n    <h3>\n        Login / Email\n    </h3>\n    <input type=\"email\" formControlName=\"eemail\" placeholder=\"Enter Email (used as your official login)\" minlength=\"7\"\n        maxlength=\"85\" title=\"Your Email (used as your official login)\" required (keyup)=\"CheckExi('eemail','email')\"\n        [ngClass]=\"{'is-invalid': this.FormService.isInvalid(Account_Edit_Form.get('eemail'))}\" />\n\n    <formErrorMessage [control]=\"Account_Edit_Form.get('eemail')\"></formErrorMessage>\n    <br />\n    <h3>\n        User Handle\n    </h3>\n    <input type=\"text\" formControlName=\"dispName\" placeholder=\"Enter your PUBLIC username...\"\n        title=\"Your public username\" minlength=\"3\" maxlength=\"50\" required\n        (ngModelChange)=\"CheckExi('dispName','disname')\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(Account_Edit_Form.get('dispName'))}\" />\n    <formErrorMessage [control]=\"Account_Edit_Form.get('dispName')\"></formErrorMessage>\n    <br />\n\n    <h3>\n        Reset Password\n    </h3>\n\n    <button type=\"button\" aria-label=\"Generate password button\" (click)=\"resetPass()\" class=\"button\"\n        style=\"padding-right: 1rem; font-size: 1.5rem; margin-right: 0.5rem;\">\n        <span>\n            <ion-icon size=\"small\" [icon]=\"key_outline\"></ion-icon>\n        </span>\n        ************\n    </button>\n    <br />\n    <br />\n    \n\n    <h3>\n        First Name / Last Name\n    </h3>\n    <p style=\"color: red;\">\n        *To edit, please visit our support page to send a name edit request.\n    </p>\n    <input style=\"width: 100%;\" type=\"text\" minlength=\"3\" maxlength=\"40\" placeholder=\"Your First Name...\"\n        pattern=\"[a-zA-Z]+\" title=\"Enter your first name...\" required formControlName=\"firstName\"\n        aria-label=\"First Name input field\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(Account_Edit_Form.get('firstName'))}\">\n    <formErrorMessage [control]=\"Account_Edit_Form.get('firstName')\"></formErrorMessage>\n    <br />\n\n\n    <input style=\"width: 100%;\" type=\"text\" minlength=\"3\" maxlength=\"40\" placeholder=\"Your Last Name...\"\n        pattern=\"[a-zA-Z]+\" title=\"Enter your last name...\" required formControlName=\"lastName\"\n        aria-label=\"Last Name input field\"\n        [ngClass]=\"{ 'is-invalid': this.FormService.isInvalid(Account_Edit_Form.get('lastName'))}\">\n    <formErrorMessage [control]=\"Account_Edit_Form.get('lastName')\"></formErrorMessage>\n    <br />\n    <br />\n\n    <div class=\"has-text-right\">\n\n        <app-loadingspinner></app-loadingspinner>\n        <div style=\"display: flex; justify-content: space-between;\">\n            <button type=\"submit\" aria-label=\"Create account button\" [disabled]=\"Account_Edit_Form.invalid\"\n                type=\"submit\" class=\"button button2\" style=\"padding-right: 1rem; font-size: 1.5rem;\">\n                <span>\n                    <ion-icon size=\"large\" [icon]=\"log_in_outline\"></ion-icon>\n                </span>\n                Save Changes\n            </button>\n            <button type=\"button\" (click)=\"requestDelete()\" class=\"button buttonR\">\n                <span>\n                    <ion-icon size=\"large\" [icon]=\"closeCircle\"></ion-icon>\n                </span>\n                Delete Account\n            </button>\n        </div>\n    </div>\n    <br />\n</form>" }]
        }], ctorParameters: function () { return [{ type: i1$2.FormBuilder }, { type: KeysComponent }, { type: ApiService }, { type: FormService }, { type: IndexedDBService }, { type: i1.Router }, { type: i4.AlertController }]; }, propDecorators: { User: [{
                type: Input
            }] } });

class SettingsComponent {
    constructor(USessionData, route, router) {
        this.USessionData = USessionData;
        this.route = route;
        this.router = router;
        // Define Routes
        this.routeKey = sRouteKey;
        this.routeKeyLogin = lRouteKey;
        this.routeView = this.route.snapshot.url[0] ? this.route.snapshot.url[0]['path'] : ''; // controls view of the page
        // To handle additional Settings 
        this.additionalSettings = ROUTE_CONFIG.filter(route => route.component === SettingsComponent && !(route.path in this.routeKey));
        //ion icons
        this.arrowleft = arrowForwardOutline;
        this.arrowright = arrowBackOutline;
        this.star = star;
    }
    // User Info Grab
    ngOnInit() {
        //this.User = await this.USessionData.getData();
    }
    setViewState(view) {
        if (view) {
            this.router.navigate(['/' + view]);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SettingsComponent, deps: [{ token: IndexedDBService }, { token: i1.ActivatedRoute }, { token: i1.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SettingsComponent, selector: "app-settings", ngImport: i0, template: "<!-- top bar for each setting -->\n<background></background>\n\n<div class=\"SettingsTopBar\">\n    <ion-icon *ngIf=\"routeView !== routeKey.settings.path \" style=\"margin: auto 0px;\" [icon]=\"arrowright\" slot=\"end\"\n        (click)=\"setViewState(routeKey.settings.path )\"></ion-icon>\n    <div style=\"display: flex;\">\n        <h5 (click)=\"setViewState(routeKey.settings.path )\" style=\"margin: auto; cursor: pointer; font-size: 1.2rem;\">\n            Settings |\n        </h5>\n        <p style=\"font-size: 1rem; margin: auto; margin-left: 0.5rem; color: var(--color)\">\n            {{routeView.charAt(0).toUpperCase() + routeView.slice(1)}}\n        </p>\n    </div>\n</div>\n\n\n<ng-template #loading>\n    <div>Loading...</div>\n</ng-template>\n\n\n<div class=\"section2\">\n\n<!-- main panel of all settings  -->\n    <div *ngIf=\"routeView === routeKey.settings.path  || !routeView\" class=\"section\">\n        <!-- <h1>\n            Settings\n        </h1> -->\n        <ion-list *ngIf=\"routeView == routeKey.settings.path  || !routeView\">\n            <div>\n                <ion-item (click)=\"setViewState(routeKey.profile.path )\">\n                    <ion-label>Edit Profile</ion-label>\n                    <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n                </ion-item>\n            </div>\n            <ion-item (click)=\"setViewState(routeKey.account.path )\">\n                <ion-label>Account Information</ion-label>\n                <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n            </ion-item>\n            <!-- <ion-item (click)=\"setViewState(SubStates[3])\">\n                <ion-label style=\"color: gold;\">Get Verified <ion-icon [icon]=\"star\" slot=\"end\"></ion-icon></ion-label>\n                <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n            </ion-item> -->\n            <ion-item (click)=\"setViewState(routeKey.help.path )\">\n                <ion-label>Help</ion-label>\n                <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n            </ion-item>\n            <!-- additional settings -->\n            <div *ngIf=\"additionalSettings\">\n                <div *ngFor=\"let s of additionalSettings\">\n                    <ion-item (click)=\"setViewState(s.path)\">\n                        <ion-label>{{s.path}}</ion-label>\n                        <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n                    </ion-item>\n                </div>\n            </div>\n            <ion-item (click)=\"setViewState(routeKeyLogin.logout.path )\">\n                <ion-label style=\"text-align: right;\">Logout</ion-label>\n                <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n            </ion-item>\n        </ion-list>\n    </div>\n\n    <div *ngIf=\"routeView === routeKey.profile.path \">\n        <settings-profile [User]=\"User\"></settings-profile>\n    </div>\n\n    <div *ngIf=\"routeView === routeKey.account.path \" class=\"section\">\n        <settings-account-form [User]=\"User\"></settings-account-form>\n    </div>\n\n    <!-- <div *ngIf=\"View_State === SubStates[3]\" class=\"section\">\n    <div *ngIf=\"User | async as user; else loading\">\n        <settings-verified [User]=\"User\"></settings-verified>\n    </div>\n</div> -->\n\n    <div *ngIf=\"routeView === routeKey.help.path \" class=\"section\">\n        <settings-help [User]=\"User\"></settings-help>\n    </div>\n\n\n</div>", styles: ["ion-item{cursor:pointer}.SettingsTopBar{display:flex;justify-content:flex-start;padding:.5rem;margin-top:calc(-1 * var(--ViewHeightMargin))}.SettingsTopBar div{margin:auto .5rem}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: i4.IonItem, selector: "ion-item", inputs: ["button", "color", "counter", "counterFormatter", "detail", "detailIcon", "disabled", "download", "fill", "href", "lines", "mode", "rel", "routerAnimation", "routerDirection", "shape", "target", "type"] }, { kind: "component", type: i4.IonLabel, selector: "ion-label", inputs: ["color", "mode", "position"] }, { kind: "component", type: i4.IonList, selector: "ion-list", inputs: ["inset", "lines", "mode"] }, { kind: "component", type: BackgroundComponent, selector: "background", inputs: ["BackgroundImage"] }, { kind: "component", type: ProfileComponent, selector: "settings-profile", inputs: ["User"] }, { kind: "component", type: HelpComponent, selector: "settings-help", inputs: ["User"] }, { kind: "component", type: UserFormComponent, selector: "settings-account-form", inputs: ["User"] }], animations: [
            trigger('slideAnimation', [
                state('settings', style({ transform: 'translateX(0)' })),
                state('profile', style({ transform: 'translateX(100%)' })),
                state('account', style({ transform: 'translateX(200%)' })),
                transition('settings => profile', animate('500ms ease-in-out')),
                transition('profile => account', animate('500ms ease-in-out')),
                transition('account => profile', animate('500ms ease-in-out')),
                transition('profile => settings', animate('500ms ease-in-out')),
                transition('settings => account', animate('500ms ease-in-out')),
                transition('account => settings', animate('500ms ease-in-out'))
            ])
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-settings', animations: [
                        trigger('slideAnimation', [
                            state('settings', style({ transform: 'translateX(0)' })),
                            state('profile', style({ transform: 'translateX(100%)' })),
                            state('account', style({ transform: 'translateX(200%)' })),
                            transition('settings => profile', animate('500ms ease-in-out')),
                            transition('profile => account', animate('500ms ease-in-out')),
                            transition('account => profile', animate('500ms ease-in-out')),
                            transition('profile => settings', animate('500ms ease-in-out')),
                            transition('settings => account', animate('500ms ease-in-out')),
                            transition('account => settings', animate('500ms ease-in-out'))
                        ])
                    ], template: "<!-- top bar for each setting -->\n<background></background>\n\n<div class=\"SettingsTopBar\">\n    <ion-icon *ngIf=\"routeView !== routeKey.settings.path \" style=\"margin: auto 0px;\" [icon]=\"arrowright\" slot=\"end\"\n        (click)=\"setViewState(routeKey.settings.path )\"></ion-icon>\n    <div style=\"display: flex;\">\n        <h5 (click)=\"setViewState(routeKey.settings.path )\" style=\"margin: auto; cursor: pointer; font-size: 1.2rem;\">\n            Settings |\n        </h5>\n        <p style=\"font-size: 1rem; margin: auto; margin-left: 0.5rem; color: var(--color)\">\n            {{routeView.charAt(0).toUpperCase() + routeView.slice(1)}}\n        </p>\n    </div>\n</div>\n\n\n<ng-template #loading>\n    <div>Loading...</div>\n</ng-template>\n\n\n<div class=\"section2\">\n\n<!-- main panel of all settings  -->\n    <div *ngIf=\"routeView === routeKey.settings.path  || !routeView\" class=\"section\">\n        <!-- <h1>\n            Settings\n        </h1> -->\n        <ion-list *ngIf=\"routeView == routeKey.settings.path  || !routeView\">\n            <div>\n                <ion-item (click)=\"setViewState(routeKey.profile.path )\">\n                    <ion-label>Edit Profile</ion-label>\n                    <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n                </ion-item>\n            </div>\n            <ion-item (click)=\"setViewState(routeKey.account.path )\">\n                <ion-label>Account Information</ion-label>\n                <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n            </ion-item>\n            <!-- <ion-item (click)=\"setViewState(SubStates[3])\">\n                <ion-label style=\"color: gold;\">Get Verified <ion-icon [icon]=\"star\" slot=\"end\"></ion-icon></ion-label>\n                <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n            </ion-item> -->\n            <ion-item (click)=\"setViewState(routeKey.help.path )\">\n                <ion-label>Help</ion-label>\n                <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n            </ion-item>\n            <!-- additional settings -->\n            <div *ngIf=\"additionalSettings\">\n                <div *ngFor=\"let s of additionalSettings\">\n                    <ion-item (click)=\"setViewState(s.path)\">\n                        <ion-label>{{s.path}}</ion-label>\n                        <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n                    </ion-item>\n                </div>\n            </div>\n            <ion-item (click)=\"setViewState(routeKeyLogin.logout.path )\">\n                <ion-label style=\"text-align: right;\">Logout</ion-label>\n                <ion-icon [icon]=\"arrowleft\" slot=\"end\"></ion-icon>\n            </ion-item>\n        </ion-list>\n    </div>\n\n    <div *ngIf=\"routeView === routeKey.profile.path \">\n        <settings-profile [User]=\"User\"></settings-profile>\n    </div>\n\n    <div *ngIf=\"routeView === routeKey.account.path \" class=\"section\">\n        <settings-account-form [User]=\"User\"></settings-account-form>\n    </div>\n\n    <!-- <div *ngIf=\"View_State === SubStates[3]\" class=\"section\">\n    <div *ngIf=\"User | async as user; else loading\">\n        <settings-verified [User]=\"User\"></settings-verified>\n    </div>\n</div> -->\n\n    <div *ngIf=\"routeView === routeKey.help.path \" class=\"section\">\n        <settings-help [User]=\"User\"></settings-help>\n    </div>\n\n\n</div>", styles: ["ion-item{cursor:pointer}.SettingsTopBar{display:flex;justify-content:flex-start;padding:.5rem;margin-top:calc(-1 * var(--ViewHeightMargin))}.SettingsTopBar div{margin:auto .5rem}\n"] }]
        }], ctorParameters: function () { return [{ type: IndexedDBService }, { type: i1.ActivatedRoute }, { type: i1.Router }]; } });

var cRouteKey = {
    contact: { path: 'contact-us', canActivate: false },
};

class LegalComponent {
    constructor(router, HTTPCall, sanitizer) {
        this.router = router;
        this.HTTPCall = HTTPCall;
        this.sanitizer = sanitizer;
        this.Content = 'policies';
    }
    ngOnInit() {
        this.router.url.subscribe(url => {
            const urlString = url.map(segment => segment.toString()).join('/');
            this.fetchContent(urlString);
        });
    }
    fetchContent(url) {
        this.HTTPCall.TakeAction({ CALL: url, Type: null }).subscribe((response) => {
            if (response.Success) {
                this.HTML_Output = response.Token;
                this.sanitizedHtml = this.sanitizer.bypassSecurityTrustHtml(this.HTML_Output);
            }
            else {
                this.HTML_Output = response.Message;
                this.sanitizedHtml = this.sanitizer.bypassSecurityTrustHtml(this.HTML_Output);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LegalComponent, deps: [{ token: i1.ActivatedRoute }, { token: ApiService }, { token: i1$3.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LegalComponent, selector: "legal-Paperwork", ngImport: i0, template: "\n<div class=\"section\" [innerHTML]=\"HTML_Output\"></div>  ", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LegalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'legal-Paperwork', template: "\n<div class=\"section\" [innerHTML]=\"HTML_Output\"></div>  " }]
        }], ctorParameters: function () { return [{ type: i1.ActivatedRoute }, { type: ApiService }, { type: i1$3.DomSanitizer }]; } });

class UserControlComponent {
    constructor(HTTPCall, Keys, USessionData, formBuilder, FormService, ErrorHelper, alertController) {
        this.HTTPCall = HTTPCall;
        this.Keys = Keys;
        this.USessionData = USessionData;
        this.formBuilder = formBuilder;
        this.FormService = FormService;
        this.ErrorHelper = ErrorHelper;
        this.alertController = alertController;
        this.ListObject = [];
        this.filteredUsers = [];
        this.editingUser = null;
        this.editingFields = null;
        this.searchTerm = '';
        this.sortOrders = {};
        this.groupFilters = {};
        this.filterableKeys = [];
        this.groupableKeys = [];
        this.displayedKeys = [];
        this.thumbWidth = 20; // Minimum thumb width
        this.thumbLeft = 0; // Thumb's left position
        this.isDragging = false;
        this.startX = 0;
        this.startLeft = 0;
        this.editForm = this.formBuilder.group({});
    }
    ngOnInit() {
        this.fetchUsers();
    }
    ngAfterViewInit() {
        this.updateThumb();
    }
    fetchUsers() {
        this.USessionData.USERDATA$.pipe(take(1), switchMap((data) => {
            this.User = data;
            return this.HTTPCall.TakeAction({ CALL: "ad1m_v", PassNullData: null }, true).pipe(take(1));
        })).subscribe((response) => {
            if (response.Token) {
                this.ListObject = response.Token;
                this.initializeKeys();
                this.applyFilters();
            }
        });
    }
    initializeKeys() {
        if (this.ListObject.length > 0) {
            const sampleUser = this.ListObject[0];
            this.displayedKeys = Object.keys(sampleUser);
            this.filterableKeys = this.displayedKeys.filter(key => typeof sampleUser[key] === 'number' || typeof sampleUser[key] === 'string');
            this.groupableKeys = this.displayedKeys.filter(key => typeof sampleUser[key] === 'string');
        }
    }
    onSearch() {
        this.applyFilters();
    }
    applyFilters() {
        this.filteredUsers = this.ListObject.filter(user => {
            return Object.values(user).some(value => value?.toString().toLowerCase().includes(this.searchTerm.toLowerCase()));
        });
        // Apply group filters
        Object.entries(this.groupFilters).forEach(([key, value]) => {
            if (value) {
                this.filteredUsers = this.filteredUsers.filter(user => user[key]?.toString() === value);
            }
        });
        // Apply sorting
        Object.entries(this.sortOrders).forEach(([key, order]) => {
            if (order) {
                this.filteredUsers.sort((a, b) => {
                    if (a[key] < b[key])
                        return order === 'asc' ? -1 : 1;
                    if (a[key] > b[key])
                        return order === 'asc' ? 1 : -1;
                    return 0;
                });
            }
        });
    }
    editUser(user) {
        this.editingUser = { ...user };
        this.buildForm(this.editingUser);
    }
    autoResizeTextarea(event) {
        const input = event.target;
        if (input) {
            input.style.height = 'auto';
            input.style.height = (input.scrollHeight + 2) + 'px';
        }
    }
    editField(user, key) {
        if (!user.ID) {
            console.error('User ID is undefined');
            return;
        }
        if (this.editingFields) {
            this.cancelFieldEdit();
        }
        this.editingFields = { userId: user.ID, key };
    }
    cancelFieldEdit() {
        this.editingFields = null;
    }
    async confirmEdit(user, key, newValue) {
        if (!user.ID) {
            console.error('User ID is undefined');
            return;
        }
        const alert = await this.alertController.create({
            header: 'Confirm Change',
            message: `Are you sure you want to change ${key} to "${newValue}"?`,
            buttons: [
                {
                    text: 'Cancel',
                    role: 'cancel'
                },
                {
                    text: 'Confirm',
                    handler: () => {
                        this.saveFieldEdit(user, key, newValue);
                    }
                }
            ]
        });
        await alert.present();
    }
    async saveFieldEdit(user, key, newValue) {
        if (!user.ID) {
            console.error('User ID is undefined');
            return;
        }
        const response = await this.HTTPCall.TakeAction({
            CALL: "ad1m_e",
            ID: user.ID,
            [key]: newValue
        }, true).toPromise();
        if (response && response.Success === true) {
            user[key] = newValue;
            this.applyFilters();
        }
        else {
            console.error('Failed to save field edit:', response);
        }
    }
    updateField(user, key, event) {
        const target = event.target;
        const newValue = target.value;
        if (newValue !== user[key]) {
            this.confirmEdit(user, key, newValue);
        }
        this.cancelFieldEdit();
    }
    onDocumentClick(event) {
        if (this.editingFields) {
            const target = event.target;
            if (!target.closest('.inline-edit-input')) {
                this.cancelEdit();
            }
        }
    }
    share_(userEmail) {
        navigator.clipboard.writeText(userEmail);
        this.ErrorHelper.setError({ Success: true, Message: 'Link Copied: ' + userEmail });
    }
    buildForm(user) {
        this.editForm = this.formBuilder.group({});
        // All Forms Include:
        this.editForm.addControl('website', this.formBuilder.control(''));
        this.editForm.addControl('Type', this.formBuilder.control(user.Type, [this.FormService.ValidateName])); // add type type to form with required validation
        this.editForm.addControl('firstname', this.formBuilder.control(user.firstname, [Validators.minLength(2), Validators.maxLength(50), this.FormService.ValidateName]));
        this.editForm.addControl('lastname', this.formBuilder.control(user.lastname, [Validators.minLength(2), Validators.maxLength(50), this.FormService.ValidateName]));
        this.editForm.addControl('bio', this.formBuilder.control(user.bio, [Validators.minLength(5), Validators.maxLength(175)]));
        this.editForm.addControl('url', this.formBuilder.control(user.url, [Validators.minLength(5), Validators.maxLength(200), this.FormService.ValidateLink]));
        if (user.Type == "Coach") {
            // build COACH Edit Form
            this.editForm.addControl('coachingname', this.formBuilder.control(user.coachingname, [Validators.minLength(2), Validators.maxLength(50), this.FormService.ValidateName]));
            this.editForm.addControl('title', this.formBuilder.control(user.title, [Validators.minLength(2), Validators.maxLength(50), this.FormService.ValidateName]));
            this.editForm.addControl('nameofcollege', this.formBuilder.control(user.nameofcollege, [Validators.minLength(5), Validators.maxLength(90), this.FormService.ValidateName]));
            this.editForm.addControl('conference', this.formBuilder.control(user.conference, [Validators.minLength(3), Validators.maxLength(50)]));
            this.editForm.addControl('division', this.formBuilder.control(user.division, [Validators.minLength(3), Validators.maxLength(50)]));
            this.editForm.addControl('schooltype', this.formBuilder.control(user.schooltype, [Validators.minLength(3), Validators.maxLength(50)]));
            this.editForm.addControl('teamname', this.formBuilder.control(user.teamname, [Validators.minLength(5), Validators.maxLength(50), this.FormService.ValidateName]));
            //
            this.editForm.addControl('state', this.formBuilder.control(user.state, [Validators.minLength(2), Validators.maxLength(50), this.FormService.ValidateName]));
            this.editForm.addControl('city', this.formBuilder.control(user.city, [Validators.minLength(2), Validators.maxLength(50), this.FormService.ValidateName]));
            this.editForm.addControl('urlschool', this.formBuilder.control(user.urlschool, [Validators.minLength(5), Validators.maxLength(200), this.FormService.ValidateLink]));
            this.editForm.addControl('videoR', this.formBuilder.control(user["videoR"], [Validators.minLength(15), Validators.maxLength(200), this.FormService.ValidateLink]));
        }
        else if (user.Type == "Player") {
            // build PLAYER edit form
            this.editForm.addControl('position', this.formBuilder.control(user.position, [Validators.minLength(2), Validators.maxLength(15)]));
            this.editForm.addControl('secondaryposition', this.formBuilder.control(user.secondaryposition, [Validators.minLength(2), Validators.maxLength(15)]));
            this.editForm.addControl('height', this.formBuilder.control(user.height, [Validators.minLength(2), Validators.maxLength(50), Validators.pattern(/^[0-9]+$/)]));
            this.editForm.addControl('weight', this.formBuilder.control(user.weight, [Validators.minLength(2), Validators.maxLength(50), Validators.pattern(/^[0-9]+$/)]));
            // to swap for birthday 
            this.editForm.addControl('age', this.formBuilder.control(user["age"], [Validators.minLength(2), Validators.maxLength(3), Validators.pattern(/^[0-9]+$/)]));
            //
            this.editForm.addControl('location', this.formBuilder.control(user.location, [Validators.minLength(2), Validators.maxLength(100)]));
            this.editForm.addControl('club', this.formBuilder.control(user.club, [Validators.minLength(2), Validators.maxLength(25)]));
            this.editForm.addControl('divisionp', this.formBuilder.control(user.division, [Validators.minLength(3), Validators.maxLength(100)]));
            this.editForm.addControl('lastclub', this.formBuilder.control(user.lastclub, [Validators.minLength(2), Validators.maxLength(35)]));
            this.editForm.addControl('gamesplayed', this.formBuilder.control(user.gamesplayed, [Validators.minLength(1), Validators.maxLength(50), Validators.pattern('[0-9]*')]));
            this.editForm.addControl('goals', this.formBuilder.control(user.goals, [Validators.minLength(1), Validators.maxLength(50), Validators.pattern(/^[0-9]+$/)]));
            this.editForm.addControl('assists', this.formBuilder.control(user.goals, [Validators.minLength(1), Validators.maxLength(50), Validators.pattern(/^[0-9]+$/)]));
            this.editForm.addControl('ncaaid', this.formBuilder.control(user.ncaaid, [Validators.minLength(2), Validators.maxLength(50), Validators.pattern(/^[0-9]+$/)]));
            this.editForm.addControl('strongfoot', this.formBuilder.control(user.strongfoot, [Validators.minLength(2), Validators.maxLength(20), this.FormService.ValidateName]));
            this.editForm.addControl('linktostat', this.formBuilder.control(user.linktostat, [Validators.minLength(2), Validators.maxLength(500)]));
            this.editForm.addControl('education', this.formBuilder.control(user.education, [Validators.minLength(1), Validators.maxLength(50)]));
            this.editForm.addControl('graduationyear', this.formBuilder.control(user.graduationyear, [Validators.minLength(2), Validators.maxLength(4), Validators.pattern(/^[0-9]+$/)]));
            this.editForm.addControl('grades', this.formBuilder.control(user.grades, [Validators.minLength(1), Validators.maxLength(20)]));
            this.editForm.addControl('transferstudent', this.formBuilder.control(user.transferstudent, [Validators.minLength(1), Validators.maxLength(5)]));
            this.editForm.addControl('videoH', this.formBuilder.control(user["videoH"], [Validators.minLength(15), Validators.maxLength(200), this.FormService.ValidateLink]));
        }
    }
    async saveUser() {
        if (this.editingUser && this.editForm.valid) {
            const formValues = this.FormService.getTouchedAndDirtyValues(this.editForm);
            const response = await this.HTTPCall.TakeAction({
                CALL: "ad1m_e",
                ...formValues,
                ID: this.editingUser.ID
            }, true).toPromise();
            if (response && response.Success === true) {
                const index = this.ListObject.findIndex(u => u.ID === this.editingUser.ID);
                if (index !== -1) {
                    this.ListObject[index] = { ...this.ListObject[index], ...formValues };
                    this.applyFilters();
                }
                this.editingUser = null;
            }
            else {
                console.error('Failed to save user:', response);
            }
        }
    }
    cancelEdit() {
        this.editingUser = null;
        this.editForm.reset();
    }
    getUniqueValues(key) {
        return Array.from(new Set(this.ListObject.map(user => user[key]?.toString() || '')));
    }
    toggleSort(key) {
        if (this.sortOrders[key] === 'asc') {
            this.sortOrders[key] = 'desc';
        }
        else {
            this.sortOrders[key] = 'asc';
        }
        this.applyFilters();
    }
    getSortIcon(key) {
        if (!this.sortOrders[key])
            return '↕';
        return this.sortOrders[key] === 'asc' ? '↑' : '↓';
    }
    isGroupable(key) {
        return this.groupableKeys.includes(key);
    }
    updateThumb() {
        const scrollableContent = this.scrollableContent.nativeElement;
        const { scrollWidth, clientWidth, scrollLeft } = scrollableContent;
        // Ensure scrollableContent is scrollable
        if (scrollWidth <= clientWidth) {
            this.thumbWidth = 0; // Hide the scrollbar
            this.thumbLeft = 0;
            return;
        }
        // Calculate thumb width and position
        this.thumbWidth = Math.max((clientWidth / scrollWidth) * clientWidth, 40);
        const maxThumbLeft = clientWidth - this.thumbWidth;
        const scrollRatio = scrollLeft / (scrollWidth - clientWidth);
        this.thumbLeft = scrollRatio * maxThumbLeft;
    }
    scrollLeft() {
        const scrollableContent = this.scrollableContent.nativeElement;
        scrollableContent.scrollLeft -= 20;
        this.updateThumb();
    }
    scrollRight() {
        const scrollableContent = this.scrollableContent.nativeElement;
        scrollableContent.scrollLeft += 20;
        this.updateThumb();
    }
    jumpTo(event) {
        const track = event.target;
        if (!track.classList.contains('scrollbar-track')) {
            return; // Ignore the click if it's outside the scrollbar track
        }
        const clickPosition = event.offsetX;
        const trackWidth = track.clientWidth;
        const scrollableContent = this.scrollableContent.nativeElement;
        const newLeft = (clickPosition / trackWidth) * scrollableContent.scrollWidth;
        scrollableContent.scrollLeft = newLeft;
        this.updateThumb();
    }
    startDrag(event) {
        const thumb = event.target;
        if (!thumb.classList.contains('scrollbar-thumb')) {
            return; // Don't start drag if it's not the thumb
        }
        event.preventDefault(); // Prevent native drag interactions
        this.isDragging = true;
        this.startX = event.clientX;
        this.startLeft = this.thumbLeft;
    }
    onDrag(event) {
        if (!this.isDragging)
            return;
        event.preventDefault(); // Prevent native text selection or interactions
        const scrollableContent = this.scrollableContent.nativeElement;
        const deltaX = event.clientX - this.startX;
        const trackWidth = scrollableContent.clientWidth - this.thumbWidth;
        // Clamp thumbLeft between 0 and trackWidth
        const newLeft = Math.min(Math.max(this.startLeft + deltaX, 0), trackWidth);
        // Update thumbLeft and scrollable content position
        this.thumbLeft = newLeft;
        const scrollRatio = newLeft / trackWidth;
        scrollableContent.scrollLeft = scrollRatio * scrollableContent.scrollWidth;
    }
    endDrag(event) {
        if (!this.isDragging)
            return;
        event.preventDefault(); // Prevent unintended native interactions
        const scrollableContent = this.scrollableContent.nativeElement;
        const trackWidth = scrollableContent.clientWidth - this.thumbWidth;
        const scrollRatio = scrollableContent.scrollLeft / scrollableContent.scrollWidth;
        // Ensure thumbLeft synchronizes exactly
        this.thumbLeft = scrollRatio * trackWidth;
        this.isDragging = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserControlComponent, deps: [{ token: ApiService }, { token: KeysComponent }, { token: IndexedDBService }, { token: i1$2.FormBuilder }, { token: FormService }, { token: ErrorHandlingService }, { token: i4.AlertController }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: UserControlComponent, selector: "app-user-control", host: { listeners: { "document:click": "onDocumentClick($event)", "mousedown": "startDrag($event)", "document:mousemove": "onDrag($event)", "document:mouseup": "endDrag($event)" } }, viewQueries: [{ propertyName: "scrollableContent", first: true, predicate: ["scrollableContent"], descendants: true }], ngImport: i0, template: "<div class=\"user-grid-body\">\n  <div class=\"fixed-header\">\n    <div class=\"header-content\">\n      <div class=\"search-bar\">\n        <input type=\"text\" [(ngModel)]=\"searchTerm\" (input)=\"onSearch()\" placeholder=\"Search users...\">\n      </div>\n    </div>\n    <div class=\"scrollbar-container horizontal\">\n      <div class=\"arrow left\" (click)=\"scrollLeft()\">\u25C0</div>\n      <div class=\"scrollbar-track\" (click)=\"jumpTo($event)\">\n        <div\n          class=\"scrollbar-thumb\"\n          [style.width.px]=\"thumbWidth\"\n          [style.left.px]=\"thumbLeft\"\n          (mousedown)=\"startDrag($event)\"\n          (click)=\"$event.stopPropagation()\"\n        ></div>\n      </div>\n      <div class=\"arrow right\" (click)=\"scrollRight()\">\u25B6</div>\n    </div>    \n  </div>\n\n  <div class=\"scrollable-content\" #scrollableContent>\n    <table class=\"user-grid\">\n      <thead>\n        <tr>\n          <th class=\"sticky-column\">Edit</th>\n          <th class=\"sticky-column\">First Name</th>\n          <th class=\"sticky-column\">Last Name</th>\n          <th class=\"sticky-column\">Email</th>\n          <th *ngFor=\"let key of displayedKeys.slice(3)\">\n            {{ key }}\n            <div class=\"filter-controls\">\n              <button (click)=\"toggleSort(key)\" class=\"sort-button\">\n                {{ getSortIcon(key) }}\n              </button>\n              <select *ngIf=\"isGroupable(key)\" [(ngModel)]=\"groupFilters[key]\" (change)=\"applyFilters()\">\n                <option value=\"\">All</option>\n                <option *ngFor=\"let value of getUniqueValues(key)\" [value]=\"value\">{{ value }}</option>\n              </select>\n            </div>\n          </th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr *ngFor=\"let user of filteredUsers\">\n          <td class=\"sticky-column actions-column\">\n            <button class=\"edit-button\" (click)=\"editUser(user)\" (click)=\"$event.stopPropagation()\">\n              <i class=\"fas fa-pen\"></i>\n            </button>\n          </td>\n          <td class=\"sticky-column\">{{ user.firstname }}</td>\n          <td class=\"sticky-column\">{{ user.lastname }}</td>\n          <td class=\"sticky-column\">\n            <button class=\"email-button\" (click)=\"share_(user.Email)\">Email</button>\n            {{ user.Email }}\n          </td>\n          <td *ngFor=\"let key of displayedKeys.slice(3)\" (click)=\"editField(user, key)\">\n            <ng-container *ngIf=\"editingFields?.userId !== user.ID || editingFields?.key !== key; else editInput\">\n              <span class=\"truncate\">{{ user[key] }}</span>\n            </ng-container>\n            <ng-template #editInput>\n              <textarea \n              [value]=\"user[key] ?? ''\" \n              (input)=\"autoResizeTextarea($event)\"\n              (blur)=\"updateField(user, key, $event)\"\n              (keyup.enter)=\"updateField(user, key, $event)\"\n              (click)=\"autoResizeTextarea($event)\"\n              (click)=\"$event.stopPropagation()\"\n              class=\"inline-edit-input\"\n              autoFocus\n              ></textarea>\n            </ng-template>\n          </td>\n        </tr>\n      </tbody>\n    </table>\n  </div>\n  <div *ngIf=\"editingUser\" class=\"edit-form-overlay\">\n    <div class=\"edit-form-container\">\n      <h3>Edit User</h3>\n      <form [formGroup]=\"editForm\" (ngSubmit)=\"saveUser()\">\n        <div *ngFor=\"let control of editForm.controls | keyvalue\" class=\"form-field\">\n          <label [for]=\"control.key\">{{ control.key }}:</label>\n          <input [id]=\"control.key\" [formControlName]=\"control.key\" [placeholder]=\"control.key\">\n          <div *ngIf=\"editForm.get(control.key)?.invalid && (editForm.get(control.key)?.dirty || editForm.get(control.key)?.touched)\" class=\"error-message\">\n            Please enter a valid {{ control.key }}.\n          </div>\n        </div>\n        <div class=\"form-actions\">\n          <button type=\"submit\" [disabled]=\"editForm.invalid\">Save</button>\n          <button type=\"button\" (click)=\"cancelEdit()\">Cancel</button>\n        </div>\n      </form>\n    </div>\n  </div>\n</div>", styles: [".user-grid-body{position:relative;overflow:hidden;flex-grow:1;display:flex;flex-direction:column;height:86vh}.truncate{display:block;max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.inline-edit-input{width:100%;min-height:10px;padding:5px;border:1px solid #ff0000;border-radius:4px;resize:none;overflow:hidden;white-space:pre-wrap;word-wrap:break-word}td{max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.fixed-header{position:sticky;top:0;background-color:#fff;z-index:10;padding:10px 0;box-shadow:0 2px 5px #0000001a}.header-content{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}.search-bar{flex:1;margin-right:20px}.search-bar input{width:100%;max-width:300px;padding:10px;border:1px solid #dddddd;border-radius:4px;font-size:16px}.filter-controls{display:flex;flex-direction:row;align-items:center;white-space:nowrap}.filter-controls .sort-button,.filter-controls select{flex-shrink:0;margin-left:5px}.scrollbar-container{display:flex;align-items:center;width:100%;height:40px;background:#fff;border:1px solid #dddddd;border-radius:5px}.scrollbar-container.horizontal{flex-direction:row}.scrollbar-container.horizontal .arrow{height:100%;width:auto;padding:0 10px;cursor:pointer;-webkit-user-select:none;user-select:none;display:flex;align-items:center;justify-content:center}.scrollbar-container.horizontal .arrow:hover{background:#fff}.scrollbar-container.horizontal .scrollbar-track{flex-grow:1;height:80%;background:#fff;position:relative;border-radius:5px;margin:0 5px;cursor:pointer}.scrollbar-container.horizontal .scrollbar-track .scrollbar-thumb{position:absolute;height:100%;background:#888;border-radius:5px;cursor:grab;transition:background .3s}.scrollbar-container.horizontal .scrollbar-track .scrollbar-thumb:hover{background:#666}.scrollable-content{overflow-x:hidden;overflow-y:auto;max-height:calc(100vh - 150px)}.user-grid{width:100%;border-collapse:separate;border-spacing:0}.user-grid th,.user-grid td{max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:normal;word-wrap:break-word}.user-grid th{background-color:#fcc;font-weight:700;position:sticky;top:0;z-index:5}.user-grid .sticky-column{position:sticky;background-color:#fff;z-index:4}.user-grid th.sticky-column{z-index:6}.user-grid th:nth-child(1),.user-grid td:nth-child(1){left:0;min-width:28px}.user-grid th:nth-child(2),.user-grid td:nth-child(2){left:28px;min-width:120px}.user-grid th:nth-child(3),.user-grid td:nth-child(3){left:148px;min-width:120px}.user-grid th:nth-child(4),.user-grid td:nth-child(4){left:268px;min-width:200px}.email-button{margin-left:10px;padding:5px 10px;background-color:red;color:#fff;border:none;border-radius:4px;cursor:pointer}.edit-button{background:none;border:none;cursor:pointer;padding:5px;font-size:16px;color:red}.editable-field{cursor:pointer}.editable-field:hover{background-color:#ff00001a}.inline-edit-input{width:100%;padding:5px;border:1px solid #ff0000;border-radius:4px}.edit-form-overlay{position:fixed;inset:0;background-color:#00000080;display:flex;justify-content:center;align-items:center;z-index:1000}.edit-form-container{background-color:#fff;padding:20px;border-radius:8px;max-width:500px;width:100%;max-height:80vh;overflow-y:auto}.edit-form-container h3{color:red;margin-bottom:20px}.edit-form-container .form-field{margin-bottom:15px}.edit-form-container .form-field label{display:block;margin-bottom:5px;font-weight:700}.edit-form-container .form-field input{width:100%;padding:8px;border:1px solid #dddddd;border-radius:4px}.edit-form-container .form-field .error-message{color:red;font-size:12px;margin-top:5px}.edit-form-container .form-actions{display:flex;justify-content:flex-end;gap:10px}.edit-form-container .form-actions button{padding:8px 16px;border:none;border-radius:4px;cursor:pointer}.edit-form-container .form-actions button[type=submit]{background-color:red;color:#fff}.edit-form-container .form-actions button[type=button]{background-color:#ddd;color:#333}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1$2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "pipe", type: i3.KeyValuePipe, name: "keyvalue" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: UserControlComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-user-control', template: "<div class=\"user-grid-body\">\n  <div class=\"fixed-header\">\n    <div class=\"header-content\">\n      <div class=\"search-bar\">\n        <input type=\"text\" [(ngModel)]=\"searchTerm\" (input)=\"onSearch()\" placeholder=\"Search users...\">\n      </div>\n    </div>\n    <div class=\"scrollbar-container horizontal\">\n      <div class=\"arrow left\" (click)=\"scrollLeft()\">\u25C0</div>\n      <div class=\"scrollbar-track\" (click)=\"jumpTo($event)\">\n        <div\n          class=\"scrollbar-thumb\"\n          [style.width.px]=\"thumbWidth\"\n          [style.left.px]=\"thumbLeft\"\n          (mousedown)=\"startDrag($event)\"\n          (click)=\"$event.stopPropagation()\"\n        ></div>\n      </div>\n      <div class=\"arrow right\" (click)=\"scrollRight()\">\u25B6</div>\n    </div>    \n  </div>\n\n  <div class=\"scrollable-content\" #scrollableContent>\n    <table class=\"user-grid\">\n      <thead>\n        <tr>\n          <th class=\"sticky-column\">Edit</th>\n          <th class=\"sticky-column\">First Name</th>\n          <th class=\"sticky-column\">Last Name</th>\n          <th class=\"sticky-column\">Email</th>\n          <th *ngFor=\"let key of displayedKeys.slice(3)\">\n            {{ key }}\n            <div class=\"filter-controls\">\n              <button (click)=\"toggleSort(key)\" class=\"sort-button\">\n                {{ getSortIcon(key) }}\n              </button>\n              <select *ngIf=\"isGroupable(key)\" [(ngModel)]=\"groupFilters[key]\" (change)=\"applyFilters()\">\n                <option value=\"\">All</option>\n                <option *ngFor=\"let value of getUniqueValues(key)\" [value]=\"value\">{{ value }}</option>\n              </select>\n            </div>\n          </th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr *ngFor=\"let user of filteredUsers\">\n          <td class=\"sticky-column actions-column\">\n            <button class=\"edit-button\" (click)=\"editUser(user)\" (click)=\"$event.stopPropagation()\">\n              <i class=\"fas fa-pen\"></i>\n            </button>\n          </td>\n          <td class=\"sticky-column\">{{ user.firstname }}</td>\n          <td class=\"sticky-column\">{{ user.lastname }}</td>\n          <td class=\"sticky-column\">\n            <button class=\"email-button\" (click)=\"share_(user.Email)\">Email</button>\n            {{ user.Email }}\n          </td>\n          <td *ngFor=\"let key of displayedKeys.slice(3)\" (click)=\"editField(user, key)\">\n            <ng-container *ngIf=\"editingFields?.userId !== user.ID || editingFields?.key !== key; else editInput\">\n              <span class=\"truncate\">{{ user[key] }}</span>\n            </ng-container>\n            <ng-template #editInput>\n              <textarea \n              [value]=\"user[key] ?? ''\" \n              (input)=\"autoResizeTextarea($event)\"\n              (blur)=\"updateField(user, key, $event)\"\n              (keyup.enter)=\"updateField(user, key, $event)\"\n              (click)=\"autoResizeTextarea($event)\"\n              (click)=\"$event.stopPropagation()\"\n              class=\"inline-edit-input\"\n              autoFocus\n              ></textarea>\n            </ng-template>\n          </td>\n        </tr>\n      </tbody>\n    </table>\n  </div>\n  <div *ngIf=\"editingUser\" class=\"edit-form-overlay\">\n    <div class=\"edit-form-container\">\n      <h3>Edit User</h3>\n      <form [formGroup]=\"editForm\" (ngSubmit)=\"saveUser()\">\n        <div *ngFor=\"let control of editForm.controls | keyvalue\" class=\"form-field\">\n          <label [for]=\"control.key\">{{ control.key }}:</label>\n          <input [id]=\"control.key\" [formControlName]=\"control.key\" [placeholder]=\"control.key\">\n          <div *ngIf=\"editForm.get(control.key)?.invalid && (editForm.get(control.key)?.dirty || editForm.get(control.key)?.touched)\" class=\"error-message\">\n            Please enter a valid {{ control.key }}.\n          </div>\n        </div>\n        <div class=\"form-actions\">\n          <button type=\"submit\" [disabled]=\"editForm.invalid\">Save</button>\n          <button type=\"button\" (click)=\"cancelEdit()\">Cancel</button>\n        </div>\n      </form>\n    </div>\n  </div>\n</div>", styles: [".user-grid-body{position:relative;overflow:hidden;flex-grow:1;display:flex;flex-direction:column;height:86vh}.truncate{display:block;max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.inline-edit-input{width:100%;min-height:10px;padding:5px;border:1px solid #ff0000;border-radius:4px;resize:none;overflow:hidden;white-space:pre-wrap;word-wrap:break-word}td{max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.fixed-header{position:sticky;top:0;background-color:#fff;z-index:10;padding:10px 0;box-shadow:0 2px 5px #0000001a}.header-content{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}.search-bar{flex:1;margin-right:20px}.search-bar input{width:100%;max-width:300px;padding:10px;border:1px solid #dddddd;border-radius:4px;font-size:16px}.filter-controls{display:flex;flex-direction:row;align-items:center;white-space:nowrap}.filter-controls .sort-button,.filter-controls select{flex-shrink:0;margin-left:5px}.scrollbar-container{display:flex;align-items:center;width:100%;height:40px;background:#fff;border:1px solid #dddddd;border-radius:5px}.scrollbar-container.horizontal{flex-direction:row}.scrollbar-container.horizontal .arrow{height:100%;width:auto;padding:0 10px;cursor:pointer;-webkit-user-select:none;user-select:none;display:flex;align-items:center;justify-content:center}.scrollbar-container.horizontal .arrow:hover{background:#fff}.scrollbar-container.horizontal .scrollbar-track{flex-grow:1;height:80%;background:#fff;position:relative;border-radius:5px;margin:0 5px;cursor:pointer}.scrollbar-container.horizontal .scrollbar-track .scrollbar-thumb{position:absolute;height:100%;background:#888;border-radius:5px;cursor:grab;transition:background .3s}.scrollbar-container.horizontal .scrollbar-track .scrollbar-thumb:hover{background:#666}.scrollable-content{overflow-x:hidden;overflow-y:auto;max-height:calc(100vh - 150px)}.user-grid{width:100%;border-collapse:separate;border-spacing:0}.user-grid th,.user-grid td{max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:normal;word-wrap:break-word}.user-grid th{background-color:#fcc;font-weight:700;position:sticky;top:0;z-index:5}.user-grid .sticky-column{position:sticky;background-color:#fff;z-index:4}.user-grid th.sticky-column{z-index:6}.user-grid th:nth-child(1),.user-grid td:nth-child(1){left:0;min-width:28px}.user-grid th:nth-child(2),.user-grid td:nth-child(2){left:28px;min-width:120px}.user-grid th:nth-child(3),.user-grid td:nth-child(3){left:148px;min-width:120px}.user-grid th:nth-child(4),.user-grid td:nth-child(4){left:268px;min-width:200px}.email-button{margin-left:10px;padding:5px 10px;background-color:red;color:#fff;border:none;border-radius:4px;cursor:pointer}.edit-button{background:none;border:none;cursor:pointer;padding:5px;font-size:16px;color:red}.editable-field{cursor:pointer}.editable-field:hover{background-color:#ff00001a}.inline-edit-input{width:100%;padding:5px;border:1px solid #ff0000;border-radius:4px}.edit-form-overlay{position:fixed;inset:0;background-color:#00000080;display:flex;justify-content:center;align-items:center;z-index:1000}.edit-form-container{background-color:#fff;padding:20px;border-radius:8px;max-width:500px;width:100%;max-height:80vh;overflow-y:auto}.edit-form-container h3{color:red;margin-bottom:20px}.edit-form-container .form-field{margin-bottom:15px}.edit-form-container .form-field label{display:block;margin-bottom:5px;font-weight:700}.edit-form-container .form-field input{width:100%;padding:8px;border:1px solid #dddddd;border-radius:4px}.edit-form-container .form-field .error-message{color:red;font-size:12px;margin-top:5px}.edit-form-container .form-actions{display:flex;justify-content:flex-end;gap:10px}.edit-form-container .form-actions button{padding:8px 16px;border:none;border-radius:4px;cursor:pointer}.edit-form-container .form-actions button[type=submit]{background-color:red;color:#fff}.edit-form-container .form-actions button[type=button]{background-color:#ddd;color:#333}\n"] }]
        }], ctorParameters: function () { return [{ type: ApiService }, { type: KeysComponent }, { type: IndexedDBService }, { type: i1$2.FormBuilder }, { type: FormService }, { type: ErrorHandlingService }, { type: i4.AlertController }]; }, propDecorators: { scrollableContent: [{
                type: ViewChild,
                args: ['scrollableContent']
            }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }], startDrag: [{
                type: HostListener,
                args: ['mousedown', ['$event']]
            }], onDrag: [{
                type: HostListener,
                args: ['document:mousemove', ['$event']]
            }], endDrag: [{
                type: HostListener,
                args: ['document:mouseup', ['$event']]
            }] } });

class FourZeroFourComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FourZeroFourComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FourZeroFourComponent, selector: "app-404", ngImport: i0, template: "\n<div class=\"section\">\n    <logo-box></logo-box>\n    <br />\n    <h1 style=\"font-size: 75px;\">\n        404\n    </h1>\n    <br />\n    <h3>\n        Dropped the weight... Sorry, the page you are looking for does not exist.\n    </h3>\n    <br />\n    <!-- <p>\n        Try returning to the <a *ngIf=\"loggedIn; else homeLink\" href=\"/account\" class=\"button\">My Account</a>\n        <ng-template #homeLink>\n            <a href=\"/\" class=\"button\">home page</a>\n        </ng-template>\n        or <a href=\"/contact\" class=\"button\">contact us</a> if you need help.\n    </p> -->\n</div>\n\n<!-- <div style=\"background: var(--color);\" class=\"p-5 m-a has-text-centered\">\n    <h3 class=\"text-white\">\n        The Latest News\n    </h3>\n    <br />\n    <app-socialmedia></app-socialmedia>\n</div> -->\n", styles: [".section{padding:5rem}\n"], dependencies: [{ kind: "component", type: LogoBoxComponent, selector: "logo-box", inputs: ["styling", "Boxstyling", "AltText", "Logo", "TagOn"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FourZeroFourComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-404', template: "\n<div class=\"section\">\n    <logo-box></logo-box>\n    <br />\n    <h1 style=\"font-size: 75px;\">\n        404\n    </h1>\n    <br />\n    <h3>\n        Dropped the weight... Sorry, the page you are looking for does not exist.\n    </h3>\n    <br />\n    <!-- <p>\n        Try returning to the <a *ngIf=\"loggedIn; else homeLink\" href=\"/account\" class=\"button\">My Account</a>\n        <ng-template #homeLink>\n            <a href=\"/\" class=\"button\">home page</a>\n        </ng-template>\n        or <a href=\"/contact\" class=\"button\">contact us</a> if you need help.\n    </p> -->\n</div>\n\n<!-- <div style=\"background: var(--color);\" class=\"p-5 m-a has-text-centered\">\n    <h3 class=\"text-white\">\n        The Latest News\n    </h3>\n    <br />\n    <app-socialmedia></app-socialmedia>\n</div> -->\n", styles: [".section{padding:5rem}\n"] }]
        }] });

var ROUTE_CONFIG = [];
class GlobalInitializer {
    constructor(HTTPCall, Splash, userService, router) {
        this.HTTPCall = HTTPCall;
        this.Splash = Splash;
        this.userService = userService;
        this.router = router;
        // private Key = 'https://dev.collegerecruit.us/CORE_FE/GATEWAY.php'; // hard coded
        this.Trig = 'In1tAppG1ob'; // hard coded
        this._Globals$ = new BehaviorSubject(null);
        this.GLOBALS$ = this._Globals$.asObservable();
    }
    initGlobals(GLOBALS_App, Routes, Key) {
        /* set routes */
        // take routes from parameter
        // take routes from library
        // merge them together and set them
        //initialize routes
        this.userSubscription = this.userService.USERDATA$.subscribe((userData) => {
            //this.User = userData;
            let SettingCheck = userData ? userData.CONFIG : null;
            if (SettingCheck) {
                this.Debug = userData.CONFIG.DEBUG;
            }
        });
        const additionalRoutes = Routes;
        if (additionalRoutes) {
            additionalRoutes.forEach((routeInfo) => {
                if (routeInfo.component) {
                    this.addRoute(routeInfo.path, routeInfo.component, routeInfo.RestrictAcess, routeInfo.children);
                }
            });
        }
        //fallback main page
        this.addRoute('', LoginComponent, true);
        //fallback 404
        this.addRoute('404', FourZeroFourComponent);
        // Construct Routes Available in library //
        /*
        ADD NEW ROUTES HERE
        */
        //main component routes with sub-components
        this.addRoute(cRouteKey, ContactComponent);
        this.addRoute(sRouteKey, SettingsComponent);
        this.addRoute(eRouteKey, EcommerceComponent);
        this.addRoute(lRouteKey, LoginComponent);
        // hard coded routes
        this.addRoute('user-control', UserControlComponent, true);
        // Legal Routes - added and have to be setup in component
        this.addRoute('policies', LegalComponent);
        this.addRoute('terms', LegalComponent);
        this.addRoute('datarequest', LegalComponent);
        this.addRoute('storepolicies', LegalComponent);
        /////////////////////////////////////
        //wait for backend call
        this.Splash.setSplash();
        return new Observable((observer) => {
            this.HTTPCall.TakeAction({ CALL: this.Trig }, false, {}, Key).subscribe({
                next: (response) => {
                    console.log(response);
                    if (response.Success && response.Token) {
                        let Token = response.Token;
                        this._Globals$.next(Token);
                        let CreateSettingGlobal = { SETTINGS: { ...Token.SETTINGS, ...GLOBALS_App[0] } };
                        let INITGlobal = { ...Token, ...CreateSettingGlobal };
                        this.userService.createSession(INITGlobal);
                        this.Splash.unsetSplashPage();
                        observer.next(Token);
                        observer.complete();
                    }
                    else {
                        observer.error('Failed to initialize globals');
                    }
                },
                error: (error) => {
                    observer.error(error);
                }
            });
        });
    }
    initializeRoutes() {
        //initializes all routes from subroutes
        const routes = Array.from(ROUTE_CONFIG.values()).map(route => {
            const routeConfig = {
                path: route.path,
                component: route.component
            };
            //if can activate
            if (route.canActivate) {
                routeConfig.canActivate = route.canActivate;
            }
            if (route.children) {
                routeConfig.children = route.children;
            }
            return routeConfig;
        });
        // Add a wildcard route
        routes.push({ path: '**', redirectTo: '/404' });
        // Configure the router with the dynamic routes
        this.router.resetConfig(routes);
    }
    // ConstructRoutes(SubComp_RouteData: RouteKey, Component: Type<any>, canActivate: any, dontActivate: any[] = []) {
    //     Object.values(SubComp_RouteData).forEach(value => {
    //       // console.log(value);
    //       if(value) {
    //       } else {
    //         this.addRoute({ path: value, component: Component, canActivate: [canActivate] });
    //       }
    //     });
    //   }
    addRoute(path, component, authGuard, children) {
        // Make canActivate an array if not undefined
        const canActivateArray = authGuard ? [AuthGuard] : undefined;
        //add single route
        if (typeof path === "string") {
            ROUTE_CONFIG.push({ path: path, component: component, canActivate: canActivateArray, children: children });
            //add routes
        }
        else {
            Object.values(path).forEach(value => {
                const routeCanActivate = value.canActivate ? [AuthGuard] : canActivateArray;
                ROUTE_CONFIG.push({ path: value.path, component: component, canActivate: routeCanActivate, children: children });
            });
        }
        this.initializeRoutes(); // Re-initialize routes with updated route map
    }
    getRoutes() {
        return ROUTE_CONFIG;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: GlobalInitializer, deps: [{ token: ApiService }, { token: SplashHandlingService }, { token: IndexedDBService }, { token: i1.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: GlobalInitializer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: GlobalInitializer, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: ApiService }, { type: SplashHandlingService }, { type: IndexedDBService }, { type: i1.Router }]; } });
///////////////////////////// AUTH GUARD /////////////////////////////////////////////////////////////////////
class AuthGuard {
    /*
        ADDED RESTRICTION NAVIGATION
        // and updated some comments
    */
    // Restrictions: { Key: string, AllowedUrls: string[] }[] = [{ Key: 'Incomplete', AllowedUrls: ['Welcome'] }];
    constructor(userService, View, route) {
        this.userService = userService;
        this.View = View;
        this.route = route;
        this.key = lRouteKey;
    }
    async canActivate(route, state) {
        try {
            const currentRoute = route.routeConfig?.path;
            let LoggedIn = await this.userService.isLoggedIn();
            // Login Restrictions
            if (!LoggedIn && currentRoute !== this.key.login.path) {
                // NOT LOGGED IN - route to login 
                this.View.navigate(['/' + this.key.login.path]);
                return false;
            }
            else if (LoggedIn && currentRoute === this.key.login.path) {
                // LOGGED IN BUT ON LOGIN - route to homepage 
                this.View.navigate(['/']);
                return false;
            }
            else if (LoggedIn) {
                // USER LOGGED IN - ACCESS REDIRECTS
                const User = await this.userService.getData();
                const UserStatus_Restrict = User.Restrict;
                // OVERRIDE RESTRICTION - always sends user to restriction page until otherwise updated 
                if (UserStatus_Restrict && UserStatus_Restrict !== '' && currentRoute !== UserStatus_Restrict) {
                    this.View.navigate([UserStatus_Restrict]);
                    return true;
                }
                // PAGE RESTRICTIONS 
                // To block access based on user type keys 
                // IN DEVELOPMENT FOR LATER 
                // let AllowedUrls = this.Restrictions.find(x => x.Key === UserStatus_Restrict)?.AllowedUrls;
                // if (AllowedUrls && currentRoute && AllowedUrls.includes(currentRoute)) {
                //     return true;
                // }  
                return true;
            }
            else {
                return true;
            }
        }
        catch (error) {
            this.View.navigate(['/']); // error so route to homepage 
            return false;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AuthGuard, deps: [{ token: IndexedDBService }, { token: i1.Router }, { token: i1.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AuthGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AuthGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: IndexedDBService }, { type: i1.Router }, { type: i1.ActivatedRoute }]; } });

class AccessRestrictOverlayService {
    constructor() {
        this.isVisibleSubject = new BehaviorSubject(false);
        this.isVisible$ = this.isVisibleSubject.asObservable();
        this.ControllerSubject = new BehaviorSubject({ Title: 'Access Restricted', Message: 'You do not have access to this page', ButtonTitle: 'Request Access', ButtonAction: '' });
        this.Controller$ = this.ControllerSubject.asObservable();
    }
    updateController(controller) {
        this.ControllerSubject.next(controller);
    }
    showOverlay() {
        this.isVisibleSubject.next(true);
    }
    hideOverlay() {
        this.isVisibleSubject.next(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AccessRestrictOverlayService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AccessRestrictOverlayService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AccessRestrictOverlayService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class AccessRestrictComponent {
    constructor(overlayService) {
        this.overlayService = overlayService;
        this.isVisible = this.overlayService.isVisible$;
        this.Controller = this.overlayService.Controller$;
    }
    ngOnInit() {
        // Subscribe to Restriction Controller
        this.Controller.subscribe(controller => {
            this.title = controller.Title;
            this.message = controller.Message;
            this.buttonTitle = controller.ButtonTitle;
            this.buttonAction = controller.ButtonAction;
        });
    }
    Close() {
        this.overlayService.hideOverlay();
    }
    GoToURL() {
        window.location.href = "/" + this.buttonAction;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AccessRestrictComponent, deps: [{ token: AccessRestrictOverlayService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: AccessRestrictComponent, selector: "access-restrict", ngImport: i0, template: "<div class=\"overlay\" *ngIf=\"isVisible | async\">\n    <div class=\"content\">\n      <button class=\"close\" (click)=\"Close()\">\u00D7</button>\n      <h1>{{title}}</h1>\n      <p>{{message}}</p>\n      <button (click)=\"GoToURL()\">{{buttonTitle}}</button>\n    </div>\n  </div>", styles: [".overlay{position:fixed;top:0;left:0;width:100%;height:100%;background-color:#000000b3;-webkit-backdrop-filter:blur(5px);backdrop-filter:blur(5px);display:flex;justify-content:center;align-items:center;z-index:1000}.content{width:90%;height:-moz-fit-content;height:fit-content;max-height:90%;background-color:#fff;padding:20px;box-shadow:0 4px 8px #0003;overflow:auto}h1{margin-top:0}p{font-size:1.2em}button{padding:10px 20px;font-size:1em;cursor:pointer}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i3.AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AccessRestrictComponent, decorators: [{
            type: Component,
            args: [{ selector: 'access-restrict', template: "<div class=\"overlay\" *ngIf=\"isVisible | async\">\n    <div class=\"content\">\n      <button class=\"close\" (click)=\"Close()\">\u00D7</button>\n      <h1>{{title}}</h1>\n      <p>{{message}}</p>\n      <button (click)=\"GoToURL()\">{{buttonTitle}}</button>\n    </div>\n  </div>", styles: [".overlay{position:fixed;top:0;left:0;width:100%;height:100%;background-color:#000000b3;-webkit-backdrop-filter:blur(5px);backdrop-filter:blur(5px);display:flex;justify-content:center;align-items:center;z-index:1000}.content{width:90%;height:-moz-fit-content;height:fit-content;max-height:90%;background-color:#fff;padding:20px;box-shadow:0 4px 8px #0003;overflow:auto}h1{margin-top:0}p{font-size:1.2em}button{padding:10px 20px;font-size:1em;cursor:pointer}\n"] }]
        }], ctorParameters: function () { return [{ type: AccessRestrictOverlayService }]; } });

class ClickmapComponent {
    constructor() {
        //@Input() Image: string = this.Globals.getMainLogoImage();
        this.ItemMap = [
            { Title: 'test1', Complete: false },
            { Title: 'test2', Complete: true },
            { Title: 'test3', Complete: true },
            { Title: 'test4', Complete: false },
            { Title: 'test5', Complete: true },
            { Title: 'test6', Complete: true },
            { Title: 'test7', Complete: true },
            { Title: 'test8', Complete: false },
            { Title: 'test9', Complete: true },
            { Title: 'test10', Complete: false },
        ];
        this.ActiveItem = 2;
        this.CheckmarkOutline = checkmarkOutline;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ClickmapComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ClickmapComponent, selector: "app-clickmap", inputs: { ItemMap: "ItemMap", ActiveItem: "ActiveItem" }, ngImport: i0, template: "<div class=\"ClickMapHolder\">\n    <div *ngFor=\"let Item of ItemMap; let i = index;\" class=\"InnerHolder\">\n\n        <!-- <img class=\"icon\" [ngClass]=\"{\n                'grey': i !== ActiveItem ,\n                'completed': Item.Complete === true,\n                'active': i === ActiveItem,\n            }\"  [src]=\"Image\" style=\"width: 2rem; height: 2rem; position: absolute;\"/> -->\n        <div [ngClass]=\"{\n            'grey': i !== ActiveItem ,\n            'completed': Item.Complete === true,\n            'active': i === ActiveItem,\n        }\">\n\n            <ion-icon [icon]=\"CheckmarkOutline\" class=\"icon\"></ion-icon>\n\n\n            <!-- <p>{{ Item.Title }}</p> -->\n            <p>\n                {{i + 1}}\n            </p>\n        </div>\n        <hr [style]=\"'margin-left: ' + (100/ItemMap.length) + 'px; height: 0.2rem;'\"\n        *ngIf=\"i < ItemMap.length - 1\">\n        <!-- <hr [style]=\"'width:' + (50/ItemMap.length) + 'px; margin-left: ' + (100/ItemMap.length) + 'px; height: 0.2rem;'\"\n            *ngIf=\"i < ItemMap.length - 1\"> -->\n    </div>\n\n</div>", styles: ["hr{height:.5rem;margin:auto}.ClickMapHolder{display:flex;justify-content:space-evenly;flex-wrap:wrap}.ClickMapHolder p{margin:auto}.InnerHolder{display:flex}.grey{filter:grayscale(100%);opacity:.5}.active{filter:grayscale(100%);animation:identifier 2s ease-in-out infinite}@keyframes identifier{0%{transform:scale(1.5)}50%{transform:scale(1.1)}to{transform:scale(1.5)}}.completed{filter:none!important}.icon{width:2rem;color:var(--Color);border-radius:100%;position:absolute}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ClickmapComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-clickmap', template: "<div class=\"ClickMapHolder\">\n    <div *ngFor=\"let Item of ItemMap; let i = index;\" class=\"InnerHolder\">\n\n        <!-- <img class=\"icon\" [ngClass]=\"{\n                'grey': i !== ActiveItem ,\n                'completed': Item.Complete === true,\n                'active': i === ActiveItem,\n            }\"  [src]=\"Image\" style=\"width: 2rem; height: 2rem; position: absolute;\"/> -->\n        <div [ngClass]=\"{\n            'grey': i !== ActiveItem ,\n            'completed': Item.Complete === true,\n            'active': i === ActiveItem,\n        }\">\n\n            <ion-icon [icon]=\"CheckmarkOutline\" class=\"icon\"></ion-icon>\n\n\n            <!-- <p>{{ Item.Title }}</p> -->\n            <p>\n                {{i + 1}}\n            </p>\n        </div>\n        <hr [style]=\"'margin-left: ' + (100/ItemMap.length) + 'px; height: 0.2rem;'\"\n        *ngIf=\"i < ItemMap.length - 1\">\n        <!-- <hr [style]=\"'width:' + (50/ItemMap.length) + 'px; margin-left: ' + (100/ItemMap.length) + 'px; height: 0.2rem;'\"\n            *ngIf=\"i < ItemMap.length - 1\"> -->\n    </div>\n\n</div>", styles: ["hr{height:.5rem;margin:auto}.ClickMapHolder{display:flex;justify-content:space-evenly;flex-wrap:wrap}.ClickMapHolder p{margin:auto}.InnerHolder{display:flex}.grey{filter:grayscale(100%);opacity:.5}.active{filter:grayscale(100%);animation:identifier 2s ease-in-out infinite}@keyframes identifier{0%{transform:scale(1.5)}50%{transform:scale(1.1)}to{transform:scale(1.5)}}.completed{filter:none!important}.icon{width:2rem;color:var(--Color);border-radius:100%;position:absolute}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { ItemMap: [{
                type: Input
            }], ActiveItem: [{
                type: Input
            }] } });

class ClockComponent {
    constructor() {
        this.clock = new Date();
        this.useLongLabels = false; // New input for label format
        this.days = 0;
        this.hours = 0;
        this.minutes = 0;
        this.seconds = 0;
    }
    ngOnInit() {
        this.startTimer();
    }
    ngOnDestroy() {
        this.clearTimer();
    }
    startTimer() {
        const endDate = new Date(this.clock);
        // If duration is provided, add it to the end date
        if (this.duration) {
            endDate.setDate(endDate.getDate() + this.duration);
        }
        this.timer = setInterval(() => {
            const now = new Date();
            const difference = endDate.getTime() - now.getTime();
            if (difference > 0) {
                this.days = Math.floor(difference / (1000 * 60 * 60 * 24));
                this.hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                this.minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
                this.seconds = Math.floor((difference % (1000 * 60)) / 1000);
            }
            else {
                this.clearTimer();
            }
        }, 1000);
    }
    clearTimer() {
        if (this.timer) {
            clearInterval(this.timer);
        }
    }
    getDayLabel() {
        return this.days === 1 ? 'Day' : 'Days';
    }
    getHourLabel() {
        return this.hours === 1 ? 'Hour' : 'Hours';
    }
    getMinuteLabel() {
        return this.minutes === 1 ? 'Minute' : 'Minutes';
    }
    getSecondLabel() {
        return this.seconds === 1 ? 'Second' : 'Seconds';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ClockComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ClockComponent, selector: "app-clock", inputs: { clock: "clock", duration: "duration", clockContainerStyle: "clockContainerStyle", timerStyle: "timerStyle", timeUnitStyle: "timeUnitStyle", valueStyle: "valueStyle", labelStyle: "labelStyle", useLongLabels: "useLongLabels" }, ngImport: i0, template: "<div class=\"countdown-clock\" [ngStyle]=\"clockContainerStyle\">\n  <div class=\"timer\" [ngStyle]=\"timerStyle\">\n    <div class=\"time-unit\" [ngStyle]=\"timeUnitStyle\">\n      <p class=\"value\" [ngStyle]=\"valueStyle\">{{ days }}</p>\n      <span class=\"label\" [ngStyle]=\"labelStyle\">\n        {{ useLongLabels ? getDayLabel() : 'D' }}\n      </span>\n    </div>\n    <div class=\"time-unit\" [ngStyle]=\"timeUnitStyle\">\n      <p class=\"value\" [ngStyle]=\"valueStyle\">{{ hours | number:'2.0-0' }}</p>\n      <span class=\"label\" [ngStyle]=\"labelStyle\">\n        {{ useLongLabels ? getHourLabel() : 'H' }}\n      </span>\n    </div>\n    <div class=\"time-unit\" [ngStyle]=\"timeUnitStyle\">\n      <p class=\"value\" [ngStyle]=\"valueStyle\">{{ minutes | number:'2.0-0' }}</p>\n      <span class=\"label\" [ngStyle]=\"labelStyle\">\n        {{ useLongLabels ? getMinuteLabel() : 'M' }}\n      </span>\n    </div>\n    <div class=\"time-unit\" [ngStyle]=\"timeUnitStyle\">\n      <p class=\"value\" [ngStyle]=\"valueStyle\">{{ seconds | number:'2.0-0' }}</p>\n      <span class=\"label\" [ngStyle]=\"labelStyle\">\n        {{ useLongLabels ? getSecondLabel() : 'S' }}\n      </span>\n    </div>\n  </div>\n</div>", styles: [".timer{display:flex;justify-content:center;flex-wrap:wrap}.time-unit{margin-right:.3em}.time-unit span{font-size:.8em}.ClockTitle,.value{font-size:1em}\n"], dependencies: [{ kind: "directive", type: i3.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "pipe", type: i3.DecimalPipe, name: "number" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ClockComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-clock', template: "<div class=\"countdown-clock\" [ngStyle]=\"clockContainerStyle\">\n  <div class=\"timer\" [ngStyle]=\"timerStyle\">\n    <div class=\"time-unit\" [ngStyle]=\"timeUnitStyle\">\n      <p class=\"value\" [ngStyle]=\"valueStyle\">{{ days }}</p>\n      <span class=\"label\" [ngStyle]=\"labelStyle\">\n        {{ useLongLabels ? getDayLabel() : 'D' }}\n      </span>\n    </div>\n    <div class=\"time-unit\" [ngStyle]=\"timeUnitStyle\">\n      <p class=\"value\" [ngStyle]=\"valueStyle\">{{ hours | number:'2.0-0' }}</p>\n      <span class=\"label\" [ngStyle]=\"labelStyle\">\n        {{ useLongLabels ? getHourLabel() : 'H' }}\n      </span>\n    </div>\n    <div class=\"time-unit\" [ngStyle]=\"timeUnitStyle\">\n      <p class=\"value\" [ngStyle]=\"valueStyle\">{{ minutes | number:'2.0-0' }}</p>\n      <span class=\"label\" [ngStyle]=\"labelStyle\">\n        {{ useLongLabels ? getMinuteLabel() : 'M' }}\n      </span>\n    </div>\n    <div class=\"time-unit\" [ngStyle]=\"timeUnitStyle\">\n      <p class=\"value\" [ngStyle]=\"valueStyle\">{{ seconds | number:'2.0-0' }}</p>\n      <span class=\"label\" [ngStyle]=\"labelStyle\">\n        {{ useLongLabels ? getSecondLabel() : 'S' }}\n      </span>\n    </div>\n  </div>\n</div>", styles: [".timer{display:flex;justify-content:center;flex-wrap:wrap}.time-unit{margin-right:.3em}.time-unit span{font-size:.8em}.ClockTitle,.value{font-size:1em}\n"] }]
        }], propDecorators: { clock: [{
                type: Input
            }], duration: [{
                type: Input
            }], clockContainerStyle: [{
                type: Input
            }], timerStyle: [{
                type: Input
            }], timeUnitStyle: [{
                type: Input
            }], valueStyle: [{
                type: Input
            }], labelStyle: [{
                type: Input
            }], useLongLabels: [{
                type: Input
            }] } });

class CountdownpageComponent {
    constructor() {
        this.targetDate = new Date('2024-11-30T23:59:59');
        this.Title = 'Countdown has begun!';
        this.Description = 'Time is running out!';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CountdownpageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: CountdownpageComponent, selector: "app-countdownpage", inputs: { targetDate: "targetDate", Title: "Title", Description: "Description" }, ngImport: i0, template: "<div class=\"section\" style=\"text-align:center;\">\n    <h1>\n        {{Title}} \n    </h1>\n    <br />\n    <app-clock [clock]=\"targetDate\"\n        [timerStyle]=\"{ 'display': 'flex', 'justify-content': 'center' }\" \n        [timeUnitStyle]=\"{ 'margin': '0 2px', 'width': '75px', 'background': '#00000021', 'padding': '0.5em', 'border-bottom': '2px solid white' }\"\n        [valueStyle]=\"{ 'font-size': '2em', 'color': 'var(--color)' }\"\n        [labelStyle]=\"{ 'font-size': '1em', 'color': '#6f6f6f' }\"\n        [useLongLabels]=\"true\"\n    >\n    </app-clock>\n    <br />\n    <br />\n    <p>\n        {{Description}}\n    </p>\n</div>", styles: [""], dependencies: [{ kind: "component", type: ClockComponent, selector: "app-clock", inputs: ["clock", "duration", "clockContainerStyle", "timerStyle", "timeUnitStyle", "valueStyle", "labelStyle", "useLongLabels"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: CountdownpageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-countdownpage', template: "<div class=\"section\" style=\"text-align:center;\">\n    <h1>\n        {{Title}} \n    </h1>\n    <br />\n    <app-clock [clock]=\"targetDate\"\n        [timerStyle]=\"{ 'display': 'flex', 'justify-content': 'center' }\" \n        [timeUnitStyle]=\"{ 'margin': '0 2px', 'width': '75px', 'background': '#00000021', 'padding': '0.5em', 'border-bottom': '2px solid white' }\"\n        [valueStyle]=\"{ 'font-size': '2em', 'color': 'var(--color)' }\"\n        [labelStyle]=\"{ 'font-size': '1em', 'color': '#6f6f6f' }\"\n        [useLongLabels]=\"true\"\n    >\n    </app-clock>\n    <br />\n    <br />\n    <p>\n        {{Description}}\n    </p>\n</div>" }]
        }], propDecorators: { targetDate: [{
                type: Input
            }], Title: [{
                type: Input
            }], Description: [{
                type: Input
            }] } });

class ErrorComponent {
    constructor(errorService, router) {
        this.errorService = errorService;
        this.router = router;
        this.ErrorData = null;
        this.showError = false;
        this.animationState = 'hidden';
    }
    ngOnInit() {
        this.errorService.error$.subscribe((error) => {
            const currentRoute = this.router.url;
            if (error && error.Message) {
                this.showError = true;
                this.ErrorData = error;
                this.animationState = 'in';
                const timeoutDuration = this.calculateTimeoutDuration(error.Message);
                window.scrollTo(0, 0);
                setTimeout(() => {
                    this.animationState = 'hidden';
                    setTimeout(() => {
                        this.showError = false;
                    }, 300); // Match the animation duration
                    this.errorService.clearError();
                }, timeoutDuration);
            }
        });
    }
    calculateTimeoutDuration(message) {
        const baseDuration = 1000; // Base duration in milliseconds (1 second)
        const additionalDuration = Math.ceil(message.length / 10) * 1000; // Additional duration based on message length
        return baseDuration + additionalDuration;
    }
    closeError() {
        this.animationState = 'hidden';
        setTimeout(() => {
            this.showError = false;
            this.errorService.clearError();
        }, 300); // Match the animation duration
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ErrorComponent, deps: [{ token: ErrorHandlingService }, { token: i1.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ErrorComponent, selector: "error", inputs: { ErrorData: "ErrorData" }, ngImport: i0, template: "<div class=\"error-container\">\n  <div *ngIf=\"showError\">\n    <div *ngIf=\"ErrorData\" class=\"error-message\" @slideInOut [@slideInOut]=\"animationState\"\n      [ngClass]=\"{'error-success': ErrorData.Success, 'error-errorred': !ErrorData.Success}\">\n      <span class=\"error-text\">{{ErrorData.Message}}</span>\n      <span class=\"close-button\" (click)=\"closeError()\">X</span>\n    </div>\n  </div>\n</div>\n", styles: [".error-container{height:1rem;width:100%}.error-message{z-index:2;padding:.25rem;position:relative;top:0;width:100%;display:flex;justify-content:space-between;align-items:center;color:#fff}.close-button{cursor:pointer;margin-left:1rem;font-weight:700;color:#000;position:absolute;right:0;padding-right:10px}.error-text{font-size:1.2rem;margin-left:.25rem}.error-success{background:linear-gradient(90deg,#3eae03e8,#00ff00b8)}.error-errorred{background:#b30202b8}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], animations: [
            trigger('slideInOut', [
                state('in', style({ transform: 'translateX(0)', opacity: 1 })),
                state('hidden', style({ transform: 'translateX(100%)', opacity: 0 })),
                transition(':enter', [
                    style({ transform: 'translateX(-100%)', opacity: 0 }),
                    animate('100ms ease-in', style({ transform: 'translateX(50%)', opacity: 1 })),
                    animate('200ms ease-out', style({ transform: 'translateX(0)' }))
                ]),
                transition('in => hidden', [
                    animate('300ms ease-out', style({ transform: 'translateX(100%)', opacity: 0 }))
                ])
            ])
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ErrorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'error', animations: [
                        trigger('slideInOut', [
                            state('in', style({ transform: 'translateX(0)', opacity: 1 })),
                            state('hidden', style({ transform: 'translateX(100%)', opacity: 0 })),
                            transition(':enter', [
                                style({ transform: 'translateX(-100%)', opacity: 0 }),
                                animate('100ms ease-in', style({ transform: 'translateX(50%)', opacity: 1 })),
                                animate('200ms ease-out', style({ transform: 'translateX(0)' }))
                            ]),
                            transition('in => hidden', [
                                animate('300ms ease-out', style({ transform: 'translateX(100%)', opacity: 0 }))
                            ])
                        ])
                    ], template: "<div class=\"error-container\">\n  <div *ngIf=\"showError\">\n    <div *ngIf=\"ErrorData\" class=\"error-message\" @slideInOut [@slideInOut]=\"animationState\"\n      [ngClass]=\"{'error-success': ErrorData.Success, 'error-errorred': !ErrorData.Success}\">\n      <span class=\"error-text\">{{ErrorData.Message}}</span>\n      <span class=\"close-button\" (click)=\"closeError()\">X</span>\n    </div>\n  </div>\n</div>\n", styles: [".error-container{height:1rem;width:100%}.error-message{z-index:2;padding:.25rem;position:relative;top:0;width:100%;display:flex;justify-content:space-between;align-items:center;color:#fff}.close-button{cursor:pointer;margin-left:1rem;font-weight:700;color:#000;position:absolute;right:0;padding-right:10px}.error-text{font-size:1.2rem;margin-left:.25rem}.error-success{background:linear-gradient(90deg,#3eae03e8,#00ff00b8)}.error-errorred{background:#b30202b8}\n"] }]
        }], ctorParameters: function () { return [{ type: ErrorHandlingService }, { type: i1.Router }]; }, propDecorators: { ErrorData: [{
                type: Input
            }] } });

class FooterComponent {
    constructor(View, router, userService) {
        this.View = View;
        this.router = router;
        this.userService = userService;
        this.Show = true; // to hide or show the entire element
        // icons //////////////////////
        this.home = home;
        this.meet = peopleOutline;
        this.guide = informationCircleOutline;
        this.settings = settingsOutline;
        this.chat = chatbubblesOutline;
        this.buttons = [
            {
                "icon": this.meet,
                "label": "Connect",
                "route": "/match",
                "active": false
            },
            {
                "icon": this.guide,
                "label": "Guide",
                "route": "/guide",
                "active": false
            },
            {
                "icon": this.chat,
                "label": "Messages",
                "route": "/messages",
                "active": false
            }
        ];
    }
    ngOnInit() {
        this.userService.isLoggedIn().then(isLoggedIn => {
            this.isLoggedIn = isLoggedIn;
            if (this.isLoggedIn) {
                /*
                  REMOVED for now - gave trouble loading footer - too slow
                */
                // this.userSubscription = this.userService.USERDATA$.subscribe(
                //   (userData) => {
                //     let SettingCheck = userData ? userData.CONFIG : null;
                //     //this.buttons = userData.SETTINGS.UserNav_Footer;
                //     // Set the initial active button based on the current route
                //     this.updateActiveButton(this.router.url.toLowerCase());
                //   }
                // );
            }
        });
        // this.userSubscription = this.userService.USERDATA$.subscribe(
        //   (userData) => {
        //     if (userData && userData.SETTINGS) {
        //       this.buttons = [...userData.SETTINGS.UserNav_Footer]; // Create a new array reference
        //       this.updateActiveButton(this.router.url.toLowerCase());
        //     }
        //   }
        // );
        this.routerSubscription = this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe((event) => {
            const navEndEvent = event;
            this.userService.isLoggedIn().then(isLoggedIn => {
                this.isLoggedIn = isLoggedIn;
                this.updateActiveButton(navEndEvent.urlAfterRedirects.toLowerCase());
            });
        });
    }
    ngOnDestroy() {
        // Unsubscribe to prevent memory leaks
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
        if (this.routerSubscription) {
            this.routerSubscription.unsubscribe();
        }
    }
    // Method to handle routing
    route(destination) {
        this.updateActiveButton(destination.toLowerCase());
        this.router.navigate(['/' + destination]);
    }
    updateActiveButton(destination) {
        this.buttons = this.buttons.map(button => ({
            ...button,
            active: button.route === destination
        }));
    }
    trackByFunction(index, button) {
        return button.route;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FooterComponent, deps: [{ token: i1.Router }, { token: i1.Router }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FooterComponent, selector: "hub-footer", inputs: { Show: "Show", buttons: "buttons" }, ngImport: i0, template: "<div *ngIf=\"Show\">\n  <div class=\"FootSpacer\">\n\n  </div>\n  <div *ngIf=\"isLoggedIn; else publicFooter\">\n    <!-- <ion-footer class=\"Foot_\">\n      <ion-toolbar>\n        <ion-grid> -->\n          <ion-row *ngIf=\"buttons\" class=\"Foot_\" style=\"text-align: center;\">\n            <ion-col *ngFor=\"let button of buttons; trackBy: trackByFunction\" size=\"4\" [ngClass]=\"{'active-button': button.active}\">\n              <ion-button fill=\"clear\" (click)=\"route(button.route)\">\n                <!-- <ion-icon [icon]=\"button.icon\"></ion-icon> -->\n                <ion-label>{{ button.label }}</ion-label>\n              </ion-button>\n            </ion-col>\n          </ion-row>\n        <!-- </ion-grid>\n      </ion-toolbar>\n    </ion-footer> -->\n  </div>\n  <ng-template #publicFooter>\n    <div>\n      <div class=\"Footer_Inner\">\n        <div style=\"padding: 0.5rem; text-align: center;\">\n          <logo-box [styling]=\"'width: 40px; margin: auto;'\" [TagOn]=\"true\"></logo-box>\n        </div>\n      </div>\n    </div>\n  </ng-template>\n</div>", styles: [".Foot_{position:fixed;border-radius:15px 15px 0 0;bottom:0;left:0;height:var(--FootHeight);width:100%;z-index:1;background-color:#fff;padding:0;margin:0;box-sizing:border-box;box-shadow:0 -2px 10px #0000001a}.FootSpacer{height:var(--FootHeight);width:100%}ion-col.active-button{background:var(--Color3)}.content-area{padding-bottom:calc(var(--FootHeight) + 60px);z-index:5;position:relative}.Footer_Inner{background-color:#fff;position:fixed;bottom:0;left:0;text-align:center;width:100%;padding:.5rem;z-index:10;margin:0;box-shadow:0 -2px 10px #0000001a;box-sizing:border-box}ion-footer{width:100%;background-color:#fff;box-shadow:0 -2px 10px #0000001a;margin:0;padding:0;box-sizing:border-box}ion-toolbar{--background: white;--border-width: 0}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.IonButton, selector: "ion-button", inputs: ["buttonType", "color", "disabled", "download", "expand", "fill", "form", "href", "mode", "rel", "routerAnimation", "routerDirection", "shape", "size", "strong", "target", "type"] }, { kind: "component", type: i4.IonCol, selector: "ion-col", inputs: ["offset", "offsetLg", "offsetMd", "offsetSm", "offsetXl", "offsetXs", "pull", "pullLg", "pullMd", "pullSm", "pullXl", "pullXs", "push", "pushLg", "pushMd", "pushSm", "pushXl", "pushXs", "size", "sizeLg", "sizeMd", "sizeSm", "sizeXl", "sizeXs"] }, { kind: "component", type: i4.IonLabel, selector: "ion-label", inputs: ["color", "mode", "position"] }, { kind: "component", type: i4.IonRow, selector: "ion-row" }, { kind: "component", type: LogoBoxComponent, selector: "logo-box", inputs: ["styling", "Boxstyling", "AltText", "Logo", "TagOn"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hub-footer', template: "<div *ngIf=\"Show\">\n  <div class=\"FootSpacer\">\n\n  </div>\n  <div *ngIf=\"isLoggedIn; else publicFooter\">\n    <!-- <ion-footer class=\"Foot_\">\n      <ion-toolbar>\n        <ion-grid> -->\n          <ion-row *ngIf=\"buttons\" class=\"Foot_\" style=\"text-align: center;\">\n            <ion-col *ngFor=\"let button of buttons; trackBy: trackByFunction\" size=\"4\" [ngClass]=\"{'active-button': button.active}\">\n              <ion-button fill=\"clear\" (click)=\"route(button.route)\">\n                <!-- <ion-icon [icon]=\"button.icon\"></ion-icon> -->\n                <ion-label>{{ button.label }}</ion-label>\n              </ion-button>\n            </ion-col>\n          </ion-row>\n        <!-- </ion-grid>\n      </ion-toolbar>\n    </ion-footer> -->\n  </div>\n  <ng-template #publicFooter>\n    <div>\n      <div class=\"Footer_Inner\">\n        <div style=\"padding: 0.5rem; text-align: center;\">\n          <logo-box [styling]=\"'width: 40px; margin: auto;'\" [TagOn]=\"true\"></logo-box>\n        </div>\n      </div>\n    </div>\n  </ng-template>\n</div>", styles: [".Foot_{position:fixed;border-radius:15px 15px 0 0;bottom:0;left:0;height:var(--FootHeight);width:100%;z-index:1;background-color:#fff;padding:0;margin:0;box-sizing:border-box;box-shadow:0 -2px 10px #0000001a}.FootSpacer{height:var(--FootHeight);width:100%}ion-col.active-button{background:var(--Color3)}.content-area{padding-bottom:calc(var(--FootHeight) + 60px);z-index:5;position:relative}.Footer_Inner{background-color:#fff;position:fixed;bottom:0;left:0;text-align:center;width:100%;padding:.5rem;z-index:10;margin:0;box-shadow:0 -2px 10px #0000001a;box-sizing:border-box}ion-footer{width:100%;background-color:#fff;box-shadow:0 -2px 10px #0000001a;margin:0;padding:0;box-sizing:border-box}ion-toolbar{--background: white;--border-width: 0}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.Router }, { type: i1.Router }, { type: IndexedDBService }]; }, propDecorators: { Show: [{
                type: Input
            }], buttons: [{
                type: Input
            }] } });

class FormSubButtonComponent {
    constructor() {
        this.ButtonTitle = 'Save';
        this.buttonClicked = new EventEmitter();
    }
    onButtonClick() {
        this.buttonClicked.emit();
        // console.log('Button Clicked');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormSubButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FormSubButtonComponent, selector: "formSubButton", inputs: { ButtonTitle: "ButtonTitle" }, outputs: { buttonClicked: "buttonClicked" }, ngImport: i0, template: "<div class=\"StickBut\" (click)=\"onButtonClick()\">\n    {{ButtonTitle}}\n</div>", styles: [".StickBut{width:100%;color:var(--Color);padding:1rem;text-align:center;cursor:pointer}.StickBut:hover{color:var(--Color2)}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FormSubButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'formSubButton', template: "<div class=\"StickBut\" (click)=\"onButtonClick()\">\n    {{ButtonTitle}}\n</div>", styles: [".StickBut{width:100%;color:var(--Color);padding:1rem;text-align:center;cursor:pointer}.StickBut:hover{color:var(--Color2)}\n"] }]
        }], propDecorators: { ButtonTitle: [{
                type: Input
            }], buttonClicked: [{
                type: Output
            }] } });

class LoginButtonComponent {
    constructor(router, indexedDBService) {
        this.router = router;
        this.indexedDBService = indexedDBService;
        //routing
        this.view = lRouteKey;
        this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(() => {
            this.indexedDBService.isLoggedIn().then(isLoggedIn => {
                this.isLoggedIn = isLoggedIn;
            });
        });
    }
    logIn() {
        this.router.navigate(['/' + this.view.login]);
    }
    settings() {
        this.router.navigate(['/' + this.view.login]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoginButtonComponent, deps: [{ token: i1.Router }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LoginButtonComponent, selector: "login-button", ngImport: i0, template: "\n<a *ngIf=\"!isLoggedIn\" (click)=\"logIn()\"><button class=\"button button2\">Login/Sign Up</button></a>\n\n<a *ngIf=\"isLoggedIn\" (click)=\"settings()\"><button class=\"button button2\">My Account</button></a> ", styles: [""], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoginButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'login-button', template: "\n<a *ngIf=\"!isLoggedIn\" (click)=\"logIn()\"><button class=\"button button2\">Login/Sign Up</button></a>\n\n<a *ngIf=\"isLoggedIn\" (click)=\"settings()\"><button class=\"button button2\">My Account</button></a> " }]
        }], ctorParameters: function () { return [{ type: i1.Router }, { type: IndexedDBService }]; } });

class HeaderComponent {
    constructor(router, userService, renderer) {
        this.router = router;
        this.userService = userService;
        this.renderer = renderer;
        this.ignoreClickOutside = false; // Flag to ignore clicks outside temporarily
        this.Show = true; // to hide or show the entire element 
        this.UserName = null;
        this.appsOutline = appsOutline; // ion icons
        //for routing
        this.login = lRouteKey;
        this.setting = sRouteKey;
        this.userService.isLoggedIn().then(isLoggedIn => {
            this.isLoggedIn = isLoggedIn;
        });
    }
    ngOnInit() {
        this.userSubscription = this.userService.USERDATA$.subscribe((userData) => {
            this.User = userData;
            let SettingCheck = userData ? userData.SETTINGS : null;
            if (SettingCheck) {
                this.logo = userData.CONFIG.LOGO;
                this.title = userData.CONFIG.BUSName;
                let Nav = userData.SETTINGS.UserNav ?? ['', 'Unavailable', ''];
                this.SettingDropdownOptions = this.generateNavigationArray(Nav);
            }
        });
        this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(() => {
            this.userService.isLoggedIn().then(isLoggedIn => {
                this.isLoggedIn = isLoggedIn;
            });
        });
        // Add event listener for clicks outside the dropdown menu
        this.renderer.listen('document', 'click', this.handleClickOutside.bind(this));
    }
    ngOnDestroy() {
        // Unsubscribe to prevent memory leaks
        if (this.userSubscription) {
            this.userSubscription.unsubscribe();
        }
    }
    toggleDropdown() {
        const dropdownMenu = document.getElementById('dropdownMenu');
        if (dropdownMenu) {
            dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
            this.ignoreClickOutside = true; // Ignore the next click outside
            setTimeout(() => this.ignoreClickOutside = false, 0); // Reset the flag after the current event loop
        }
    }
    handleClickOutside(event) {
        if (this.ignoreClickOutside) {
            return; // Ignore this click
        }
        const dropdownMenu = document.getElementById('dropdownMenu');
        if (dropdownMenu && dropdownMenu.style.display === 'block' && !dropdownMenu.contains(event.target)) {
            this.toggleDropdown();
        }
    }
    generateNavigationArray(items) {
        return items.map(item => {
            return {
                Icon: item[0],
                Title: item[1],
                func: () => {
                    this.router.navigate([`/${item[2].toLowerCase()}`]);
                    this.toggleDropdown();
                }
            };
        });
    }
    // Links ///////////////////////////////////////////////////////////
    home() {
        this.router.navigate(['/']);
    }
    Login_() {
        this.router.navigate(['/' + this.login.login]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HeaderComponent, deps: [{ token: i1.Router }, { token: IndexedDBService }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: HeaderComponent, selector: "hub-header", inputs: { Show: "Show" }, ngImport: i0, template: "<!-- Header_UnderLay -->\n<div class=\"\" *ngIf=\"Show\">\n    <div class=\"Header\">\n        <div class=\"Header__logo\" (click)=\"home()\">\n            <!-- <img style=\"border-radius: 0.5rem;\" src=\"{{logo}}\" alt=\"Logo\" /> -->\n            <logo-box [styling]=\"'width: auto; max-height: 35px;'\"></logo-box>\n            <h4 style=\"margin: auto;\">\n                {{title}}\n            </h4>\n        </div>\n\n        <div class=\"Header__user\" *ngIf=\"isLoggedIn; else PublicHeader;\">\n            <div style=\"display: flex;\">\n                <!-- <app-clock *ngIf=\"(User.verified && User.verified_dur); else getverified;\" (click)=\"verified_()\"\n                    [clock]=\"User.verified\" [duration]=\"User.verified_dur\" style=\"margin: auto;\"></app-clock> -->\n                <ng-template #getverified>\n                    <!-- <div style=\"color: white; margin: auto; margin-left: 0.5rem; cursor: pointer; width: 50px;\"\n                        (click)=\"verified_()\">\n                        <verified-icon [Verified]=\"User.Verified\"></verified-icon>\n                    </div> -->\n                </ng-template>\n\n                <div class=\"Header__user__avatar\">\n                    <profilePhoto [AllowGoToProfile]=\"true\" [Type]=\"'view'\" [style]=\"{'width': '2.5rem', 'height': '100%', 'border-radius': '100%'}\">\n                    </profilePhoto>\n                </div>\n                <div style=\"color: var(--Color); margin: auto 0.75rem; margin-top: 0.25em; cursor: pointer;\"\n                    (click)=\"toggleDropdown()\">\n                    <ion-icon [icon]=\"appsOutline\" slot=\"end\" style=\"font-size: 1.5rem;\"></ion-icon>\n                </div>\n\n                <div id=\"dropdownMenu\" class=\"dropdown-menu\">\n                    <div *ngFor=\"let option of SettingDropdownOptions\">\n                        <div class=\"menu-item\" (click)=\"option.func()\">\n                            <ion-icon *ngIf=\"option.Icon\" [name]=\"option.Icon\"></ion-icon>\n                            <a>{{ option.Title }}</a>\n                        </div>\n                    </div>\n                </div>\n\n\n                <!-- <div class=\"Header__user__name\" (click)=\"profile_()\">\n                    <ion-icon [icon]=\"settings\" slot=\"end\"></ion-icon>\n                    <span>{{\" \" + User.firstname + \" \" + User.lastname}} </span>\n                </div> -->\n                <!-- <ion-icon [icon]=\"chat\" style=\"color: white; margin: auto; margin-left: 0.5rem;\" slot=\"end\"\n                    (click)=\"messages_()\"></ion-icon> -->\n            </div>\n        </div>\n        <ng-template #PublicHeader>\n            <login-button style=\"margin: auto 0px; margin-right: 0.25em;\"></login-button>\n        </ng-template>\n    </div>\n</div>", styles: [".Header{display:flex;justify-content:space-between;z-index:1000}.Header_UnderLay{background-image:url(/assets/TextBackground.png);background-size:180px;background-position:center;position:sticky;top:0;z-index:100}.Header__user{margin:auto 5px;color:#fff}.Header__user__name{padding:.5rem;background-color:#fff;color:var(--color);cursor:pointer;border-radius:.5rem}.Header__user__avatar img{width:35px;height:35px;border-radius:50%;margin:auto .5rem}.Header__logo{margin:auto 0;cursor:pointer;display:flex;padding:.5rem}.Header__logo p{margin:auto;margin-left:.5rem;color:#fff}.Header__logo img{width:35px;height:35px}.dropdown-menu{display:none;position:fixed;top:50px;right:10px;background-color:#fff;box-shadow:0 8px 16px #0003;z-index:1000}.menu-item{display:flex;padding:10px 20px;gap:8px;cursor:pointer;text-decoration:none;color:inherit}.menu-item ion-icon{font-size:1.6em}.menu-item a{color:inherit;text-decoration:none}.menu-item:hover{color:#007bff}.TopNav{position:sticky;top:0;padding:1rem;display:flex;justify-content:space-between}\n"], dependencies: [{ kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }, { kind: "component", type: LogoBoxComponent, selector: "logo-box", inputs: ["styling", "Boxstyling", "AltText", "Logo", "TagOn"] }, { kind: "component", type: ProfilePhotoComponent, selector: "profilePhoto", inputs: ["Type", "style", "PicUrl", "AllowGoToProfile"] }, { kind: "component", type: LoginButtonComponent, selector: "login-button" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: HeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hub-header', template: "<!-- Header_UnderLay -->\n<div class=\"\" *ngIf=\"Show\">\n    <div class=\"Header\">\n        <div class=\"Header__logo\" (click)=\"home()\">\n            <!-- <img style=\"border-radius: 0.5rem;\" src=\"{{logo}}\" alt=\"Logo\" /> -->\n            <logo-box [styling]=\"'width: auto; max-height: 35px;'\"></logo-box>\n            <h4 style=\"margin: auto;\">\n                {{title}}\n            </h4>\n        </div>\n\n        <div class=\"Header__user\" *ngIf=\"isLoggedIn; else PublicHeader;\">\n            <div style=\"display: flex;\">\n                <!-- <app-clock *ngIf=\"(User.verified && User.verified_dur); else getverified;\" (click)=\"verified_()\"\n                    [clock]=\"User.verified\" [duration]=\"User.verified_dur\" style=\"margin: auto;\"></app-clock> -->\n                <ng-template #getverified>\n                    <!-- <div style=\"color: white; margin: auto; margin-left: 0.5rem; cursor: pointer; width: 50px;\"\n                        (click)=\"verified_()\">\n                        <verified-icon [Verified]=\"User.Verified\"></verified-icon>\n                    </div> -->\n                </ng-template>\n\n                <div class=\"Header__user__avatar\">\n                    <profilePhoto [AllowGoToProfile]=\"true\" [Type]=\"'view'\" [style]=\"{'width': '2.5rem', 'height': '100%', 'border-radius': '100%'}\">\n                    </profilePhoto>\n                </div>\n                <div style=\"color: var(--Color); margin: auto 0.75rem; margin-top: 0.25em; cursor: pointer;\"\n                    (click)=\"toggleDropdown()\">\n                    <ion-icon [icon]=\"appsOutline\" slot=\"end\" style=\"font-size: 1.5rem;\"></ion-icon>\n                </div>\n\n                <div id=\"dropdownMenu\" class=\"dropdown-menu\">\n                    <div *ngFor=\"let option of SettingDropdownOptions\">\n                        <div class=\"menu-item\" (click)=\"option.func()\">\n                            <ion-icon *ngIf=\"option.Icon\" [name]=\"option.Icon\"></ion-icon>\n                            <a>{{ option.Title }}</a>\n                        </div>\n                    </div>\n                </div>\n\n\n                <!-- <div class=\"Header__user__name\" (click)=\"profile_()\">\n                    <ion-icon [icon]=\"settings\" slot=\"end\"></ion-icon>\n                    <span>{{\" \" + User.firstname + \" \" + User.lastname}} </span>\n                </div> -->\n                <!-- <ion-icon [icon]=\"chat\" style=\"color: white; margin: auto; margin-left: 0.5rem;\" slot=\"end\"\n                    (click)=\"messages_()\"></ion-icon> -->\n            </div>\n        </div>\n        <ng-template #PublicHeader>\n            <login-button style=\"margin: auto 0px; margin-right: 0.25em;\"></login-button>\n        </ng-template>\n    </div>\n</div>", styles: [".Header{display:flex;justify-content:space-between;z-index:1000}.Header_UnderLay{background-image:url(/assets/TextBackground.png);background-size:180px;background-position:center;position:sticky;top:0;z-index:100}.Header__user{margin:auto 5px;color:#fff}.Header__user__name{padding:.5rem;background-color:#fff;color:var(--color);cursor:pointer;border-radius:.5rem}.Header__user__avatar img{width:35px;height:35px;border-radius:50%;margin:auto .5rem}.Header__logo{margin:auto 0;cursor:pointer;display:flex;padding:.5rem}.Header__logo p{margin:auto;margin-left:.5rem;color:#fff}.Header__logo img{width:35px;height:35px}.dropdown-menu{display:none;position:fixed;top:50px;right:10px;background-color:#fff;box-shadow:0 8px 16px #0003;z-index:1000}.menu-item{display:flex;padding:10px 20px;gap:8px;cursor:pointer;text-decoration:none;color:inherit}.menu-item ion-icon{font-size:1.6em}.menu-item a{color:inherit;text-decoration:none}.menu-item:hover{color:#007bff}.TopNav{position:sticky;top:0;padding:1rem;display:flex;justify-content:space-between}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.Router }, { type: IndexedDBService }, { type: i0.Renderer2 }]; }, propDecorators: { Show: [{
                type: Input
            }] } });

class ProgbarComponent {
    get percentage() {
        return Math.round((this.current / this.total) * 100);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProgbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ProgbarComponent, selector: "app-progress-bar", inputs: { total: "total", current: "current" }, ngImport: i0, template: "<div class=\"progress\">\n  <div *ngIf=\"percentage !== 0; else zerobar\" class=\"progress-bar\" role=\"progressbar\" [style.width.%]=\"percentage\" aria-valuenow=\"percentage\" aria-valuemin=\"0\"\n    aria-valuemax=\"100\">\n    {{ percentage }}%\n  </div>\n  <ng-template #zerobar>\n    <div class=\"progress-bar\" style=\"background-color: grey;\" role=\"progressbar\" [style.width.%]=\"100\" aria-valuenow=\"percentage\" aria-valuemin=\"0\"\n      aria-valuemax=\"100\">\n      0%\n    </div>\n  </ng-template>\n</div>", styles: [".progress{height:20px;background-color:#f5f5f5;border-radius:4px;box-shadow:inset 0 1px 2px #0000001a}.progress-bar{float:left;width:0%;height:100%;font-size:12px;line-height:20px;color:#fff;text-align:center;background-color:var(--Color2);box-shadow:inset 0 -1px #00000026;transition:width .6s ease}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ProgbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-progress-bar', template: "<div class=\"progress\">\n  <div *ngIf=\"percentage !== 0; else zerobar\" class=\"progress-bar\" role=\"progressbar\" [style.width.%]=\"percentage\" aria-valuenow=\"percentage\" aria-valuemin=\"0\"\n    aria-valuemax=\"100\">\n    {{ percentage }}%\n  </div>\n  <ng-template #zerobar>\n    <div class=\"progress-bar\" style=\"background-color: grey;\" role=\"progressbar\" [style.width.%]=\"100\" aria-valuenow=\"percentage\" aria-valuemin=\"0\"\n      aria-valuemax=\"100\">\n      0%\n    </div>\n  </ng-template>\n</div>", styles: [".progress{height:20px;background-color:#f5f5f5;border-radius:4px;box-shadow:inset 0 1px 2px #0000001a}.progress-bar{float:left;width:0%;height:100%;font-size:12px;line-height:20px;color:#fff;text-align:center;background-color:var(--Color2);box-shadow:inset 0 -1px #00000026;transition:width .6s ease}\n"] }]
        }], propDecorators: { total: [{
                type: Input
            }], current: [{
                type: Input
            }] } });

class ScrollTopComponent {
    constructor() {
        this.isAtTop = true;
        this.arrowDown = arrowDown;
        this.arrowUp = arrowUp;
        this.styleAdjust = '';
    }
    onWindowScroll() {
        this.isAtTop = window.pageYOffset === 0;
    }
    scrollToTopOrBottom() {
        if (this.isAtTop) {
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        }
        else {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ScrollTopComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ScrollTopComponent, selector: "app-scroll-top", inputs: { styleAdjust: "styleAdjust" }, host: { listeners: { "window:scroll": "onWindowScroll()" } }, ngImport: i0, template: "<div [style]=\"styleAdjust\" class=\"basicDesign\" [ngClass]=\"{'scroll-button': !styleAdjust}\"  (click)=\"scrollToTopOrBottom()\">\n  <ion-icon [icon]=\"(!isAtTop ? arrowUp : arrowDown)\"></ion-icon>\n</div>", styles: [".basicDesign{display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background-color .3s;z-index:100000;width:.8rem;height:auto;border-radius:10%;left:unset;position:fixed;right:3.25rem;top:4rem;z-index:10}.basicDesign:hover{background-color:var(--accentColor)}.basicDesign ion-icon{font-size:2.2em}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ScrollTopComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-scroll-top', template: "<div [style]=\"styleAdjust\" class=\"basicDesign\" [ngClass]=\"{'scroll-button': !styleAdjust}\"  (click)=\"scrollToTopOrBottom()\">\n  <ion-icon [icon]=\"(!isAtTop ? arrowUp : arrowDown)\"></ion-icon>\n</div>", styles: [".basicDesign{display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background-color .3s;z-index:100000;width:.8rem;height:auto;border-radius:10%;left:unset;position:fixed;right:3.25rem;top:4rem;z-index:10}.basicDesign:hover{background-color:var(--accentColor)}.basicDesign ion-icon{font-size:2.2em}\n"] }]
        }], propDecorators: { styleAdjust: [{
                type: Input
            }], onWindowScroll: [{
                type: HostListener,
                args: ['window:scroll', []]
            }] } });

class SplashComponent {
    constructor(splashService) {
        this.splashService = splashService;
        this.Image = null; // NOT SETUP FULLY
        this.ImageStylingString = `
    padding-top: 25vh;
    max-width: 350px;
    width: 100%;
    padding-bottom: 25vh;
    animation: rotate 4s infinite;
    height: 100%;
  `;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SplashComponent, deps: [{ token: SplashHandlingService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SplashComponent, selector: "splash-page", inputs: { Image: "Image" }, ngImport: i0, template: "<div [ngClass]=\"{'OverlaySetup': true, 'hidden': !(splashService.splash$ | async)}\">\n    <div class=\"spinner\">\n        <!-- <logo-box *ngIf=\"Image\" [Boxstyling]=\"ImageStylingString\" [Logo]=\"Image\" class=\"img\" [AltText]=\"'Loading...'\"></logo-box> -->\n    </div>\n</div>", styles: [".OverlaySetup{display:flex;justify-content:center;align-items:center;text-align:center;z-index:1000;top:0;left:0;position:fixed;height:100vh;width:100vw;background:#fff}.hidden{animation:hide .5s forwards}@keyframes hide{0%{opacity:1;z-index:0}20%{opacity:0;z-index:0}to{opacity:0;z-index:-10}}.spinner{border:16px solid #f3f3f3;border-top:16px solid var(--Color);border-radius:50%;width:120px;height:120px;animation:spin 2s linear infinite}@keyframes spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}\n"], dependencies: [{ kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: i3.AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SplashComponent, decorators: [{
            type: Component,
            args: [{ selector: 'splash-page', template: "<div [ngClass]=\"{'OverlaySetup': true, 'hidden': !(splashService.splash$ | async)}\">\n    <div class=\"spinner\">\n        <!-- <logo-box *ngIf=\"Image\" [Boxstyling]=\"ImageStylingString\" [Logo]=\"Image\" class=\"img\" [AltText]=\"'Loading...'\"></logo-box> -->\n    </div>\n</div>", styles: [".OverlaySetup{display:flex;justify-content:center;align-items:center;text-align:center;z-index:1000;top:0;left:0;position:fixed;height:100vh;width:100vw;background:#fff}.hidden{animation:hide .5s forwards}@keyframes hide{0%{opacity:1;z-index:0}20%{opacity:0;z-index:0}to{opacity:0;z-index:-10}}.spinner{border:16px solid #f3f3f3;border-top:16px solid var(--Color);border-radius:50%;width:120px;height:120px;animation:spin 2s linear infinite}@keyframes spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}\n"] }]
        }], ctorParameters: function () { return [{ type: SplashHandlingService }]; }, propDecorators: { Image: [{
                type: Input
            }] } });

class VideodisplayService {
    constructor() { }
    // MODIFIES A USER VIDEO AFTER PAGE LOAD // CUSTOM FOR TWO USER PATHWAYS 
    changeUserVideo(videoUrl, attempt = 0) {
        let videoElement = document.getElementById('videoautogen');
        const maxAttempts = 25;
        if (!videoElement && attempt < maxAttempts) {
            setTimeout(() => {
                this.changeUserVideo(videoUrl, attempt + 1); // Retry the function
            }, 1000); // Retry after 1 second
            return;
        }
        if (videoElement) {
            const newSrc = `${videoUrl}?timestamp=${new Date().getTime()}`;
            // Check if the URL contains 'collegerecruit.us'
            if (videoUrl.includes('collegerecruit.us')) {
                // Create a new video element
                const parent = videoElement.parentNode;
                parent.classList.remove('video-container');
                parent.classList.add('video-container2');
                const newVideoElement = document.createElement('video');
                newVideoElement.id = 'videoautogen';
                newVideoElement.setAttribute('controls', 'true');
                newVideoElement.setAttribute('autoplay', 'true');
                newVideoElement.className = 'video_';
                const sourceElement = document.createElement('source');
                sourceElement.src = newSrc;
                sourceElement.type = 'video/mp4';
                newVideoElement.appendChild(sourceElement);
                // Replace the old element with the new video element
                //const parent = videoElement.parentNode;
                if (parent) {
                    parent.replaceChild(newVideoElement, videoElement);
                }
            }
            else {
                // Create a new iframe element
                const newIframeElement = document.createElement('iframe');
                newIframeElement.id = 'videoautogen';
                newIframeElement.setAttribute('frameborder', '0');
                newIframeElement.setAttribute('allow', 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture');
                newIframeElement.setAttribute('allowfullscreen', 'true');
                newIframeElement.className = 'video_';
                newIframeElement.src = newSrc;
                // Replace the old element with the new iframe element
                const parent = videoElement.parentNode;
                if (parent) {
                    parent.replaceChild(newIframeElement, videoElement);
                }
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: VideodisplayService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: VideodisplayService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: VideodisplayService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class ShareprofileService {
    constructor(ErrorHelper, USessionData) {
        this.ErrorHelper = ErrorHelper;
        this.USessionData = USessionData;
        if (!this.User) {
            this.USessionData.USERDATA$.subscribe((data) => {
                this.User = data;
                this.Url = data.CONFIG.URL;
            });
        }
    }
    share_(dis_name = this.User.dis_name) {
        let link = this.Url + '/profile/' + dis_name;
        navigator.clipboard.writeText(link);
        this.ErrorHelper.setError({ Success: true, Message: 'Profile share link copied to clipboard! ' });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShareprofileService, deps: [{ token: ErrorHandlingService }, { token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShareprofileService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShareprofileService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: ErrorHandlingService }, { type: IndexedDBService }]; } });

class ShareprofileComponent {
    constructor(ShareProfile) {
        this.ShareProfile = ShareProfile;
        this.dis_name = null;
        this.Share = shareSocialOutline;
    }
    share_() {
        if (!this.dis_name) {
            this.ShareProfile.share_();
        }
        else {
            this.ShareProfile.share_(this.dis_name);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShareprofileComponent, deps: [{ token: ShareprofileService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ShareprofileComponent, selector: "profile-shareprofile", inputs: { dis_name: "dis_name" }, ngImport: i0, template: "<ion-icon [icon]=\"Share\" (click)=\"share_()\"></ion-icon>", styles: [""], dependencies: [{ kind: "component", type: i4.IonIcon, selector: "ion-icon", inputs: ["color", "flipRtl", "icon", "ios", "lazy", "md", "mode", "name", "sanitize", "size", "src"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ShareprofileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'profile-shareprofile', template: "<ion-icon [icon]=\"Share\" (click)=\"share_()\"></ion-icon>" }]
        }], ctorParameters: function () { return [{ type: ShareprofileService }]; }, propDecorators: { dis_name: [{
                type: Input
            }] } });

class AccountComponent {
    constructor(USessionData) {
        this.USessionData = USessionData;
        this.USessionData.USERDATA$.pipe(take$1(1)).subscribe((userData) => {
            this.User = userData;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AccountComponent, deps: [{ token: IndexedDBService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: AccountComponent, selector: "settings-account", inputs: { User: "User" }, ngImport: i0, template: "<settings-account-form [User]=\"User\"></settings-account-form>\n", styles: [""], dependencies: [{ kind: "component", type: UserFormComponent, selector: "settings-account-form", inputs: ["User"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: AccountComponent, decorators: [{
            type: Component,
            args: [{ selector: 'settings-account', template: "<settings-account-form [User]=\"User\"></settings-account-form>\n" }]
        }], ctorParameters: function () { return [{ type: IndexedDBService }]; }, propDecorators: { User: [{
                type: Input
            }] } });

// Routing ////////////////////////////////////////////////////////////////////////
// import {
//   DynamicRoutingService,
//   AuthGuard
// } from './dynamicRoutingService.service';
class MyLibraryModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: MyLibraryModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: MyLibraryModule, declarations: [
            // CONTACT FORM // IN DEVELOPMENT
            ContactComponent,
            ContactUsComponent,
            // COMPONENTS //////////////
            FourZeroFourComponent,
            AccessRestrictComponent,
            BackgroundComponent,
            ClickmapComponent,
            ClockComponent,
            CountdownpageComponent,
            ErrorComponent,
            FooterComponent,
            FormErrorComponent,
            FormCreatorComponent,
            FormSubButtonComponent,
            HeaderComponent,
            LoadingSpinnerComponent,
            LogoBoxComponent,
            ProfilePhotoComponent,
            ProgbarComponent,
            ScrollTopComponent,
            SplashComponent,
            VideodisplayComponent,
            UserControlComponent,
            // LOGIN /////////////////////////////////////////
            LoginComponent,
            LoginPopUpComponent,
            NewPassFormComponent,
            LoginformComponent,
            UserRegComponent,
            PassresetComponent,
            LogoutComponent,
            LoginButtonComponent,
            // ECOMMERCE ///////////////////////////////////////
            EcommerceComponent,
            TickMarkerComponent,
            ShopViewComponent,
            ShopNavComponent,
            ProductViewComponent,
            ProductTierComponent,
            CheckoutComponent,
            CartComponent,
            SidecartComponent,
            ItemsdisplayComponent,
            InvoiceComponent,
            // PROFILE /////////////////////////////////////////
            ShareprofileComponent,
            // SETTINGS /////////////////////////////////////////
            SettingsComponent,
            ProfileComponent,
            HelpComponent,
            AccountComponent,
            UserFormComponent,
            // LEGAL /////////////////////////////////////////////
            LegalComponent], imports: [BrowserModule,
            BrowserAnimationsModule,
            FormsModule,
            ReactiveFormsModule,
            HttpClientModule,
            NgOptimizedImage,
            // ION ICONS /////////////////////
            IonicModule], exports: [
            //contact-us
            ContactComponent,
            // COMPONENTS //////////////
            FourZeroFourComponent,
            AccessRestrictComponent,
            BackgroundComponent,
            ClickmapComponent,
            ClockComponent,
            CountdownpageComponent,
            ErrorComponent,
            FooterComponent,
            FormErrorComponent,
            FormCreatorComponent,
            FormSubButtonComponent,
            HeaderComponent,
            LoadingSpinnerComponent,
            LogoBoxComponent,
            ProfilePhotoComponent,
            ProgbarComponent,
            ScrollTopComponent,
            SplashComponent,
            VideodisplayComponent,
            UserControlComponent,
            // LOGIN ///////////////////////////
            LoginComponent,
            LoginPopUpComponent,
            NewPassFormComponent,
            LoginformComponent,
            UserRegComponent,
            PassresetComponent,
            LogoutComponent,
            LoginButtonComponent,
            // Ecommerce ///////////////////////////
            EcommerceComponent,
            TickMarkerComponent,
            ShopViewComponent, ShopNavComponent,
            ProductViewComponent,
            ProductTierComponent,
            CheckoutComponent,
            CartComponent,
            SidecartComponent, ItemsdisplayComponent,
            InvoiceComponent,
            // Settings ///////////////////////////
            SettingsComponent,
            ProfileComponent,
            HelpComponent,
            AccountComponent, UserFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: MyLibraryModule, providers: [
            // FUNCTIONS ////////////////////////// 
            IndexedDBService, FormService, ApiService,
            AuthGuard,
            // GLOBALS  ///////////////////////////
            // GLOBALSService,
            GlobalInitializer,
            // ROUTING ///////////////////////////
            // DynamicRoutingService,
            // COMPONENTS //////////////////////////
            AccessRestrictOverlayService,
            ErrorHandlingService,
            LoadingSpinnerService,
            SplashHandlingService,
            VideodisplayService,
            // PROFILE /////////////////////////////
            ShareprofileService,
            // Ecommerce ///////////////////////////  
            // PaymentService, 
            // StripeService,
        ], imports: [BrowserModule,
            BrowserAnimationsModule,
            FormsModule,
            ReactiveFormsModule,
            HttpClientModule,
            // ION ICONS /////////////////////
            IonicModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: MyLibraryModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        // CONTACT FORM // IN DEVELOPMENT
                        ContactComponent,
                        ContactUsComponent,
                        // COMPONENTS //////////////
                        FourZeroFourComponent,
                        AccessRestrictComponent,
                        BackgroundComponent,
                        ClickmapComponent,
                        ClockComponent,
                        CountdownpageComponent,
                        ErrorComponent,
                        FooterComponent,
                        FormErrorComponent,
                        FormCreatorComponent,
                        FormSubButtonComponent,
                        HeaderComponent,
                        LoadingSpinnerComponent,
                        LogoBoxComponent,
                        ProfilePhotoComponent,
                        ProgbarComponent,
                        ScrollTopComponent,
                        SplashComponent,
                        VideodisplayComponent,
                        UserControlComponent,
                        // LOGIN /////////////////////////////////////////
                        LoginComponent,
                        LoginPopUpComponent,
                        NewPassFormComponent,
                        LoginformComponent,
                        UserRegComponent,
                        PassresetComponent,
                        LogoutComponent,
                        LoginButtonComponent,
                        // ECOMMERCE ///////////////////////////////////////
                        EcommerceComponent,
                        TickMarkerComponent,
                        ShopViewComponent,
                        ShopNavComponent,
                        ProductViewComponent,
                        ProductTierComponent,
                        CheckoutComponent,
                        CartComponent,
                        SidecartComponent,
                        ItemsdisplayComponent,
                        InvoiceComponent,
                        // PROFILE /////////////////////////////////////////
                        ShareprofileComponent,
                        // SETTINGS /////////////////////////////////////////
                        SettingsComponent,
                        ProfileComponent,
                        HelpComponent,
                        AccountComponent,
                        UserFormComponent,
                        // LEGAL /////////////////////////////////////////////
                        LegalComponent,
                        //hub
                        // UserHubComponent, SecondaryRegComponent,
                    ],
                    imports: [
                        BrowserModule,
                        BrowserAnimationsModule,
                        FormsModule,
                        ReactiveFormsModule,
                        HttpClientModule,
                        NgOptimizedImage,
                        // ION ICONS /////////////////////
                        IonicModule,
                    ],
                    exports: [
                        //contact-us
                        ContactComponent,
                        // COMPONENTS //////////////
                        FourZeroFourComponent,
                        AccessRestrictComponent,
                        BackgroundComponent,
                        ClickmapComponent,
                        ClockComponent,
                        CountdownpageComponent,
                        ErrorComponent,
                        FooterComponent,
                        FormErrorComponent,
                        FormCreatorComponent,
                        FormSubButtonComponent,
                        HeaderComponent,
                        LoadingSpinnerComponent,
                        LogoBoxComponent,
                        ProfilePhotoComponent,
                        ProgbarComponent,
                        ScrollTopComponent,
                        SplashComponent,
                        VideodisplayComponent,
                        UserControlComponent,
                        // LOGIN ///////////////////////////
                        LoginComponent,
                        LoginPopUpComponent,
                        NewPassFormComponent,
                        LoginformComponent,
                        UserRegComponent,
                        PassresetComponent,
                        LogoutComponent,
                        LoginButtonComponent,
                        // Ecommerce ///////////////////////////
                        EcommerceComponent,
                        TickMarkerComponent,
                        ShopViewComponent, ShopNavComponent,
                        ProductViewComponent,
                        ProductTierComponent,
                        CheckoutComponent,
                        CartComponent,
                        SidecartComponent, ItemsdisplayComponent,
                        InvoiceComponent,
                        // Settings ///////////////////////////
                        SettingsComponent,
                        ProfileComponent,
                        HelpComponent,
                        AccountComponent, UserFormComponent,
                        //hub
                        // UserHubComponent, SecondaryRegComponent, HeaderComponent,HubFooterComponent,
                        // ION ICONS /////////////////////
                        // IonicModule,
                    ],
                    providers: [
                        // FUNCTIONS ////////////////////////// 
                        IndexedDBService, FormService, ApiService,
                        AuthGuard,
                        // GLOBALS  ///////////////////////////
                        // GLOBALSService,
                        GlobalInitializer,
                        // ROUTING ///////////////////////////
                        // DynamicRoutingService,
                        // COMPONENTS //////////////////////////
                        AccessRestrictOverlayService,
                        ErrorHandlingService,
                        LoadingSpinnerService,
                        SplashHandlingService,
                        VideodisplayService,
                        // PROFILE /////////////////////////////
                        ShareprofileService,
                        // Ecommerce ///////////////////////////  
                        // PaymentService, 
                        // StripeService,
                    ]
                }]
        }] });

/*
 * Public API Surface of my-library
 */
//functions
// export * from './lib/GLOBALS-service.service';

/**
 * Generated bundle index. Do not edit.
 */

export { AccessRestrictComponent, AccessRestrictOverlayService, AccountComponent, ApiService, AuthGuard, BackgroundComponent, CartComponent, CheckoutComponent, ClickmapComponent, ClockComponent, ContactComponent, ContactUsComponent, CountdownpageComponent, EC_Functions, EcommerceComponent, ErrorComponent, ErrorHandlingService, FooterComponent, FormCreatorComponent, FormErrorComponent, FormService, FormSubButtonComponent, FourZeroFourComponent, GlobalInitializer, HeaderComponent, HelpComponent, IndexedDBService, InvoiceComponent, ItemsdisplayComponent, KeysComponent, LoadingSpinnerComponent, LoadingSpinnerService, LoginButtonComponent, LoginComponent, LoginPopUpComponent, LoginformComponent, LogoBoxComponent, LogoutComponent, MyLibraryModule, NavList, NewPassFormComponent, Packages, PassresetComponent, PaymentService, ProductTierComponent, ProductViewComponent, ProfileComponent, ProfilePhotoComponent, ProgbarComponent, ROUTE_CONFIG, ScrollTopComponent, Services, SettingsComponent, ShareprofileComponent, ShareprofileService, ShopNavComponent, ShopViewComponent, SidecartComponent, SplashComponent, SplashHandlingService, StripeService, TickMarkerComponent, US_States, UserControlComponent, UserFormComponent, UserRegComponent, VideodisplayComponent, VideodisplayService, WebsiteAdvancedServices, cRouteKey, eRouteKey, lRouteKey, sRouteKey };
//# sourceMappingURL=my-library.mjs.map
